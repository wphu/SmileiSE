com.deepin.filemanager.icon-view icon-zoom-level 100
com.deepin.filemanager.icon-view thumbnail-size 64
com.deepin.filemanager.icon-view icon-margin 48
com.deepin.wrap.pantheon.desktop.gala.appearance button-layout ':minimize,maximize,close'
com.deepin.wrap.pantheon.desktop.gala.appearance dim-parents false
com.deepin.wrap.pantheon.desktop.gala.appearance workspace-switcher-background ''
com.deepin.wrap.pantheon.desktop.gala.appearance alt-tab-window-opacity 0.0
com.deepin.wrap.pantheon.desktop.gala.appearance attach-modal-dialogs false
com.deepin.wrap.gnome.desktop.privacy remember-app-usage true
com.deepin.wrap.gnome.desktop.privacy remove-old-temp-files false
com.deepin.wrap.gnome.desktop.privacy old-files-age uint32 30
com.deepin.wrap.gnome.desktop.privacy remove-old-trash-files false
com.deepin.wrap.gnome.desktop.privacy remember-recent-files true
com.deepin.wrap.gnome.desktop.privacy send-software-usage-stats false
com.deepin.wrap.gnome.desktop.privacy report-technical-problems false
com.deepin.wrap.gnome.desktop.privacy recent-files-max-age -1
com.deepin.wrap.gnome.desktop.privacy hide-identity false
com.deepin.wrap.gnome.desktop.privacy show-full-name-in-top-bar true
com.deepin.wrap.gnome.settings-daemon.plugins.sharing active true
com.deepin.wrap.gnome.settings-daemon.plugins.sharing priority 0
com.deepin.wrap.gnome.desktop.peripherals.mouse natural-scroll false
com.deepin.wrap.gnome.desktop.peripherals.mouse speed 0.0
com.deepin.wrap.gnome.desktop.peripherals.mouse left-handed false
com.deepin.wrap.gnome.settings-daemon.plugins.screensaver-proxy active true
com.deepin.wrap.gnome.settings-daemon.plugins.screensaver-proxy priority 0
com.deepin.wrap.gnome.mutter.keybindings toggle-tiled-right @as []
com.deepin.wrap.gnome.mutter.keybindings toggle-tiled-left @as []
com.deepin.wrap.gnome.mutter.keybindings tab-popup-cancel @as []
com.deepin.wrap.gnome.mutter.keybindings tab-popup-select @as []
com.deepin.wrap.gnome.settings-daemon.plugins whitelisted-plugins ['all']
com.deepin.wrap.gnome.settings-daemon.plugins.orientation active true
com.deepin.wrap.gnome.settings-daemon.plugins.orientation priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.keyboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.keyboard priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings disabled-gtk-modules @as []
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings hinting 'medium'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings overrides @a{sv} {}
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings rgba-order 'rgb'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings antialiasing 'grayscale'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings active true
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings enabled-gtk-modules @as []
com.deepin.wrap.gnome.settings-daemon.plugins.mouse active true
com.deepin.wrap.gnome.settings-daemon.plugins.mouse priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys logout '<Control><Alt>Delete'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenreader '<Alt><Super>s'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-mute 'XF86AudioMute'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-up 'XF86AudioRaiseVolume'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys window-screenshot '<Alt>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys previous 'XF86AudioPrev'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys control-center 'XF86Tools'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys stop 'XF86AudioStop'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys home 'XF86Explorer'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenshot-clip '<Ctrl>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier '<Alt><Super>8'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys help ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys search 'XF86Search'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys custom-keybindings @as []
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier-zoom-in '<Alt><Super>equal'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys calculator 'XF86Calculator'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys video-out '<Super>p'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys eject 'XF86Eject'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys window-screenshot-clip '<Ctrl><Alt>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys area-screenshot-clip '<Ctrl><Shift>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys media 'XF86AudioMedia'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys www 'XF86WWW'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys play 'XF86AudioPlay'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys email 'XF86Mail'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-down 'XF86AudioLowerVolume'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys decrease-text-size ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys on-screen-keyboard ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys next 'XF86AudioNext'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenshot 'Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys increase-text-size ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys max-screencast-length uint32 30
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier-zoom-out '<Alt><Super>minus'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screencast '<Ctrl><Shift><Alt>R'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screensaver '<Super>l'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys toggle-contrast ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys pause 'XF86AudioPause'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys active true
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys area-screenshot '<Shift>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-keyboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-keyboard priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.gsdwacom active true
com.deepin.wrap.gnome.settings-daemon.plugins.gsdwacom priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr active true
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr default-monitors-setup 'follow-lid'
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr default-configuration-file '/etc/gnome-settings-daemon/xrandr/monitors.xml'
com.deepin.wrap.gnome.settings-daemon.plugins.sound active true
com.deepin.wrap.gnome.settings-daemon.plugins.sound priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.screensaver-proxy active true
com.deepin.wrap.gnome.settings-daemon.plugins.screensaver-proxy priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.print-notifications active true
com.deepin.wrap.gnome.settings-daemon.plugins.print-notifications priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.datetime active true
com.deepin.wrap.gnome.settings-daemon.plugins.datetime priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-settings active true
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-settings priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping min-notify-period 10
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping active true
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-size-gb-no-notify 1
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping ignore-paths @as []
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-percent-notify 0.050000000000000003
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-percent-notify-again 0.01
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.power idle-brightness 30
com.deepin.wrap.gnome.settings-daemon.plugins.power priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-ac-type 'suspend'
com.deepin.wrap.gnome.settings-daemon.plugins.power idle-dim true
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-battery-timeout 0
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-battery-type 'suspend'
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout 0
com.deepin.wrap.gnome.settings-daemon.plugins.power ambient-enabled true
com.deepin.wrap.gnome.settings-daemon.plugins.power active true
com.deepin.wrap.gnome.settings-daemon.plugins.smartcard active true
com.deepin.wrap.gnome.settings-daemon.plugins.smartcard priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.sharing active true
com.deepin.wrap.gnome.settings-daemon.plugins.sharing priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.color active true
com.deepin.wrap.gnome.settings-daemon.plugins.color priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.color recalibrate-display-threshold uint32 0
com.deepin.wrap.gnome.settings-daemon.plugins.color recalibrate-printer-threshold uint32 0
com.deepin.wrap.gnome.settings-daemon.plugins.clipboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.clipboard priority 0
com.deepin.dde.touchpad tap-to-click true
com.deepin.dde.touchpad natural-scroll false
com.deepin.dde.touchpad left-handed false
com.deepin.dde.touchpad delta-scroll 30
com.deepin.dde.touchpad motion-scaling 10.0
com.deepin.dde.touchpad edge-scroll-enabled true
com.deepin.dde.touchpad drag-threshold 8
com.deepin.dde.touchpad motion-acceleration 1.0
com.deepin.dde.touchpad horiz-scroll-enabled false
com.deepin.dde.touchpad vert-scroll-enabled true
com.deepin.dde.touchpad disable-while-typing true
com.deepin.dde.touchpad double-click 400
com.deepin.dde.touchpad motion-threshold 1.0
com.deepin.dde.touchpad touchpad-enabled true
com.deepin.wrap.gnome.desktop.input-sources show-all-sources false
com.deepin.wrap.gnome.desktop.input-sources per-window false
com.deepin.wrap.gnome.desktop.input-sources current uint32 0
com.deepin.wrap.gnome.desktop.input-sources sources @a(ss) []
com.deepin.wrap.gnome.desktop.input-sources xkb-options @as []
com.deepin.desktop.default-applications.terminal exec-arg '-x'
com.deepin.desktop.default-applications.terminal exec 'deepin-terminal'
com.deepin.dde.power sleep-lock true
com.deepin.dde.power fullscreen-workaround-enabled true
com.deepin.dde.power percentage-low 20
com.deepin.dde.power time-to-empty-critical 600
com.deepin.dde.power screen-black-lock false
com.deepin.dde.power line-power-screen-black-delay 900
com.deepin.dde.power time-to-empty-action 300
com.deepin.dde.power use-percentage-for-policy true
com.deepin.dde.power percentage-critical 10
com.deepin.dde.power percentage-action 5
com.deepin.dde.power power-button-pressed-exec 'dde-shutdown'
com.deepin.dde.power fullscreen-workaround-app-list ['libflash', 'chrome', 'firefox', 'mplayer', 'operaplugin', 'soffice', 'wpp', 'evince', 'vlc', 'totem']
com.deepin.dde.power line-power-sleep-delay 1800
com.deepin.dde.power battery-screen-black-delay 900
com.deepin.dde.power lid-closed-exec 'dbus-send --print-reply --dest=com.deepin.SessionManager /com/deepin/SessionManager com.deepin.SessionManager.RequestSuspend'
com.deepin.dde.power battery-sleep-delay 1800
com.deepin.dde.power power-module-initialized false
com.deepin.dde.power multi-screen-prevent-lid-closed-exec false
com.deepin.dde.power time-to-empty-low 1200
com.deepin.wrap.gnome.settings-daemon.plugins.power idle-brightness 30
com.deepin.wrap.gnome.settings-daemon.plugins.power priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-ac-type 'suspend'
com.deepin.wrap.gnome.settings-daemon.plugins.power idle-dim true
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-battery-timeout 0
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-battery-type 'suspend'
com.deepin.wrap.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout 0
com.deepin.wrap.gnome.settings-daemon.plugins.power ambient-enabled true
com.deepin.wrap.gnome.settings-daemon.plugins.power active true
com.deepin.dde.launcher display-mode 'free'
com.deepin.dde.launcher sort-method 'name'
com.deepin.dde.launcher category-display-mode 'icon'
com.deepin.wrap.gnome.desktop.peripherals.keyboard repeat-interval uint32 30
com.deepin.wrap.gnome.desktop.peripherals.keyboard delay uint32 500
com.deepin.wrap.gnome.desktop.peripherals.keyboard repeat true
com.deepin.wrap.gnome.settings-daemon.peripherals.smartcard removal-action 'none'
com.deepin.wrap.gnome.settings-daemon.peripherals.input-devices hotplug-command ''
com.deepin.wrap.gnome.settings-daemon.peripherals.touchscreen orientation-lock false
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard remember-numlock-state true
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-pitch 400
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard click-volume 0
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard numlock-state 'unknown'
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-duration 100
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-mode 'on'
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-custom-file ''
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard click true
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse drag-threshold 8
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse double-click 400
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse locate-pointer false
com.deepin.wrap.gnome.system.proxy.ftp host ''
com.deepin.wrap.gnome.system.proxy.ftp port 0
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys logout '<Control><Alt>Delete'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenreader '<Alt><Super>s'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-mute 'XF86AudioMute'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-up 'XF86AudioRaiseVolume'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys window-screenshot '<Alt>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys previous 'XF86AudioPrev'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys control-center 'XF86Tools'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys stop 'XF86AudioStop'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys home 'XF86Explorer'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenshot-clip '<Ctrl>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier '<Alt><Super>8'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys help ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys search 'XF86Search'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys custom-keybindings @as []
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier-zoom-in '<Alt><Super>equal'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys calculator 'XF86Calculator'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys video-out '<Super>p'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys eject 'XF86Eject'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys window-screenshot-clip '<Ctrl><Alt>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys area-screenshot-clip '<Ctrl><Shift>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys media 'XF86AudioMedia'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys www 'XF86WWW'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys play 'XF86AudioPlay'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys email 'XF86Mail'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys volume-down 'XF86AudioLowerVolume'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys decrease-text-size ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys on-screen-keyboard ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys next 'XF86AudioNext'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screenshot 'Print'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys increase-text-size ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys max-screencast-length uint32 30
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys magnifier-zoom-out '<Alt><Super>minus'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screencast '<Ctrl><Shift><Alt>R'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys screensaver '<Super>l'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys toggle-contrast ''
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys pause 'XF86AudioPause'
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys active true
com.deepin.wrap.gnome.settings-daemon.plugins.media-keys area-screenshot '<Shift>Print'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings disabled-gtk-modules @as []
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings hinting 'medium'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings overrides @a{sv} {}
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings rgba-order 'rgb'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings antialiasing 'grayscale'
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings active true
com.deepin.wrap.gnome.settings-daemon.plugins.xsettings enabled-gtk-modules @as []
com.deepin.wrap.gnome.desktop.screensaver picture-opacity 100
com.deepin.wrap.gnome.desktop.screensaver logout-enabled false
com.deepin.wrap.gnome.desktop.screensaver lock-enabled true
com.deepin.wrap.gnome.desktop.screensaver logout-delay uint32 7200
com.deepin.wrap.gnome.desktop.screensaver embedded-keyboard-enabled false
com.deepin.wrap.gnome.desktop.screensaver primary-color '#023c88'
com.deepin.wrap.gnome.desktop.screensaver idle-activation-enabled true
com.deepin.wrap.gnome.desktop.screensaver secondary-color '#5789ca'
com.deepin.wrap.gnome.desktop.screensaver logout-command ''
com.deepin.wrap.gnome.desktop.screensaver color-shading-type 'solid'
com.deepin.wrap.gnome.desktop.screensaver embedded-keyboard-command ''
com.deepin.wrap.gnome.desktop.screensaver picture-options 'zoom'
com.deepin.wrap.gnome.desktop.screensaver lock-delay uint32 0
com.deepin.wrap.gnome.desktop.screensaver show-full-name-in-top-bar true
com.deepin.wrap.gnome.desktop.screensaver picture-uri 'file:///usr/share/backgrounds/gnome/adwaita-lock.jpg'
com.deepin.wrap.gnome.desktop.screensaver status-message-enabled true
com.deepin.wrap.gnome.desktop.screensaver user-switch-enabled true
com.deepin.dde.peripherals.touchpad tap-to-click true
com.deepin.dde.peripherals.touchpad natural-scroll false
com.deepin.dde.peripherals.touchpad left-handed 'right'
com.deepin.dde.peripherals.touchpad scroll-method 'edge-scrolling'
com.deepin.dde.peripherals.touchpad two-finger-scroll true
com.deepin.dde.peripherals.touchpad motion-acceleration 1.0
com.deepin.dde.peripherals.touchpad horiz-scroll-enabled true
com.deepin.dde.peripherals.touchpad disable-while-typing false
com.deepin.dde.peripherals.touchpad motion-threshold 1.0
com.deepin.dde.peripherals.touchpad touchpad-enabled true
com.deepin.dde.peripherals.input-devices hotplug-command ''
com.deepin.dde.peripherals.touchscreen orientation-lock false
com.deepin.dde.peripherals.keyboard remember-numlock-state true
com.deepin.dde.peripherals.keyboard input-sources-switcher 'off'
com.deepin.dde.peripherals.keyboard delay uint32 500
com.deepin.dde.peripherals.keyboard bell-pitch 400
com.deepin.dde.peripherals.keyboard repeat true
com.deepin.dde.peripherals.keyboard click-volume 0
com.deepin.dde.peripherals.keyboard numlock-state 'unknown'
com.deepin.dde.peripherals.keyboard bell-duration 100
com.deepin.dde.peripherals.keyboard bell-mode 'on'
com.deepin.dde.peripherals.keyboard bell-custom-file ''
com.deepin.dde.peripherals.keyboard click true
com.deepin.dde.peripherals.keyboard user-layout-list @as []
com.deepin.dde.peripherals.keyboard repeat-interval uint32 30
com.deepin.dde.peripherals.mouse drag-threshold 8
com.deepin.dde.peripherals.mouse motion-threshold 1.0
com.deepin.dde.peripherals.mouse middle-button-enabled false
com.deepin.dde.peripherals.mouse motion-acceleration 1.0
com.deepin.dde.peripherals.mouse double-click 400
com.deepin.dde.peripherals.mouse left-handed false
com.deepin.dde.peripherals.mouse locate-pointer false
com.deepin.filemanager.list-view columns-order ['label', 'size', 'mtime', 'filetype']
com.deepin.filemanager.list-view icon-zoom-level 100
com.deepin.filemanager.list-view thumbnail-size 32
com.deepin.filemanager.list-view visible-columns ['label', 'size', 'mtime', 'filetype']
com.deepin.wrap.gnome.desktop.peripherals.touchpad natural-scroll false
com.deepin.wrap.gnome.desktop.peripherals.touchpad click-method 'default'
com.deepin.wrap.gnome.desktop.peripherals.touchpad edge-scrolling-enabled true
com.deepin.wrap.gnome.desktop.peripherals.touchpad left-handed 'mouse'
com.deepin.wrap.gnome.desktop.peripherals.touchpad send-events 'enabled'
com.deepin.wrap.gnome.desktop.peripherals.touchpad tap-to-click false
com.deepin.wrap.gnome.desktop.peripherals.touchpad speed 0.0
com.deepin.wrap.gnome.desktop.peripherals.tablet display ['', '', '']
com.deepin.wrap.gnome.desktop.peripherals.touchscreen display ['', '', '']
com.deepin.wrap.gnome.desktop.peripherals.trackball scroll-wheel-emulation-button 0
com.deepin.wrap.gnome.desktop.peripherals.keyboard repeat-interval uint32 30
com.deepin.wrap.gnome.desktop.peripherals.keyboard delay uint32 500
com.deepin.wrap.gnome.desktop.peripherals.keyboard repeat true
com.deepin.wrap.gnome.desktop.peripherals.mouse natural-scroll false
com.deepin.wrap.gnome.desktop.peripherals.mouse speed 0.0
com.deepin.wrap.gnome.desktop.peripherals.mouse left-handed false
com.deepin.wrap.gnome.settings-daemon.plugins.print-notifications active true
com.deepin.wrap.gnome.settings-daemon.plugins.print-notifications priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.smartcard active true
com.deepin.wrap.gnome.settings-daemon.plugins.smartcard priority 0
com.deepin.wrap.gnome.settings-daemon.peripherals.input-devices hotplug-command ''
com.deepin.wrap.gnome.settings-daemon.plugins.orientation active true
com.deepin.wrap.gnome.settings-daemon.plugins.orientation priority 0
com.deepin.wrap.gnome.desktop.a11y.applications screen-keyboard-enabled false
com.deepin.wrap.gnome.desktop.a11y.applications screen-magnifier-enabled false
com.deepin.wrap.gnome.desktop.a11y.applications screen-reader-enabled false
com.deepin.dde.peripherals.input-devices hotplug-command ''
com.deepin.wrap.gnome.system.proxy use-same-proxy true
com.deepin.wrap.gnome.system.proxy mode 'none'
com.deepin.wrap.gnome.system.proxy autoconfig-url ''
com.deepin.wrap.gnome.system.proxy ignore-hosts ['localhost', '127.0.0.0/8', '::1']
com.deepin.wrap.gnome.system.proxy.ftp host ''
com.deepin.wrap.gnome.system.proxy.ftp port 0
com.deepin.wrap.gnome.system.proxy.socks host ''
com.deepin.wrap.gnome.system.proxy.socks port 0
com.deepin.wrap.gnome.system.proxy.http host ''
com.deepin.wrap.gnome.system.proxy.http port 8080
com.deepin.wrap.gnome.system.proxy.http use-authentication false
com.deepin.wrap.gnome.system.proxy.http authentication-password ''
com.deepin.wrap.gnome.system.proxy.http authentication-user ''
com.deepin.wrap.gnome.system.proxy.http enabled false
com.deepin.wrap.gnome.system.proxy.https host ''
com.deepin.wrap.gnome.system.proxy.https port 0
com.deepin.wrap.pantheon.desktop.gala.mask-corners disable-on-fullscreen true
com.deepin.wrap.pantheon.desktop.gala.mask-corners only-on-primary false
com.deepin.wrap.pantheon.desktop.gala.mask-corners corner-radius 4
com.deepin.wrap.pantheon.desktop.gala.mask-corners enable true
com.deepin.dde.peripherals.touchpad tap-to-click true
com.deepin.dde.peripherals.touchpad natural-scroll false
com.deepin.dde.peripherals.touchpad left-handed 'right'
com.deepin.dde.peripherals.touchpad scroll-method 'edge-scrolling'
com.deepin.dde.peripherals.touchpad two-finger-scroll true
com.deepin.dde.peripherals.touchpad motion-acceleration 1.0
com.deepin.dde.peripherals.touchpad horiz-scroll-enabled true
com.deepin.dde.peripherals.touchpad disable-while-typing false
com.deepin.dde.peripherals.touchpad motion-threshold 1.0
com.deepin.dde.peripherals.touchpad touchpad-enabled true
com.deepin.dde.display display-mode 'unknow'
com.deepin.dde.display brightness-setter 'auto'
com.deepin.dde.display brightness ''
com.deepin.dde.display map-output ''
com.deepin.wrap.gnome.system.locale region ''
com.deepin.wrap.gnome.desktop.default-applications.terminal exec-arg '-x'
com.deepin.wrap.gnome.desktop.default-applications.terminal exec 'gnome-terminal'
com.deepin.wrap.gnome.desktop.default-applications.office.calendar exec 'evolution -c calendar'
com.deepin.wrap.gnome.desktop.default-applications.office.calendar needs-term false
com.deepin.wrap.gnome.desktop.default-applications.office.tasks exec 'evolution -c tasks'
com.deepin.wrap.gnome.desktop.default-applications.office.tasks needs-term false
com.deepin.wrap.gnome.system.proxy.http host ''
com.deepin.wrap.gnome.system.proxy.http port 8080
com.deepin.wrap.gnome.system.proxy.http use-authentication false
com.deepin.wrap.gnome.system.proxy.http authentication-password ''
com.deepin.wrap.gnome.system.proxy.http authentication-user ''
com.deepin.wrap.gnome.system.proxy.http enabled false
com.deepin.wrap.gnome.desktop.datetime automatic-timezone false
com.deepin.dde.dock display-mode 'fashion'
com.deepin.dde.dock icon-size uint32 36
com.deepin.dde.dock position 'bottom'
com.deepin.dde.dock hide-timeout uint32 0
com.deepin.dde.dock docked-apps ['deepin-toggle-desktop', 'deepin-wm-multitaskingview', 'dde-file-manager', 'deepin-appstore', 'deepin-music-player', 'deepin-movie', 'google-chrome', 'dde-control-center']
com.deepin.dde.dock hide-mode 'keep-showing'
com.deepin.dde.dock show-timeout uint32 100
com.deepin.wrap.gnome.desktop.app-folders folder-children @as []
com.deepin.wrap.pantheon.desktop.gala.animations open-duration 350
com.deepin.wrap.pantheon.desktop.gala.animations snap-duration 250
com.deepin.wrap.pantheon.desktop.gala.animations close-duration 300
com.deepin.wrap.pantheon.desktop.gala.animations multitasking-toggle-duration 450
com.deepin.wrap.pantheon.desktop.gala.animations menu-duration 150
com.deepin.wrap.pantheon.desktop.gala.animations workspace-switch-duration 300
com.deepin.wrap.pantheon.desktop.gala.animations enable-animations true
com.deepin.wrap.pantheon.desktop.gala.animations minimize-duration 200
com.deepin.dde.peripherals.touchscreen orientation-lock false
com.deepin.dde.trackpoint middle-button-enabled true
com.deepin.dde.trackpoint middle-button-timeout 50
com.deepin.dde.trackpoint wheel-horiz-scroll true
com.deepin.dde.trackpoint motion-scaling 10.0
com.deepin.dde.trackpoint motion-acceleration 1.0
com.deepin.dde.trackpoint wheel-emulation-timeout 200
com.deepin.dde.trackpoint wheel-emulation-button 2
com.deepin.dde.trackpoint wheel-emulation true
com.deepin.dde.trackpoint motion-threshold 1.0
com.deepin.wrap.gnome.desktop.wm.preferences disable-workarounds false
com.deepin.wrap.gnome.desktop.wm.preferences focus-new-windows 'smart'
com.deepin.wrap.gnome.desktop.wm.preferences action-right-click-titlebar 'menu'
com.deepin.wrap.gnome.desktop.wm.preferences mouse-button-modifier ''
com.deepin.wrap.gnome.desktop.wm.preferences action-middle-click-titlebar 'none'
com.deepin.wrap.gnome.desktop.wm.preferences titlebar-uses-system-font true
com.deepin.wrap.gnome.desktop.wm.preferences theme 'deepin'
com.deepin.wrap.gnome.desktop.wm.preferences num-workspaces 4
com.deepin.wrap.gnome.desktop.wm.preferences raise-on-click true
com.deepin.wrap.gnome.desktop.wm.preferences auto-raise false
com.deepin.wrap.gnome.desktop.wm.preferences visual-bell false
com.deepin.wrap.gnome.desktop.wm.preferences focus-mode 'click'
com.deepin.wrap.gnome.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'
com.deepin.wrap.gnome.desktop.wm.preferences auto-raise-delay 500
com.deepin.wrap.gnome.desktop.wm.preferences button-layout 'appmenu:close'
com.deepin.wrap.gnome.desktop.wm.preferences workspace-names @as []
com.deepin.wrap.gnome.desktop.wm.preferences audible-bell false
com.deepin.wrap.gnome.desktop.wm.preferences resize-with-right-button false
com.deepin.wrap.gnome.desktop.wm.preferences titlebar-font 'Cantarell Bold 11'
com.deepin.wrap.gnome.desktop.wm.preferences visual-bell-type 'fullscreen-flash'
com.deepin.wrap.gnome.desktop.notifications application-children @as []
com.deepin.wrap.gnome.desktop.notifications show-in-lock-screen true
com.deepin.wrap.gnome.desktop.notifications show-banners true
com.deepin.wrap.gnome.desktop.a11y.magnifier focus-tracking 'proportional'
com.deepin.wrap.gnome.desktop.a11y.magnifier contrast-green 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier caret-tracking 'centered'
com.deepin.wrap.gnome.desktop.a11y.magnifier brightness-red 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier cross-hairs-color '#ff0000'
com.deepin.wrap.gnome.desktop.a11y.magnifier cross-hairs-clip false
com.deepin.wrap.gnome.desktop.a11y.magnifier contrast-blue 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier scroll-at-edges false
com.deepin.wrap.gnome.desktop.a11y.magnifier cross-hairs-length 4096
com.deepin.wrap.gnome.desktop.a11y.magnifier show-cross-hairs false
com.deepin.wrap.gnome.desktop.a11y.magnifier screen-position 'full-screen'
com.deepin.wrap.gnome.desktop.a11y.magnifier color-saturation 1.0
com.deepin.wrap.gnome.desktop.a11y.magnifier brightness-green 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier cross-hairs-thickness 8
com.deepin.wrap.gnome.desktop.a11y.magnifier lens-mode false
com.deepin.wrap.gnome.desktop.a11y.magnifier contrast-red 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier invert-lightness false
com.deepin.wrap.gnome.desktop.a11y.magnifier brightness-blue 0.0
com.deepin.wrap.gnome.desktop.a11y.magnifier mouse-tracking 'proportional'
com.deepin.wrap.gnome.desktop.a11y.magnifier cross-hairs-opacity 0.66000000000000003
com.deepin.wrap.gnome.desktop.a11y.magnifier mag-factor 2.0
com.deepin.wrap.gnome.system.proxy.https host ''
com.deepin.wrap.gnome.system.proxy.https port 0
com.deepin.wrap.gnome.metacity.keybindings toggle-tiled-right @as []
com.deepin.wrap.gnome.metacity.keybindings expose-windows ['<Super>W']
com.deepin.wrap.gnome.metacity.keybindings expose-all-windows ['<Super>A']
com.deepin.wrap.gnome.metacity.keybindings preview-workspace ['<Super>S']
com.deepin.wrap.gnome.metacity.keybindings toggle-tiled-left @as []
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-10 ['<Primary><Alt>F10']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-11 ['<Primary><Alt>F11']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-12 ['<Primary><Alt>F12']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-1 ['<Primary><Alt>F1']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-2 ['<Primary><Alt>F2']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-3 ['<Primary><Alt>F3']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-4 ['<Primary><Alt>F4']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-5 ['<Primary><Alt>F5']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-6 ['<Primary><Alt>F6']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-7 ['<Primary><Alt>F7']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-8 ['<Primary><Alt>F8']
com.deepin.wrap.gnome.mutter.wayland.keybindings switch-to-session-9 ['<Primary><Alt>F9']
com.deepin.dde.datetime is-auto-set false
com.deepin.dde.datetime user-timezone-list @as []
com.deepin.dde.datetime dst-offset 0
com.deepin.dde.datetime is-24hour true
com.deepin.wrap.gnome.desktop.lockdown disable-command-line false
com.deepin.wrap.gnome.desktop.lockdown disable-application-handlers false
com.deepin.wrap.gnome.desktop.lockdown disable-user-switching false
com.deepin.wrap.gnome.desktop.lockdown user-administration-disabled false
com.deepin.wrap.gnome.desktop.lockdown disable-printing false
com.deepin.wrap.gnome.desktop.lockdown disable-log-out false
com.deepin.wrap.gnome.desktop.lockdown disable-lock-screen false
com.deepin.wrap.gnome.desktop.lockdown disable-print-setup false
com.deepin.wrap.gnome.desktop.lockdown disable-save-to-disk false
com.deepin.dde.keyboard delay uint32 250
com.deepin.dde.keyboard repeat-enabled true
com.deepin.dde.keyboard click-volume 0
com.deepin.dde.keyboard cursor-blink-time 1200
com.deepin.dde.keyboard layout-options @as []
com.deepin.dde.keyboard click true
com.deepin.dde.keyboard layout ''
com.deepin.dde.keyboard user-layout-list @as []
com.deepin.dde.keyboard capslock-toggle true
com.deepin.dde.keyboard repeat-interval uint32 50
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse drag-threshold 8
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse double-click 400
com.deepin.wrap.gnome.settings-daemon.peripherals.mouse locate-pointer false
com.deepin.wrap.gnome.settings-daemon.plugins.clipboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.clipboard priority 0
com.deepin.wrap.gnome.mutter attach-modal-dialogs false
com.deepin.wrap.gnome.mutter auto-maximize false
com.deepin.wrap.gnome.mutter overlay-key ''
com.deepin.wrap.gnome.mutter dynamic-workspaces false
com.deepin.wrap.gnome.mutter edge-tiling false
com.deepin.wrap.gnome.mutter draggable-border-width 10
com.deepin.wrap.gnome.mutter workspaces-only-on-primary false
com.deepin.wrap.gnome.mutter focus-change-on-pointer-rest false
com.deepin.wrap.gnome.mutter center-new-windows false
com.deepin.wrap.gnome.mutter no-tab-popup false
com.deepin.wrap.gnome.mutter.keybindings toggle-tiled-right @as []
com.deepin.wrap.gnome.mutter.keybindings toggle-tiled-left @as []
com.deepin.wrap.gnome.mutter.keybindings tab-popup-cancel @as []
com.deepin.wrap.gnome.mutter.keybindings tab-popup-select @as []
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr active true
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr default-monitors-setup 'follow-lid'
com.deepin.wrap.gnome.settings-daemon.plugins.xrandr default-configuration-file '/etc/gnome-settings-daemon/xrandr/monitors.xml'
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-time 1.2
com.deepin.wrap.gnome.desktop.a11y.mouse secondary-click-time 1.2
com.deepin.wrap.gnome.desktop.a11y.mouse click-type-window-visible true
com.deepin.wrap.gnome.desktop.a11y.mouse secondary-click-enabled false
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-gesture-double 'up'
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-mode 'window'
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-gesture-single 'left'
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-click-enabled false
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-threshold 10
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-gesture-drag 'down'
com.deepin.wrap.gnome.desktop.a11y.mouse dwell-gesture-secondary 'right'
com.deepin.wrap.gnome.desktop.peripherals.trackball scroll-wheel-emulation-button 0
com.deepin.dde.audio input-volume 10
com.deepin.dde.audio first-run true
com.deepin.dde.audio output-volume 50
com.deepin.wrap.gnome.desktop.default-applications.terminal exec-arg '-x'
com.deepin.wrap.gnome.desktop.default-applications.terminal exec 'gnome-terminal'
com.deepin.filemanager.preferences confirm-trash false
com.deepin.filemanager.preferences activation-policy 'ask'
com.deepin.filemanager.preferences show-extension-name true
com.deepin.filemanager.preferences show-zipped-file-in-directory false
com.deepin.filemanager.preferences autoplay-audio-video false
com.deepin.filemanager.preferences show-function-bar true
com.deepin.filemanager.preferences show-thumbnail 'always'
com.deepin.filemanager.preferences allow-delete-immediatly false
com.deepin.filemanager.preferences sidebar-display-mode 'icon-and-text'
com.deepin.filemanager.preferences click-policy 'double'
com.deepin.filemanager.preferences show-hidden-files-in-search-result false
com.deepin.filemanager.preferences thumbnail-size-unit 'MB'
com.deepin.filemanager.preferences confirm-empty-trash true
com.deepin.filemanager.preferences thumbnail-size-limitation uint64 50
com.deepin.filemanager.preferences label-position 'bottom'
com.deepin.filemanager.preferences open-dir-in-new-window false
com.deepin.filemanager.preferences show-hidden-files false
com.deepin.filemanager.preferences display-extra-items false
com.deepin.filemanager.preferences sort-order 'name'
com.deepin.filemanager.preferences show-brief false
com.deepin.filemanager.preferences view 'icon-view'
com.deepin.wrap.gnome.desktop.interface cursor-blink-timeout 10
com.deepin.wrap.gnome.desktop.interface gtk-color-palette 'black:white:gray50:red:purple:blue:light blue:green:yellow:orange:lavender:brown:goldenrod4:dodger blue:pink:light green:gray10:gray30:gray75:gray90'
com.deepin.wrap.gnome.desktop.interface gtk-timeout-repeat 20
com.deepin.wrap.gnome.desktop.interface toolkit-accessibility false
com.deepin.wrap.gnome.desktop.interface cursor-theme 'deepin'
com.deepin.wrap.gnome.desktop.interface gtk-im-module 'fcitx'
com.deepin.wrap.gnome.desktop.interface clock-show-seconds false
com.deepin.wrap.gnome.desktop.interface can-change-accels false
com.deepin.wrap.gnome.desktop.interface toolbar-detachable false
com.deepin.wrap.gnome.desktop.interface cursor-blink-time 1200
com.deepin.wrap.gnome.desktop.interface enable-animations true
com.deepin.wrap.gnome.desktop.interface menubar-detachable false
com.deepin.wrap.gnome.desktop.interface toolbar-style 'both-horiz'
com.deepin.wrap.gnome.desktop.interface toolbar-icons-size 'large'
com.deepin.wrap.gnome.desktop.interface text-scaling-factor 1.0
com.deepin.wrap.gnome.desktop.interface icon-theme 'deepin'
com.deepin.wrap.gnome.desktop.interface gtk-timeout-initial 200
com.deepin.wrap.gnome.desktop.interface scaling-factor uint32 0
com.deepin.wrap.gnome.desktop.interface clock-format '24h'
com.deepin.wrap.gnome.desktop.interface monospace-font-name 'Monospace 11'
com.deepin.wrap.gnome.desktop.interface menus-have-tearoff false
com.deepin.wrap.gnome.desktop.interface gtk-im-preedit-style 'callback'
com.deepin.wrap.gnome.desktop.interface cursor-blink true
com.deepin.wrap.gnome.desktop.interface gtk-theme 'deepin'
com.deepin.wrap.gnome.desktop.interface gtk-key-theme 'Default'
com.deepin.wrap.gnome.desktop.interface gtk-im-status-style 'callback'
com.deepin.wrap.gnome.desktop.interface menubar-accel 'F10'
com.deepin.wrap.gnome.desktop.interface cursor-size 24
com.deepin.wrap.gnome.desktop.interface font-name 'Cantarell 11'
com.deepin.wrap.gnome.desktop.interface clock-show-date false
com.deepin.wrap.gnome.desktop.interface document-font-name 'Sans 11'
com.deepin.wrap.gnome.desktop.interface gtk-color-scheme ''
com.deepin.wrap.pantheon.desktop.gala.behavior hotcorner-custom-command ''
com.deepin.wrap.pantheon.desktop.gala.behavior dynamic-workspaces false
com.deepin.wrap.pantheon.desktop.gala.behavior auto-focus-windows ['dde-launcher', 'DDE-Launcher']
com.deepin.wrap.pantheon.desktop.gala.behavior hotcorner-bottomright 'none'
com.deepin.wrap.pantheon.desktop.gala.behavior show-desktop-in-alt-tab true
com.deepin.wrap.pantheon.desktop.gala.behavior dock-names ['plank']
com.deepin.wrap.pantheon.desktop.gala.behavior panel-main-menu-action ''
com.deepin.wrap.pantheon.desktop.gala.behavior edge-tiling true
com.deepin.wrap.pantheon.desktop.gala.behavior hotcorner-topright 'none'
com.deepin.wrap.pantheon.desktop.gala.behavior hotcorner-bottomleft 'none'
com.deepin.wrap.pantheon.desktop.gala.behavior hotcorner-topleft 'none'
com.deepin.wrap.pantheon.desktop.gala.behavior overlay-action ''
com.deepin.wrap.pantheon.desktop.gala.behavior toggle-recording-action ''
com.deepin.wrap.pantheon.desktop.gala.behavior window-overview-type 'grid'
com.deepin.wrap.pantheon.desktop.gala.keybindings move-to-workspace-last ['<Super><Shift>End', '<Control><Alt><Shift>End']
com.deepin.wrap.pantheon.desktop.gala.keybindings expose-windows ['<Super>W']
com.deepin.wrap.pantheon.desktop.gala.keybindings move-to-workspace-first ['<Super><Shift>Home', '<Control><Alt><Shift>Home']
com.deepin.wrap.pantheon.desktop.gala.keybindings switch-input-source @as []
com.deepin.wrap.pantheon.desktop.gala.keybindings switch-input-source-backward @as []
com.deepin.wrap.pantheon.desktop.gala.keybindings cycle-workspaces-next @as []
com.deepin.wrap.pantheon.desktop.gala.keybindings cycle-workspaces-previous @as []
com.deepin.wrap.pantheon.desktop.gala.keybindings switch-to-workspace-last ['<Super>End', '<Control><Alt>End']
com.deepin.wrap.pantheon.desktop.gala.keybindings zoom-out ['<Super>minus', '<Super>KP_Subtract']
com.deepin.wrap.pantheon.desktop.gala.keybindings switch-to-workspace-first ['<Super>Home', '<Control><Alt>Home']
com.deepin.wrap.pantheon.desktop.gala.keybindings expose-all-windows ['<Super>A']
com.deepin.wrap.pantheon.desktop.gala.keybindings zoom-in ['<Super>plus', '<Super>KP_Add']
com.deepin.wrap.pantheon.desktop.gala.keybindings preview-workspace ['<Super>S']
com.deepin.wrap.gnome.desktop.search-providers sort-order ['gnome-contacts.desktop', 'gnome-documents.desktop', 'nautilus.desktop']
com.deepin.wrap.gnome.desktop.search-providers disabled @as []
com.deepin.wrap.gnome.desktop.search-providers disable-external false
com.deepin.wrap.gnome.desktop.search-providers enabled @as []
com.deepin.wrap.gnome.settings-daemon.plugins.color active true
com.deepin.wrap.gnome.settings-daemon.plugins.color priority 0
com.deepin.wrap.gnome.settings-daemon.plugins.color recalibrate-display-threshold uint32 0
com.deepin.wrap.gnome.settings-daemon.plugins.color recalibrate-printer-threshold uint32 0
com.deepin.xsettings scale-factor 1.0
com.deepin.xsettings xft-rgba 'rgb'
com.deepin.xsettings gtk-key-theme-name 'Default'
com.deepin.xsettings gtk-recent-files-enabled true
com.deepin.xsettings theme-name 'deepin'
com.deepin.xsettings gtk-theme-name 'deepin'
com.deepin.xsettings xft-hinting true
com.deepin.xsettings sound-theme-name 'deepin'
com.deepin.xsettings gtk-cursor-blink-timeout 10
com.deepin.xsettings icon-theme-fallback 'default'
com.deepin.xsettings double-click-time 250
com.deepin.xsettings cursor-blink-time 1200
com.deepin.xsettings dnd-drag-threshold 8
com.deepin.xsettings enable-event-sounds true
com.deepin.xsettings enable-input-feedback-sounds true
com.deepin.xsettings double-click-distance 5
com.deepin.xsettings icon-theme-name 'deepin'
com.deepin.xsettings gtk-cursor-theme-name 'deepin'
com.deepin.xsettings xft-hintstyle 'hintfull'
com.deepin.xsettings cursor-blink true
com.deepin.xsettings xft-antialias true
com.deepin.xsettings gtk-cursor-theme-size 24
com.deepin.xsettings gtk-font-name 'sans-serif 10'
com.deepin.xsettings gtk-recent-files-max-age 30
com.deepin.xsettings xft-dpi -1
com.deepin.dde.keybinding.system launcher ['Super_L']
com.deepin.dde.keybinding.system screenshot-fullscreen ['Print']
com.deepin.dde.keybinding.system screenshot-delayed ['<Control>Print']
com.deepin.dde.keybinding.system screenshot ['<Control><Alt>A']
com.deepin.dde.keybinding.system logout ['<Control><Alt>Delete']
com.deepin.dde.keybinding.system lock-screen ['<Super>L']
com.deepin.dde.keybinding.system switch-layout ['<Super>Space']
com.deepin.dde.keybinding.system screenshot-window ['<Alt>Print']
com.deepin.dde.keybinding.system disable-touchpad ['']
com.deepin.dde.keybinding.system terminal ['<Control><Alt>T']
com.deepin.dde.keybinding.system turn-off-screen ['<Shift><Super>L']
com.deepin.dde.keybinding.system file-manager ['<Super>E']
com.deepin.dde.keybinding.system terminal-quake ['<Alt>F2']
com.deepin.dde.keybinding.system wm-switcher ['<Shift><Super>Tab']
com.deepin.wrap.gnome.desktop.session session-name 'gnome'
com.deepin.wrap.gnome.desktop.session idle-delay uint32 300
com.deepin.wrap.gnome.desktop.a11y always-show-universal-access-status false
com.deepin.wrap.gnome.desktop.default-applications.office.calendar exec 'evolution -c calendar'
com.deepin.wrap.gnome.desktop.default-applications.office.calendar needs-term false
com.deepin.wrap.gnome.desktop.default-applications.office.tasks exec 'evolution -c tasks'
com.deepin.wrap.gnome.desktop.default-applications.office.tasks needs-term false
com.deepin.wrap.gnome.desktop.thumbnailers disable-all false
com.deepin.wrap.gnome.desktop.thumbnailers disable @as []
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-windows-backward @as []
com.deepin.wrap.gnome.desktop.wm.keybindings minimize ['<Super>N']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-7 ['<Super><Shift>7', '<Super><Shift>KP_7']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-8 ['<Super><Shift>8', '<Super><Shift>KP_8']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-9 ['<Super><Shift>9', '<Super><Shift>KP_9']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-monitor-left @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-5 ['<Super><Shift>5', '<Super><Shift>KP_5']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-6 ['<Super><Shift>6', '<Super><Shift>KP_6']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-10 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-11 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-12 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-center @as []
com.deepin.wrap.gnome.desktop.wm.keybindings unmaximize ['<Super>Down']
com.deepin.wrap.gnome.desktop.wm.keybindings panel-main-menu @as []
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-windows @as []
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-panels-backward ['<Shift><Control><Alt>Escape']
com.deepin.wrap.gnome.desktop.wm.keybindings panel-run-dialog @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-down @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-corner-ne @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-side-e @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-right ['<Super><Shift>Right']
com.deepin.wrap.gnome.desktop.wm.keybindings always-on-top @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-up @as []
com.deepin.wrap.gnome.desktop.wm.keybindings raise @as []
com.deepin.wrap.gnome.desktop.wm.keybindings maximize ['<Super>Up']
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-group-backward @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-side-n @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-side-s @as []
com.deepin.wrap.gnome.desktop.wm.keybindings maximize-horizontally @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-side-w @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-corner-nw @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-windows @as []
com.deepin.wrap.gnome.desktop.wm.keybindings begin-move ['<Alt>F7']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-monitor-down @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-windows-backward @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-left ['<Super><Shift>Left']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-corner-se @as []
com.deepin.wrap.gnome.desktop.wm.keybindings activate-window-menu ['<Alt>space']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-input-source @as []
com.deepin.wrap.gnome.desktop.wm.keybindings toggle-above @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-monitor-right @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-input-source-backward @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-last ['<Super><Shift>End']
com.deepin.wrap.gnome.desktop.wm.keybindings lower @as []
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-panels ['<Control><Alt>Escape']
com.deepin.wrap.gnome.desktop.wm.keybindings toggle-fullscreen @as []
com.deepin.wrap.gnome.desktop.wm.keybindings toggle-on-all-workspaces @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-monitor-up @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-corner-sw @as []
com.deepin.wrap.gnome.desktop.wm.keybindings toggle-shaded @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-1 ['<Super>1', '<Super>KP_1']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-2 ['<Super>2', '<Super>KP_2']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-3 ['<Super>3', '<Super>KP_3']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-4 ['<Super>4', '<Super>KP_4']
com.deepin.wrap.gnome.desktop.wm.keybindings raise-or-lower @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-panels ['<Control><Alt>Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-panels-backward ['<Shift><Control><Alt>Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-applications-backward ['<Alt><Shift>Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings maximize-vertically @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-7 ['<Super>7', '<Super>KP_7']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-5 ['<Super>5', '<Super>KP_5']
com.deepin.wrap.gnome.desktop.wm.keybindings show-desktop ['<Super>D']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-8 ['<Super>8', '<Super>KP_8']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-9 ['<Super>9', '<Super>KP_9']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-6 ['<Super>6', '<Super>KP_6']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-applications ['<Alt>Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-10 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-11 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-12 @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-left ['<Super>Left']
com.deepin.wrap.gnome.desktop.wm.keybindings toggle-maximized ['<Super>M', '<Alt>F10']
com.deepin.wrap.gnome.desktop.wm.keybindings set-spew-mark @as []
com.deepin.wrap.gnome.desktop.wm.keybindings begin-resize ['<Alt>F8']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-down @as []
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-last ['<Super>End']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-group-backward ['<Alt><Shift>Above_Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-group ['<Alt>Above_Tab']
com.deepin.wrap.gnome.desktop.wm.keybindings cycle-group @as []
com.deepin.wrap.gnome.desktop.wm.keybindings close ['<Alt>F4']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-up @as []
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-1 ['<Super><Shift>1', '<Super><Shift>KP_1']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-2 ['<Super><Shift>2', '<Super><Shift>KP_2']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-3 ['<Super><Shift>3', '<Super><Shift>KP_3']
com.deepin.wrap.gnome.desktop.wm.keybindings move-to-workspace-4 ['<Super><Shift>4', '<Super><Shift>KP_4']
com.deepin.wrap.gnome.desktop.wm.keybindings switch-to-workspace-right ['<Super>Right']
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-keyboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-keyboard priority 0
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard remember-numlock-state true
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-pitch 400
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard click-volume 0
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard numlock-state 'unknown'
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-duration 100
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-mode 'on'
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard bell-custom-file ''
com.deepin.wrap.gnome.settings-daemon.peripherals.keyboard click true
com.deepin.dde.zone white-list ['dde-launcher']
com.deepin.dde.zone black-list ['pyrogenesis', '0ad']
com.deepin.dde.zone right-down 'dbus-send --print-reply --dest=com.deepin.dde.ControlCenter /com/deepin/dde/ControlCenter com.deepin.dde.ControlCenter.Toggle'
com.deepin.dde.zone delay 300
com.deepin.dde.zone right-up ''
com.deepin.dde.zone left-down 'dbus-send --session --dest=com.deepin.wm --print-reply /com/deepin/wm com.deepin.wm.PerformAction int32:6'
com.deepin.dde.zone left-up 'dbus-send --print-reply --dest=com.deepin.dde.Launcher /com/deepin/dde/Launcher com.deepin.dde.Launcher.Toggle'
com.deepin.dde.peripherals.keyboard remember-numlock-state true
com.deepin.dde.peripherals.keyboard input-sources-switcher 'off'
com.deepin.dde.peripherals.keyboard delay uint32 500
com.deepin.dde.peripherals.keyboard bell-pitch 400
com.deepin.dde.peripherals.keyboard repeat true
com.deepin.dde.peripherals.keyboard click-volume 0
com.deepin.dde.peripherals.keyboard numlock-state 'unknown'
com.deepin.dde.peripherals.keyboard bell-duration 100
com.deepin.dde.peripherals.keyboard bell-mode 'on'
com.deepin.dde.peripherals.keyboard bell-custom-file ''
com.deepin.dde.peripherals.keyboard click true
com.deepin.dde.peripherals.keyboard user-layout-list @as []
com.deepin.dde.peripherals.keyboard repeat-interval uint32 30
com.deepin.wrap.gnome.desktop.a11y.keyboard slowkeys-beep-press false
com.deepin.wrap.gnome.desktop.a11y.keyboard mousekeys-accel-time 300
com.deepin.wrap.gnome.desktop.a11y.keyboard bouncekeys-beep-reject false
com.deepin.wrap.gnome.desktop.a11y.keyboard slowkeys-beep-reject false
com.deepin.wrap.gnome.desktop.a11y.keyboard togglekeys-enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard disable-timeout 200
com.deepin.wrap.gnome.desktop.a11y.keyboard enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard bouncekeys-enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard stickykeys-enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard feature-state-change-beep false
com.deepin.wrap.gnome.desktop.a11y.keyboard slowkeys-beep-accept false
com.deepin.wrap.gnome.desktop.a11y.keyboard bouncekeys-delay 300
com.deepin.wrap.gnome.desktop.a11y.keyboard mousekeys-max-speed 10
com.deepin.wrap.gnome.desktop.a11y.keyboard mousekeys-enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard timeout-enable false
com.deepin.wrap.gnome.desktop.a11y.keyboard slowkeys-delay 300
com.deepin.wrap.gnome.desktop.a11y.keyboard stickykeys-modifier-beep false
com.deepin.wrap.gnome.desktop.a11y.keyboard stickykeys-two-key-off false
com.deepin.wrap.gnome.desktop.a11y.keyboard mousekeys-init-delay 300
com.deepin.wrap.gnome.desktop.a11y.keyboard slowkeys-enable false
com.deepin.dde.wacom keydown-action 'MiddleClick'
com.deepin.dde.wacom left-handed false
com.deepin.dde.wacom pressure-sensitive uint32 6
com.deepin.dde.wacom raw-sample uint32 4
com.deepin.dde.wacom threshold uint32 27
com.deepin.dde.wacom map-output ''
com.deepin.dde.wacom double-delta uint32 2
com.deepin.dde.wacom keyup-action 'RightClick'
com.deepin.dde.wacom cursor-mode false
com.deepin.dde.appearance extra-picture-uris @as []
com.deepin.dde.appearance font-standard 'Noto Sans'
com.deepin.dde.appearance cursor-theme 'deepin'
com.deepin.dde.appearance font-size 11
com.deepin.dde.appearance icon-theme 'deepin'
com.deepin.dde.appearance font-monospace 'Noto Mono'
com.deepin.dde.appearance excluded-icon-themes ['hicolor', 'gnome', 'Adwaita']
com.deepin.dde.appearance gtk-theme 'deepin'
com.deepin.dde.appearance sound-theme 'deepin'
com.deepin.dde.appearance background-uris @as []
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping min-notify-period 10
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping active true
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-size-gb-no-notify 1
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping ignore-paths @as []
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-percent-notify 0.050000000000000003
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping free-percent-notify-again 0.01
com.deepin.wrap.gnome.settings-daemon.plugins.housekeeping priority 0
com.deepin.wrap.pantheon.desktop.gala.shadows normal-focused ['20', '-1', '0', '15', '220']
com.deepin.wrap.pantheon.desktop.gala.shadows menu ['7', '-1', '0', '5', '130']
com.deepin.wrap.pantheon.desktop.gala.shadows dialog-focused ['12', '-1', '0', '7', '190']
com.deepin.wrap.pantheon.desktop.gala.shadows dialog-unfocused ['7', '-1', '0', '4', '130']
com.deepin.wrap.pantheon.desktop.gala.shadows normal-unfocused ['8', '-1', '0', '6', '150']
com.deepin.wrap.gnome.settings-daemon.plugins.rfkill active true
com.deepin.wrap.gnome.settings-daemon.plugins.rfkill priority 0
com.deepin.wrap.pantheon.desktop.gala.notifications do-not-disturb false
com.deepin.wrap.pantheon.desktop.gala.notifications.application bubbles true
com.deepin.wrap.pantheon.desktop.gala.notifications.application remember true
com.deepin.wrap.pantheon.desktop.gala.notifications.application sounds true
com.deepin.wrap.gnome.settings-daemon.peripherals.smartcard removal-action 'none'
com.deepin.dde.keybinding.mediakey cycle-angle ['XF86CycleAngle']
com.deepin.dde.keybinding.mediakey standby ['XF86Standby']
com.deepin.dde.keybinding.mediakey messenger ['XF86Messenger']
com.deepin.dde.keybinding.mediakey mail ['XF86Mail']
com.deepin.dde.keybinding.mediakey frame-back ['XF86FrameBack']
com.deepin.dde.keybinding.mediakey calendar ['XF86Calendar']
com.deepin.dde.keybinding.mediakey send ['XF86Send']
com.deepin.dde.keybinding.mediakey application-right ['XF86ApplicationRight']
com.deepin.dde.keybinding.mediakey scroll-down ['XF86ScrollDown']
com.deepin.dde.keybinding.mediakey clear ['XF86Clear']
com.deepin.dde.keybinding.mediakey mon-brightness-up ['XF86MonBrightnessUp']
com.deepin.dde.keybinding.mediakey menu-kb ['XF86MenuKB']
com.deepin.dde.keybinding.mediakey audio-mute ['XF86AudioMute']
com.deepin.dde.keybinding.mediakey mode-lock ['XF86ModeLock']
com.deepin.dde.keybinding.mediakey forward ['XF86Forward']
com.deepin.dde.keybinding.mediakey favorites ['XF86Favorites']
com.deepin.dde.keybinding.mediakey audio-repeat ['XF86AudioRepeat']
com.deepin.dde.keybinding.mediakey power-down ['XF86PowerDown']
com.deepin.dde.keybinding.mediakey touchpad-on ['XF86TouchpadOn']
com.deepin.dde.keybinding.mediakey wheel-button ['XF86WheelButton']
com.deepin.dde.keybinding.mediakey finance ['XF86Finance']
com.deepin.dde.keybinding.mediakey sleep ['XF86Sleep']
com.deepin.dde.keybinding.mediakey audio-play ['XF86AudioPlay']
com.deepin.dde.keybinding.mediakey xfer ['XF86Xfer']
com.deepin.dde.keybinding.mediakey application-left ['XF86ApplicationLeft']
com.deepin.dde.keybinding.mediakey audio-raise-volume ['XF86AudioRaiseVolume']
com.deepin.dde.keybinding.mediakey audio-stop ['XF86AudioStop']
com.deepin.dde.keybinding.mediakey dos ['XF86DOS']
com.deepin.dde.keybinding.mediakey bluetooth ['XF86Bluetooth']
com.deepin.dde.keybinding.mediakey subtitle ['XF86Subtitle']
com.deepin.dde.keybinding.mediakey suspend ['XF86Suspend']
com.deepin.dde.keybinding.mediakey mail-forward ['XF86MailForward']
com.deepin.dde.keybinding.mediakey open-url ['XF86OpenURL']
com.deepin.dde.keybinding.mediakey go ['XF86Go']
com.deepin.dde.keybinding.mediakey rocker-up ['XF86RockerUp']
com.deepin.dde.keybinding.mediakey music ['XF86Music']
com.deepin.dde.keybinding.mediakey mon-brightness-down ['XF86MonBrightnessDown']
com.deepin.dde.keybinding.mediakey capslock ['Caps_Lock']
com.deepin.dde.keybinding.mediakey shop ['XF86Shop']
com.deepin.dde.keybinding.mediakey office-home ['XF86OfficeHome']
com.deepin.dde.keybinding.mediakey calculater ['XF86Calculater']
com.deepin.dde.keybinding.mediakey new ['XF86New']
com.deepin.dde.keybinding.mediakey audio-forward ['XF86AudioForward']
com.deepin.dde.keybinding.mediakey scroll-up ['XF86ScrollUp']
com.deepin.dde.keybinding.mediakey back ['XF86Back']
com.deepin.dde.keybinding.mediakey audio-random-play ['XF86AudioRandomPlay']
com.deepin.dde.keybinding.mediakey documents ['XF86Documents']
com.deepin.dde.keybinding.mediakey stop ['XF86Stop']
com.deepin.dde.keybinding.mediakey explorer ['XF86Explorer']
com.deepin.dde.keybinding.mediakey terminal ['XF86Terminal']
com.deepin.dde.keybinding.mediakey audio-rewind ['XF86AudioRewind']
com.deepin.dde.keybinding.mediakey my-computer ['XF86MyComputer']
com.deepin.dde.keybinding.mediakey power-off ['XF86PowerOff']
com.deepin.dde.keybinding.mediakey wake-up ['XF86WakeUp']
com.deepin.dde.keybinding.mediakey top-menu ['XF86TopMenu']
com.deepin.dde.keybinding.mediakey blue ['XF86Blue']
com.deepin.dde.keybinding.mediakey audio-lower-volume ['XF86AudioLowerVolume']
com.deepin.dde.keybinding.mediakey rocker-enter ['XF86RockerEnter']
com.deepin.dde.keybinding.mediakey away ['XF86Away']
com.deepin.dde.keybinding.mediakey audio-record ['XF86AudioRecord']
com.deepin.dde.keybinding.mediakey my-sites ['XF86MySites']
com.deepin.dde.keybinding.mediakey brightness-adjust ['XF86BrightnessAdjust']
com.deepin.dde.keybinding.mediakey hot-links ['XF86HotLinks']
com.deepin.dde.keybinding.mediakey display ['XF86Display']
com.deepin.dde.keybinding.mediakey audio-mic-mute ['XF86AudioMicMute']
com.deepin.dde.keybinding.mediakey audio-next ['XF86AudioNext']
com.deepin.dde.keybinding.mediakey news ['XF86News']
com.deepin.dde.keybinding.mediakey split-screen ['XF86SplitScreen']
com.deepin.dde.keybinding.mediakey time ['XF86Time']
com.deepin.dde.keybinding.mediakey wlan ['XF86WLAN']
com.deepin.dde.keybinding.mediakey game ['XF86Game']
com.deepin.dde.keybinding.mediakey select ['XF86Select']
com.deepin.dde.keybinding.mediakey paste ['XF86Paste']
com.deepin.dde.keybinding.mediakey touchpad-toggle ['XF86TouchpadToggle']
com.deepin.dde.keybinding.mediakey red ['XF86Red']
com.deepin.dde.keybinding.mediakey eject ['XF86Eject']
com.deepin.dde.keybinding.mediakey excel ['XF86Excel']
com.deepin.dde.keybinding.mediakey rocker-down ['XF86RockerDown']
com.deepin.dde.keybinding.mediakey meeting ['XF86Meeting']
com.deepin.dde.keybinding.mediakey community ['XF86Community']
com.deepin.dde.keybinding.mediakey calculator ['XF86Calculator']
com.deepin.dde.keybinding.mediakey zoom-out ['XF86ZoomOut']
com.deepin.dde.keybinding.mediakey zoom-in ['XF86ZoomIn']
com.deepin.dde.keybinding.mediakey phone ['XF86Phone']
com.deepin.dde.keybinding.mediakey battery ['XF86Battery']
com.deepin.dde.keybinding.mediakey switch-monitors ['<Super>P']
com.deepin.dde.keybinding.mediakey book ['XF86Book']
com.deepin.dde.keybinding.mediakey kbd-brightness-down ['XF86KbdBrightnessDown']
com.deepin.dde.keybinding.mediakey video ['XF86Video']
com.deepin.dde.keybinding.mediakey home-page ['XF86HomePage']
com.deepin.dde.keybinding.mediakey audio-cycle-track ['XF86AudioCycleTrack']
com.deepin.dde.keybinding.mediakey cut ['XF86Cut']
com.deepin.dde.keybinding.mediakey reload ['XF86Reload']
com.deepin.dde.keybinding.mediakey cd ['XF86CD']
com.deepin.dde.keybinding.mediakey pictures ['XF86Pictures']
com.deepin.dde.keybinding.mediakey word ['XF86Word']
com.deepin.dde.keybinding.mediakey frame-forward ['XF86FrameForward']
com.deepin.dde.keybinding.mediakey touchpad-off ['XF86TouchpadOff']
com.deepin.dde.keybinding.mediakey numlock ['Num_Lock']
com.deepin.dde.keybinding.mediakey audio-prev ['XF86AudioPrev']
com.deepin.dde.keybinding.mediakey contrast-adjust ['XF86ContrastAdjust']
com.deepin.dde.keybinding.mediakey www ['XF86WWW']
com.deepin.dde.keybinding.mediakey history ['XF86History']
com.deepin.dde.keybinding.mediakey audio-pause ['XF86AudioPause']
com.deepin.dde.keybinding.mediakey web-cam ['XF86WebCam']
com.deepin.dde.keybinding.mediakey menu-pb ['XF86MenuPB']
com.deepin.dde.keybinding.mediakey spell ['XF86Spell']
com.deepin.dde.keybinding.mediakey save ['XF86Save']
com.deepin.dde.keybinding.mediakey green ['XF86Green']
com.deepin.dde.keybinding.mediakey tools ['XF86Tools']
com.deepin.dde.keybinding.mediakey to-do-list ['XF86ToDoList']
com.deepin.dde.keybinding.mediakey close ['XF86Close']
com.deepin.dde.keybinding.mediakey vendor-home ['XF86VendorHome']
com.deepin.dde.keybinding.mediakey reply ['XF86Reply']
com.deepin.dde.keybinding.mediakey support ['XF86Support']
com.deepin.dde.keybinding.mediakey light-bulb ['XF86LightBulb']
com.deepin.dde.keybinding.mediakey view ['XF86View']
com.deepin.dde.keybinding.mediakey scroll-click ['XF86ScrollClick']
com.deepin.dde.keybinding.mediakey option ['XF86Option']
com.deepin.dde.keybinding.mediakey yellow ['XF86Yellow']
com.deepin.dde.keybinding.mediakey screen-saver ['XF86ScreenSaver']
com.deepin.dde.keybinding.mediakey kbd-light-on-off ['XF86KbdLightOnOff']
com.deepin.dde.keybinding.mediakey refresh ['XF86Refresh']
com.deepin.dde.keybinding.mediakey start ['XF86Start']
com.deepin.dde.keybinding.mediakey kbd-brightness-up ['XF86KbdBrightnessUp']
com.deepin.dde.keybinding.mediakey search ['XF86Search']
com.deepin.dde.keybinding.mediakey task-pane ['XF86TaskPane']
com.deepin.dde.keybinding.mediakey uwb ['XF86UWB']
com.deepin.dde.keybinding.mediakey open ['XF86Open']
com.deepin.dde.keybinding.mediakey memo ['XF86Memo']
com.deepin.dde.keybinding.mediakey add-favorite ['XF86AddFavorite']
com.deepin.dde.keybinding.mediakey hibernate ['XF86Hibernate']
com.deepin.dde.keybinding.mediakey log-off ['XF86LogOff']
com.deepin.dde.keybinding.mediakey rotate-windows ['XF86RotateWindows']
com.deepin.dde.keybinding.mediakey audio-media ['XF86AudioMedia']
com.deepin.dde.keybinding.mediakey copy ['XF86Copy']
com.deepin.wrap.gnome.system.proxy.socks host ''
com.deepin.wrap.gnome.system.proxy.socks port 0
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-settings active true
com.deepin.wrap.gnome.settings-daemon.plugins.a11y-settings priority 0
com.deepin.wrap.gnome.desktop.default-applications.office.calendar exec 'evolution -c calendar'
com.deepin.wrap.gnome.desktop.default-applications.office.calendar needs-term false
com.deepin.wrap.gnome.desktop.peripherals.touchpad natural-scroll false
com.deepin.wrap.gnome.desktop.peripherals.touchpad click-method 'default'
com.deepin.wrap.gnome.desktop.peripherals.touchpad edge-scrolling-enabled true
com.deepin.wrap.gnome.desktop.peripherals.touchpad left-handed 'mouse'
com.deepin.wrap.gnome.desktop.peripherals.touchpad send-events 'enabled'
com.deepin.wrap.gnome.desktop.peripherals.touchpad tap-to-click false
com.deepin.wrap.gnome.desktop.peripherals.touchpad speed 0.0
com.deepin.wrap.gnome.desktop.default-applications.office.tasks exec 'evolution -c tasks'
com.deepin.wrap.gnome.desktop.default-applications.office.tasks needs-term false
com.deepin.dde.sound-effect empty-trash true
com.deepin.dde.sound-effect icon-to-desktop false
com.deepin.dde.sound-effect volume-change true
com.deepin.dde.sound-effect camera-shutter false
com.deepin.dde.sound-effect screenshot false
com.deepin.dde.sound-effect logout true
com.deepin.dde.sound-effect login true
com.deepin.dde.sound-effect device-unplug true
com.deepin.dde.sound-effect shutdown true
com.deepin.dde.sound-effect power-plug true
com.deepin.dde.sound-effect device-plug true
com.deepin.dde.sound-effect unable-operate true
com.deepin.dde.sound-effect enabled true
com.deepin.dde.sound-effect notification true
com.deepin.dde.sound-effect power-unplug true
com.deepin.dde.sound-effect battery-low true
com.deepin.dde.sound-effect wakeup true
com.deepin.wrap.gnome.desktop.thumbnail-cache maximum-age 180
com.deepin.wrap.gnome.desktop.thumbnail-cache maximum-size 512
com.deepin.wrap.gnome.metacity placement-mode 'smart'
com.deepin.wrap.gnome.metacity compositing-manager true
com.deepin.wrap.gnome.metacity theme 'deepin'
com.deepin.wrap.gnome.metacity reduced-resources false
com.deepin.wrap.gnome.metacity alt-tab-thumbnails false
com.deepin.wrap.gnome.metacity edge-tiling true
com.deepin.wrap.gnome.settings-daemon.plugins.gsdwacom active true
com.deepin.wrap.gnome.settings-daemon.plugins.gsdwacom priority 0
com.deepin.dde.watchdog dde-dock true
com.deepin.dde.watchdog dde-desktop true
com.deepin.filemanager.preferences confirm-trash false
com.deepin.filemanager.preferences activation-policy 'ask'
com.deepin.filemanager.preferences show-extension-name true
com.deepin.filemanager.preferences show-zipped-file-in-directory false
com.deepin.filemanager.preferences autoplay-audio-video false
com.deepin.filemanager.preferences show-function-bar true
com.deepin.filemanager.preferences show-thumbnail 'always'
com.deepin.filemanager.preferences allow-delete-immediatly false
com.deepin.filemanager.preferences sidebar-display-mode 'icon-and-text'
com.deepin.filemanager.preferences click-policy 'double'
com.deepin.filemanager.preferences show-hidden-files-in-search-result false
com.deepin.filemanager.preferences thumbnail-size-unit 'MB'
com.deepin.filemanager.preferences confirm-empty-trash true
com.deepin.filemanager.preferences thumbnail-size-limitation uint64 50
com.deepin.filemanager.preferences label-position 'bottom'
com.deepin.filemanager.preferences open-dir-in-new-window false
com.deepin.filemanager.preferences show-hidden-files false
com.deepin.filemanager.preferences display-extra-items false
com.deepin.filemanager.preferences sort-order 'name'
com.deepin.filemanager.preferences show-brief false
com.deepin.filemanager.preferences view 'icon-view'
com.deepin.filemanager.icon-view icon-zoom-level 100
com.deepin.filemanager.icon-view thumbnail-size 64
com.deepin.filemanager.icon-view icon-margin 48
com.deepin.filemanager.list-view columns-order ['label', 'size', 'mtime', 'filetype']
com.deepin.filemanager.list-view icon-zoom-level 100
com.deepin.filemanager.list-view thumbnail-size 32
com.deepin.filemanager.list-view visible-columns ['label', 'size', 'mtime', 'filetype']
com.deepin.wrap.gnome.desktop.background picture-uri 'file:///usr/share/backgrounds/default_background.jpg'
com.deepin.wrap.gnome.desktop.background show-desktop-icons false
com.deepin.wrap.gnome.desktop.background color-shading-type 'solid'
com.deepin.wrap.gnome.desktop.background primary-color '#000000'
com.deepin.wrap.gnome.desktop.background picture-options 'zoom'
com.deepin.wrap.gnome.desktop.background picture-opacity 100
com.deepin.wrap.gnome.desktop.background secondary-color '#023c88'
com.deepin.wrap.gnome.system.location max-accuracy-level 'exact'
com.deepin.wrap.gnome.system.location enabled false
com.deepin.dde.desktop icon-zoom-level 100
com.deepin.dde.desktop first-run true
com.deepin.dde.desktop stickup-grid true
com.deepin.dde.desktop show-computer-icon false
com.deepin.dde.desktop show-trashed-item-number true
com.deepin.dde.desktop icon-default-size '48'
com.deepin.dde.desktop show-home-icon false
com.deepin.dde.desktop auto-arrangement false
com.deepin.dde.desktop show-trash-icon false
com.deepin.dde.mouse natural-scroll false
com.deepin.dde.mouse middle-button-enabled false
com.deepin.dde.mouse locate-pointer false
com.deepin.dde.mouse left-handed false
com.deepin.dde.mouse disable-touchpad false
com.deepin.dde.mouse motion-scaling 10.0
com.deepin.dde.mouse drag-threshold 8
com.deepin.dde.mouse motion-acceleration 1.0
com.deepin.dde.mouse double-click 400
com.deepin.dde.mouse motion-threshold 1.0
com.deepin.wrap.gnome.settings-daemon.plugins.mouse active true
com.deepin.wrap.gnome.settings-daemon.plugins.mouse priority 0
com.deepin.dde.peripherals.mouse drag-threshold 8
com.deepin.dde.peripherals.mouse motion-threshold 1.0
com.deepin.dde.peripherals.mouse middle-button-enabled false
com.deepin.dde.peripherals.mouse motion-acceleration 1.0
com.deepin.dde.peripherals.mouse double-click 400
com.deepin.dde.peripherals.mouse left-handed false
com.deepin.dde.peripherals.mouse locate-pointer false
com.deepin.wrap.gnome.settings-daemon.plugins.datetime active true
com.deepin.wrap.gnome.settings-daemon.plugins.datetime priority 0
com.deepin.dde.daemon launcher true
com.deepin.dde.daemon screenedge true
com.deepin.dde.daemon dock true
com.deepin.dde.daemon power true
com.deepin.dde.daemon clipboard true
com.deepin.dde.daemon network true
com.deepin.dde.daemon systeminfo true
com.deepin.dde.daemon debug false
com.deepin.dde.daemon keybinding true
com.deepin.dde.daemon gesture true
com.deepin.dde.daemon sessionwatcher true
com.deepin.dde.daemon bluetooth true
com.deepin.dde.daemon inputdevices true
com.deepin.dde.daemon mounts true
com.deepin.dde.daemon mpris true
com.deepin.dde.daemon screensaver true
com.deepin.dde.daemon audio true
com.deepin.dde.daemon soundeffect true
com.deepin.dde.daemon appearance true
com.deepin.dde.daemon timedate true
com.deepin.wrap.gnome.settings-daemon.plugins.keyboard active true
com.deepin.wrap.gnome.settings-daemon.plugins.keyboard priority 0
com.deepin.wrap.gnome.settings-daemon.peripherals.touchscreen orientation-lock false
com.deepin.wrap.gnome.settings-daemon.plugins.sound active true
com.deepin.wrap.gnome.settings-daemon.plugins.sound priority 0
com.deepin.wrap.gnome.desktop.media-handling automount-open true
com.deepin.wrap.gnome.desktop.media-handling automount true
com.deepin.wrap.gnome.desktop.media-handling autorun-x-content-start-app ['x-content/unix-software']
com.deepin.wrap.gnome.desktop.media-handling autorun-never false
com.deepin.wrap.gnome.desktop.media-handling autorun-x-content-ignore @as []
com.deepin.wrap.gnome.desktop.media-handling autorun-x-content-open-folder @as []
com.deepin.wrap.gnome.desktop.sound input-feedback-sounds false
com.deepin.wrap.gnome.desktop.sound theme-name 'deepin'
com.deepin.wrap.gnome.desktop.sound event-sounds true
