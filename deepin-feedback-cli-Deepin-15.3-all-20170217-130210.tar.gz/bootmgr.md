
# Boot Files

    /boot
    /boot/System.map-4.9.0-deepin1-amd64
    /boot/config-4.9.0-deepin1-amd64
    /boot/System.map-4.9.0-deepin2-amd64
    /boot/initrd.img-4.9.0-deepin2-amd64
    /boot/vmlinuz-4.9.0-deepin1-amd64
    /boot/vmlinuz-4.2.0-1-amd64
    /boot/config-4.9.0-deepin2-amd64
    /boot/grub
    /boot/grub/i386-pc
    /boot/grub/i386-pc/halt.mod
    /boot/grub/i386-pc/part_acorn.mod
    /boot/grub/i386-pc/ufs1.mod
    /boot/grub/i386-pc/test_blockarg.mod
    /boot/grub/i386-pc/video_bochs.mod
    /boot/grub/i386-pc/cat.mod
    /boot/grub/i386-pc/all_video.mod
    /boot/grub/i386-pc/cs5536.mod
    /boot/grub/i386-pc/fat.mod
    /boot/grub/i386-pc/offsetio.mod
    /boot/grub/i386-pc/command.lst
    /boot/grub/i386-pc/trig.mod
    /boot/grub/i386-pc/minix3.mod
    /boot/grub/i386-pc/usb.mod
    /boot/grub/i386-pc/password_pbkdf2.mod
    /boot/grub/i386-pc/gcry_sha256.mod
    /boot/grub/i386-pc/linux16.mod
    /boot/grub/i386-pc/minicmd.mod
    /boot/grub/i386-pc/memrw.mod
    /boot/grub/i386-pc/reboot.mod
    /boot/grub/i386-pc/newc.mod
    /boot/grub/i386-pc/setjmp_test.mod
    /boot/grub/i386-pc/ufs2.mod
    /boot/grub/i386-pc/usb_keyboard.mod
    /boot/grub/i386-pc/gptsync.mod
    /boot/grub/i386-pc/boot.img
    /boot/grub/i386-pc/sfs.mod
    /boot/grub/i386-pc/functional_test.mod
    /boot/grub/i386-pc/nilfs2.mod
    /boot/grub/i386-pc/progress.mod
    /boot/grub/i386-pc/ntfs.mod
    /boot/grub/i386-pc/datehook.mod
    /boot/grub/i386-pc/configfile.mod
    /boot/grub/i386-pc/pcidump.mod
    /boot/grub/i386-pc/multiboot.mod
    /boot/grub/i386-pc/fs.lst
    /boot/grub/i386-pc/videotest_checksum.mod
    /boot/grub/i386-pc/xzio.mod
    /boot/grub/i386-pc/biosdisk.mod
    /boot/grub/i386-pc/hfspluscomp.mod
    /boot/grub/i386-pc/odc.mod
    /boot/grub/i386-pc/diskfilter.mod
    /boot/grub/i386-pc/gcry_sha1.mod
    /boot/grub/i386-pc/modinfo.sh
    /boot/grub/i386-pc/efiemu64.o
    /boot/grub/i386-pc/macho.mod
    /boot/grub/i386-pc/freedos.mod
    /boot/grub/i386-pc/eval.mod
    /boot/grub/i386-pc/gfxterm_background.mod
    /boot/grub/i386-pc/efiemu.mod
    /boot/grub/i386-pc/vbe.mod
    /boot/grub/i386-pc/verify.mod
    /boot/grub/i386-pc/crypto.lst
    /boot/grub/i386-pc/gcry_cast5.mod
    /boot/grub/i386-pc/aout.mod
    /boot/grub/i386-pc/truecrypt.mod
    /boot/grub/i386-pc/ahci.mod
    /boot/grub/i386-pc/usbserial_ftdi.mod
    /boot/grub/i386-pc/gcry_serpent.mod
    /boot/grub/i386-pc/video_fb.mod
    /boot/grub/i386-pc/luks.mod
    /boot/grub/i386-pc/core.img
    /boot/grub/i386-pc/usbserial_usbdebug.mod
    /boot/grub/i386-pc/gcry_camellia.mod
    /boot/grub/i386-pc/iorw.mod
    /boot/grub/i386-pc/testload.mod
    /boot/grub/i386-pc/terminal.mod
    /boot/grub/i386-pc/bitmap_scale.mod
    /boot/grub/i386-pc/romfs.mod
    /boot/grub/i386-pc/setjmp.mod
    /boot/grub/i386-pc/affs.mod
    /boot/grub/i386-pc/adler32.mod
    /boot/grub/i386-pc/sendkey.mod
    /boot/grub/i386-pc/reiserfs.mod
    /boot/grub/i386-pc/lsmmap.mod
    /boot/grub/i386-pc/mdraid09.mod
    /boot/grub/i386-pc/raid6rec.mod
    /boot/grub/i386-pc/relocator.mod
    /boot/grub/i386-pc/exfat.mod
    /boot/grub/i386-pc/usbserial_common.mod
    /boot/grub/i386-pc/moddep.lst
    /boot/grub/i386-pc/cbtable.mod
    /boot/grub/i386-pc/scsi.mod
    /boot/grub/i386-pc/probe.mod
    /boot/grub/i386-pc/lzopio.mod
    /boot/grub/i386-pc/cbfs.mod
    /boot/grub/i386-pc/cmostest.mod
    /boot/grub/i386-pc/gcry_sha512.mod
    /boot/grub/i386-pc/png.mod
    /boot/grub/i386-pc/fshelp.mod
    /boot/grub/i386-pc/play.mod
    /boot/grub/i386-pc/squash4.mod
    /boot/grub/i386-pc/search_fs_file.mod
    /boot/grub/i386-pc/tar.mod
    /boot/grub/i386-pc/drivemap.mod
    /boot/grub/i386-pc/at_keyboard.mod
    /boot/grub/i386-pc/lvm.mod
    /boot/grub/i386-pc/usbtest.mod
    /boot/grub/i386-pc/acpi.mod
    /boot/grub/i386-pc/linux.mod
    /boot/grub/i386-pc/hello.mod
    /boot/grub/i386-pc/part_dvh.mod
    /boot/grub/i386-pc/blocklist.mod
    /boot/grub/i386-pc/gcry_md5.mod
    /boot/grub/i386-pc/macbless.mod
    /boot/grub/i386-pc/hdparm.mod
    /boot/grub/i386-pc/backtrace.mod
    /boot/grub/i386-pc/hwmatch.mod
    /boot/grub/i386-pc/gcry_blowfish.mod
    /boot/grub/i386-pc/gcry_rijndael.mod
    /boot/grub/i386-pc/exfctest.mod
    /boot/grub/i386-pc/xnu_uuid.mod
    /boot/grub/i386-pc/usbms.mod
    /boot/grub/i386-pc/password.mod
    /boot/grub/i386-pc/minix2.mod
    /boot/grub/i386-pc/file.mod
    /boot/grub/i386-pc/vga_text.mod
    /boot/grub/i386-pc/lspci.mod
    /boot/grub/i386-pc/gettext.mod
    /boot/grub/i386-pc/sleep_test.mod
    /boot/grub/i386-pc/part_msdos.mod
    /boot/grub/i386-pc/testspeed.mod
    /boot/grub/i386-pc/echo.mod
    /boot/grub/i386-pc/cpuid.mod
    /boot/grub/i386-pc/zfs.mod
    /boot/grub/i386-pc/sleep.mod
    /boot/grub/i386-pc/minix_be.mod
    /boot/grub/i386-pc/cbtime.mod
    /boot/grub/i386-pc/videotest.mod
    /boot/grub/i386-pc/xnu.mod
    /boot/grub/i386-pc/legacy_password_test.mod
    /boot/grub/i386-pc/chain.mod
    /boot/grub/i386-pc/pci.mod
    /boot/grub/i386-pc/extcmd.mod
    /boot/grub/i386-pc/part_sun.mod
    /boot/grub/i386-pc/mdraid09_be.mod
    /boot/grub/i386-pc/zfscrypt.mod
    /boot/grub/i386-pc/gcry_idea.mod
    /boot/grub/i386-pc/minix2_be.mod
    /boot/grub/i386-pc/font.mod
    /boot/grub/i386-pc/efiemu32.o
    /boot/grub/i386-pc/ext2.mod
    /boot/grub/i386-pc/spkmodem.mod
    /boot/grub/i386-pc/afs.mod
    /boot/grub/i386-pc/video_colors.mod
    /boot/grub/i386-pc/syslinuxcfg.mod
    /boot/grub/i386-pc/mda_text.mod
    /boot/grub/i386-pc/hfsplus.mod
    /boot/grub/i386-pc/video.lst
    /boot/grub/i386-pc/cpio.mod
    /boot/grub/i386-pc/boot.mod
    /boot/grub/i386-pc/gcry_whirlpool.mod
    /boot/grub/i386-pc/normal.mod
    /boot/grub/i386-pc/part_amiga.mod
    /boot/grub/i386-pc/ufs1_be.mod
    /boot/grub/i386-pc/videoinfo.mod
    /boot/grub/i386-pc/elf.mod
    /boot/grub/i386-pc/bufio.mod
    /boot/grub/i386-pc/btrfs.mod
    /boot/grub/i386-pc/datetime.mod
    /boot/grub/i386-pc/xnu_uuid_test.mod
    /boot/grub/i386-pc/minix.mod
    /boot/grub/i386-pc/signature_test.mod
    /boot/grub/i386-pc/mmap.mod
    /boot/grub/i386-pc/search_fs_uuid.mod
    /boot/grub/i386-pc/archelp.mod
    /boot/grub/i386-pc/parttool.mod
    /boot/grub/i386-pc/http.mod
    /boot/grub/i386-pc/tr.mod
    /boot/grub/i386-pc/gcry_seed.mod
    /boot/grub/i386-pc/gcry_rfc2268.mod
    /boot/grub/i386-pc/pata.mod
    /boot/grub/i386-pc/ohci.mod
    /boot/grub/i386-pc/lsacpi.mod
    /boot/grub/i386-pc/part_apple.mod
    /boot/grub/i386-pc/read.mod
    /boot/grub/i386-pc/tftp.mod
    /boot/grub/i386-pc/jpeg.mod
    /boot/grub/i386-pc/cmp.mod
    /boot/grub/i386-pc/zfsinfo.mod
    /boot/grub/i386-pc/disk.mod
    /boot/grub/i386-pc/hexdump.mod
    /boot/grub/i386-pc/bitmap.mod
    /boot/grub/i386-pc/raid5rec.mod
    /boot/grub/i386-pc/ldm.mod
    /boot/grub/i386-pc/parttool.lst
    /boot/grub/i386-pc/priority_queue.mod
    /boot/grub/i386-pc/part_gpt.mod
    /boot/grub/i386-pc/ntldr.mod
    /boot/grub/i386-pc/date.mod
    /boot/grub/i386-pc/gcry_arcfour.mod
    /boot/grub/i386-pc/lsapm.mod
    /boot/grub/i386-pc/video.mod
    /boot/grub/i386-pc/gcry_tiger.mod
    /boot/grub/i386-pc/memdisk.mod
    /boot/grub/i386-pc/gcry_des.mod
    /boot/grub/i386-pc/geli.mod
    /boot/grub/i386-pc/mpi.mod
    /boot/grub/i386-pc/search.mod
    /boot/grub/i386-pc/search_label.mod
    /boot/grub/i386-pc/terminfo.mod
    /boot/grub/i386-pc/net.mod
    /boot/grub/i386-pc/gfxterm.mod
    /boot/grub/i386-pc/gzio.mod
    /boot/grub/i386-pc/cpio_be.mod
    /boot/grub/i386-pc/part_bsd.mod
    /boot/grub/i386-pc/mdraid1x.mod
    /boot/grub/i386-pc/pbkdf2.mod
    /boot/grub/i386-pc/915resolution.mod
    /boot/grub/i386-pc/gfxterm_menu.mod
    /boot/grub/i386-pc/legacycfg.mod
    /boot/grub/i386-pc/gcry_rsa.mod
    /boot/grub/i386-pc/loadenv.mod
    /boot/grub/i386-pc/crc64.mod
    /boot/grub/i386-pc/gcry_crc.mod
    /boot/grub/i386-pc/minix3_be.mod
    /boot/grub/i386-pc/keylayouts.mod
    /boot/grub/i386-pc/multiboot2.mod
    /boot/grub/i386-pc/usbserial_pl2303.mod
    /boot/grub/i386-pc/ata.mod
    /boot/grub/i386-pc/pbkdf2_test.mod
    /boot/grub/i386-pc/gcry_md4.mod
    /boot/grub/i386-pc/true.mod
    /boot/grub/i386-pc/jfs.mod
    /boot/grub/i386-pc/procfs.mod
    /boot/grub/i386-pc/cmosdump.mod
    /boot/grub/i386-pc/uhci.mod
    /boot/grub/i386-pc/div_test.mod
    /boot/grub/i386-pc/pxe.mod
    /boot/grub/i386-pc/part_dfly.mod
    /boot/grub/i386-pc/gdb.mod
    /boot/grub/i386-pc/plan9.mod
    /boot/grub/i386-pc/partmap.lst
    /boot/grub/i386-pc/video_cirrus.mod
    /boot/grub/i386-pc/xfs.mod
    /boot/grub/i386-pc/part_sunpc.mod
    /boot/grub/i386-pc/hfs.mod
    /boot/grub/i386-pc/cmdline_cat_test.mod
    /boot/grub/i386-pc/gcry_twofish.mod
    /boot/grub/i386-pc/vga.mod
    /boot/grub/i386-pc/dm_nv.mod
    /boot/grub/i386-pc/ls.mod
    /boot/grub/i386-pc/morse.mod
    /boot/grub/i386-pc/gcry_dsa.mod
    /boot/grub/i386-pc/part_plan.mod
    /boot/grub/i386-pc/test.mod
    /boot/grub/i386-pc/cbls.mod
    /boot/grub/i386-pc/cryptodisk.mod
    /boot/grub/i386-pc/msdospart.mod
    /boot/grub/i386-pc/tga.mod
    /boot/grub/i386-pc/nativedisk.mod
    /boot/grub/i386-pc/regexp.mod
    /boot/grub/i386-pc/serial.mod
    /boot/grub/i386-pc/loopback.mod
    /boot/grub/i386-pc/pxechain.mod
    /boot/grub/i386-pc/hashsum.mod
    /boot/grub/i386-pc/time.mod
    /boot/grub/i386-pc/udf.mod
    /boot/grub/i386-pc/help.mod
    /boot/grub/i386-pc/crypto.mod
    /boot/grub/i386-pc/keystatus.mod
    /boot/grub/i386-pc/ehci.mod
    /boot/grub/i386-pc/setpci.mod
    /boot/grub/i386-pc/gfxmenu.mod
    /boot/grub/i386-pc/iso9660.mod
    /boot/grub/i386-pc/cbmemc.mod
    /boot/grub/i386-pc/gcry_rmd160.mod
    /boot/grub/i386-pc/terminal.lst
    /boot/grub/i386-pc/bsd.mod
    /boot/grub/i386-pc/ntfscomp.mod
    /boot/grub/i386-pc/bfs.mod
    /boot/grub/grub.cfg
    /boot/grub/unicode.pf2
    /boot/grub/grubenv
    /boot/grub/locale
    /boot/grub/locale/zh_CN.mo
    /boot/grub/locale/pa.mo
    /boot/grub/locale/fr.mo
    /boot/grub/locale/nl.mo
    /boot/grub/locale/uk.mo
    /boot/grub/locale/lt.mo
    /boot/grub/locale/gl.mo
    /boot/grub/locale/ru.mo
    /boot/grub/locale/sv.mo
    /boot/grub/locale/en@hebrew.mo
    /boot/grub/locale/id.mo
    /boot/grub/locale/zh_TW.mo
    /boot/grub/locale/fi.mo
    /boot/grub/locale/de_CH.mo
    /boot/grub/locale/ja.mo
    /boot/grub/locale/da.mo
    /boot/grub/locale/sl.mo
    /boot/grub/locale/en@quot.mo
    /boot/grub/locale/en@arabic.mo
    /boot/grub/locale/ast.mo
    /boot/grub/locale/it.mo
    /boot/grub/locale/en@greek.mo
    /boot/grub/locale/hu.mo
    /boot/grub/locale/pt_BR.mo
    /boot/grub/locale/vi.mo
    /boot/grub/locale/en@piglatin.mo
    /boot/grub/locale/de@hebrew.mo
    /boot/grub/locale/de.mo
    /boot/grub/locale/eo.mo
    /boot/grub/locale/tr.mo
    /boot/grub/locale/ca.mo
    /boot/grub/locale/es.mo
    /boot/grub/locale/en@cyrillic.mo
    /boot/grub/locale/pl.mo
    /boot/grub/fonts
    /boot/grub/fonts/unicode.pf2
    /boot/grub/themes
    /boot/grub/themes/deepin
    /boot/grub/themes/deepin/terminal_box_w.png
    /boot/grub/themes/deepin/theme.txt
    /boot/grub/themes/deepin/select_s.png
    /boot/grub/themes/deepin/select_n.png
    /boot/grub/themes/deepin/terminal_box_e.png
    /boot/grub/themes/deepin/background_source
    /boot/grub/themes/deepin/terminal_box_nw.png
    /boot/grub/themes/deepin/terminal_box_s.png
    /boot/grub/themes/deepin/background_origin_source
    /boot/grub/themes/deepin/select_e.png
    /boot/grub/themes/deepin/select_c.png
    /boot/grub/themes/deepin/select_se.png
    /boot/grub/themes/deepin/terminal_box_se.png
    /boot/grub/themes/deepin/terminal_box_c.png
    /boot/grub/themes/deepin/select_w.png
    /boot/grub/themes/deepin/select_sw.png
    /boot/grub/themes/deepin/select_ne.png
    /boot/grub/themes/deepin/theme_tpl.json
    /boot/grub/themes/deepin/terminal_box_ne.png
    /boot/grub/themes/deepin/terminal_box_n.png
    /boot/grub/themes/deepin/theme.tpl
    /boot/grub/themes/deepin/background_thumb.png
    /boot/grub/themes/deepin/background.png
    /boot/grub/themes/deepin/select_nw.png
    /boot/grub/themes/deepin/terminal_box_sw.png
    /boot/grub/themes/deepin/unifont-regular-16.pf2
    /boot/System.map-4.2.0-1-amd64
    /boot/vmlinuz-4.4.0-3-deepin-amd64
    /boot/vmlinuz-4.9.0-deepin2-amd64
    /boot/config-4.4.0-3-deepin-amd64
    /boot/initrd.img-4.4.0-3-deepin-amd64
    /boot/config-4.2.0-1-amd64
    /boot/initrd.img-4.2.0-1-amd64
    /boot/initrd.img-4.9.0-deepin1-amd64
    /boot/System.map-4.4.0-3-deepin-amd64

# Boot Info Script

    
    Boot Info Script 0.61      [1 April 2012]
    
    Identifying MBRs...
    Computing Partition Table of /dev/sda...
    Searching sda1 for information... 
    Searching sda2 for information... 
    Searching sda3 for information... 
                      Boot Info Script 0.61      [1 April 2012]
    
    
    ============================= Boot Info Summary: ===============================
    
     => Grub2 (v1.99) is installed in the MBR of /dev/sda and looks at sector 1 of 
        the same hard drive for core.img. core.img is at this location and looks 
        in partition 114 for .
    
    sda1: __________________________________________________________________________
    
        File system:       ext4
        Boot sector type:  -
        Boot sector info: 
        Operating System:  
        Boot files:        
    
    sda2: __________________________________________________________________________
    
        File system:       ext4
        Boot sector type:  -
        Boot sector info: 
        Operating System:  Deepin GNU/Linux 2015
        Boot files:        /boot/grub/grub.cfg /etc/fstab
    
    sda3: __________________________________________________________________________
    
        File system:       ntfs
        Boot sector type:  Windows Vista/7: NTFS
        Boot sector info:  No errors found in the Boot Parameter Block.
        Operating System:  
        Boot files:        
    
    ============================ Drive/Partition Info: =============================
    
    Drive: sda _____________________________________________________________________
    Disk /dev/sda: 465.8 GiB, 500107862016 bytes, 976773168 sectors
    Units: sectors of 1 * 512 = 512 bytes
    Sector size (logical/physical): 512 bytes / 512 bytes
    I/O size (minimum/optimal): 512 bytes / 512 bytes
    Disklabel type: dos
    
    Partition  Boot  Start Sector    End Sector  # of Sectors  Id System
    
    /dev/sda1               2,048   104,856,254   104,854,207  83 Linux
    /dev/sda2         104,872,320   209,712,509   104,840,190  83 Linux
    /dev/sda3         209,728,575   314,568,764   104,840,190   7 NTFS / exFAT / HPFS
    
    
    "blkid" output: ________________________________________________________________
    
    Device           UUID                                   TYPE       LABEL
    
    /dev/sda1        06848116-3c05-4b21-b074-85507f6f136b   ext4       
    /dev/sda2        35ebd624-9703-4247-82f2-c3a23f2f8c64   ext4       
    /dev/sda3        3A6CFD886749837E                       ntfs       
    
    ================================ Mount points: =================================
    
    Device           Mount_Point              Type       Options
    
    /dev/sda1        /home                    ext4       (rw,relatime,data=ordered)
    /dev/sda2        /                        ext4       (rw,relatime,data=ordered)
    
    
    =========================== sda2/boot/grub/grub.cfg: ===========================
    
    --------------------------------------------------------------------------------
    #
    # DO NOT EDIT THIS FILE
    #
    # It is automatically generated by grub-mkconfig using templates
    # from /etc/grub.d and settings from /etc/default/grub
    #
    
    ### BEGIN /etc/grub.d/00_header ###
    if [ -s $prefix/grubenv ]; then
      set have_grubenv=true
      load_env
    fi
    if [ "${next_entry}" ] ; then
       set default="${next_entry}"
       set next_entry=
       save_env next_entry
       set boot_once=true
    else
       set default="Deepin 15.1.1 GNU/Linux"
    fi
    
    if [ x"${feature_menuentry_id}" = xy ]; then
      menuentry_id_option="--id"
    else
      menuentry_id_option=""
    fi
    
    export menuentry_id_option
    
    if [ "${prev_saved_entry}" ]; then
      set saved_entry="${prev_saved_entry}"
      save_env saved_entry
      set prev_saved_entry=
      save_env prev_saved_entry
      set boot_once=true
    fi
    
    function savedefault {
      if [ -z "${boot_once}" ]; then
        saved_entry="${chosen}"
        save_env saved_entry
      fi
    }
    function load_video {
      if [ x$feature_all_video_module = xy ]; then
        insmod all_video
      else
        insmod efi_gop
        insmod efi_uga
        insmod ieee1275_fb
        insmod vbe
        insmod vga
        insmod video_bochs
        insmod video_cirrus
      fi
    }
    
    if [ x$feature_default_font_path = xy ] ; then
       font=unicode
    else
    insmod part_msdos
    insmod ext2
    set root='hd0,msdos2'
    if [ x$feature_platform_search_hint = xy ]; then
      search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    else
      search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    fi
        font="/usr/share/grub/unicode.pf2"
    fi
    
    if loadfont $font ; then
      set gfxmode=1440x900
      load_video
      insmod gfxterm
      set locale_dir=$prefix/locale
      set lang=zh_CN
      insmod gettext
    fi
    terminal_output gfxterm
    insmod part_msdos
    insmod ext2
    set root='hd0,msdos2'
    if [ x$feature_platform_search_hint = xy ]; then
      search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    else
      search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    fi
    insmod gfxmenu
    loadfont ($root)/boot/grub/themes/deepin/unifont-regular-16.pf2
    insmod png
    set theme=($root)/boot/grub/themes/deepin/theme.txt
    export theme
    if [ "${recordfail}" = 1 ] ; then
      set timeout=30
    else
      if [ x$feature_timeout_style = xy ] ; then
        set timeout_style=menu
        set timeout=5
      # Fallback normal timeout code in case the timeout_style feature is
      # unavailable.
      else
        set timeout=5
      fi
    fi
    ### END /etc/grub.d/00_header ###
    
    ### BEGIN /etc/grub.d/05_debian_theme ###
    insmod part_msdos
    insmod ext2
    set root='hd0,msdos2'
    if [ x$feature_platform_search_hint = xy ]; then
      search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    else
      search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    fi
    insmod png
    if background_image /boot/grub/themes/deepin/background.png; then
      true
    else
      set menu_color_normal=cyan/blue
      set menu_color_highlight=white/blue
    fi
    ### END /etc/grub.d/05_debian_theme ###
    
    ### BEGIN /etc/grub.d/10_linux ###
    function gfxmode {
    	set gfxpayload="${1}"
    }
    set linux_gfx_mode=
    export linux_gfx_mode
    menuentry 'Deepin 15.3 GNU/Linux' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-simple-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    	load_video
    	insmod gzio
    	if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    	insmod part_msdos
    	insmod ext2
    	set root='hd0,msdos2'
    	if [ x$feature_platform_search_hint = xy ]; then
    	  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    	else
    	  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    	fi
    	linux	/boot/vmlinuz-4.9.0-deepin2-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro  splash quiet
    	initrd	/boot/initrd.img-4.9.0-deepin2-amd64
    }
    submenu 'Advanced options for Deepin 15.3 GNU/Linux' $menuentry_id_option 'gnulinux-advanced-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    	menuentry 'Deepin 15.3 GNU/Linux，Linux 4.9.0-deepin2-amd64' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.9.0-deepin2-amd64-advanced-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.9.0-deepin2-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro  splash quiet
    		initrd	/boot/initrd.img-4.9.0-deepin2-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux, with Linux 4.9.0-deepin2-amd64 (recovery mode)' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.9.0-deepin2-amd64-recovery-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.9.0-deepin2-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro recovery 
    		initrd	/boot/initrd.img-4.9.0-deepin2-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux，Linux 4.9.0-deepin1-amd64' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.9.0-deepin1-amd64-advanced-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.9.0-deepin1-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro  splash quiet
    		initrd	/boot/initrd.img-4.9.0-deepin1-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux, with Linux 4.9.0-deepin1-amd64 (recovery mode)' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.9.0-deepin1-amd64-recovery-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.9.0-deepin1-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro recovery 
    		initrd	/boot/initrd.img-4.9.0-deepin1-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux，Linux 4.4.0-3-deepin-amd64' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.4.0-3-deepin-amd64-advanced-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.4.0-3-deepin-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro  splash quiet
    		initrd	/boot/initrd.img-4.4.0-3-deepin-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux, with Linux 4.4.0-3-deepin-amd64 (recovery mode)' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.4.0-3-deepin-amd64-recovery-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.4.0-3-deepin-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro recovery 
    		initrd	/boot/initrd.img-4.4.0-3-deepin-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux，Linux 4.2.0-1-amd64' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.2.0-1-amd64-advanced-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.2.0-1-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro  splash quiet
    		initrd	/boot/initrd.img-4.2.0-1-amd64
    	}
    	menuentry 'Deepin 15.3 GNU/Linux, with Linux 4.2.0-1-amd64 (recovery mode)' --class deepin --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-4.2.0-1-amd64-recovery-35ebd624-9703-4247-82f2-c3a23f2f8c64' {
    		load_video
    		insmod gzio
    		if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
    		insmod part_msdos
    		insmod ext2
    		set root='hd0,msdos2'
    		if [ x$feature_platform_search_hint = xy ]; then
    		  search --no-floppy --fs-uuid --set=root --hint-bios=hd0,msdos2 --hint-efi=hd0,msdos2 --hint-baremetal=ahci0,msdos2  35ebd624-9703-4247-82f2-c3a23f2f8c64
    		else
    		  search --no-floppy --fs-uuid --set=root 35ebd624-9703-4247-82f2-c3a23f2f8c64
    		fi
    		linux	/boot/vmlinuz-4.2.0-1-amd64 root=UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64 ro recovery 
    		initrd	/boot/initrd.img-4.2.0-1-amd64
    	}
    }
    
    ### END /etc/grub.d/10_linux ###
    
    ### BEGIN /etc/grub.d/20_linux_xen ###
    
    ### END /etc/grub.d/20_linux_xen ###
    
    ### BEGIN /etc/grub.d/30_os-prober ###
    ### END /etc/grub.d/30_os-prober ###
    
    ### BEGIN /etc/grub.d/30_uefi-firmware ###
    ### END /etc/grub.d/30_uefi-firmware ###
    
    ### BEGIN /etc/grub.d/40_custom ###
    # This file provides an easy way to add custom menu entries.  Simply type the
    # menu entries you want to add after this comment.  Be careful not to change
    # the 'exec tail' line above.
    ### END /etc/grub.d/40_custom ###
    
    ### BEGIN /etc/grub.d/41_custom ###
    if [ -f  ${config_directory}/custom.cfg ]; then
      source ${config_directory}/custom.cfg
    elif [ -z "${config_directory}" -a -f  $prefix/custom.cfg ]; then
      source $prefix/custom.cfg;
    fi
    ### END /etc/grub.d/41_custom ###
    --------------------------------------------------------------------------------
    
    =============================== sda2/etc/fstab: ================================
    
    --------------------------------------------------------------------------------
    # /dev/sda2
    UUID=35ebd624-9703-4247-82f2-c3a23f2f8c64	/         	ext4      	rw,relatime,data=ordered	0 1
    
    # /dev/sda1
    UUID=06848116-3c05-4b21-b074-85507f6f136b	/home     	ext4      	rw,relatime,data=ordered	0 2
    
    --------------------------------------------------------------------------------
    
    =================== sda2: Location of files loaded by Grub: ====================
    
               GiB - GB             File                                 Fragment(s)
    
    
    =============================== StdErr Messages: ===============================
    
    cat: /tmp/BootInfo-xP2yMryv/Tmp_Log: 没有那个文件或目录
    mdadm: No arrays found in config file or automatically
