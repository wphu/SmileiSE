
# DPKG Packages

    期望状态=未知(u)/安装(i)/删除(r)/清除(p)/保持(h)
    | 状态=未安装(n)/已安装(i)/仅存配置(c)/仅解压缩(U)/配置失败(F)/不完全安装(H)/触发器等待(W)/触发器未决(T)
    |/ 错误?=(无)/须重装(R) (状态，错误：大写=故障)
    ||/ 名称                                      版本                              体系结构     描述
    +++-=========================================-=================================-============-==========================================================================================================
    ii  360safeforcnos                            3.0.0.71                          amd64        360 safe for cn os
    ii  accountsservice                           0.6.40-3                          amd64        query and manipulate user account information
    ii  acl                                       2.2.52-3                          amd64        Access control list utilities
    ii  acpid                                     1:2.0.28-1                        amd64        Advanced Configuration and Power Interface event daemon
    ii  adduser                                   3.115                             all          add and remove users and groups
    ii  adwaita-icon-theme                        3.22.0-1                          all          default icon theme of GNOME
    ii  aglfn                                     1.7-3                             all          Adobe Glyph List For New Fonts
    ii  alsa-utils                                1.1.2-1                           amd64        Utilities for configuring and using ALSA
    ii  android-studio                            2.1.2.0~r1                        all          Android Studio.
    ii  android-udev-rules                        0.0+git20160805                   all          Udev rules to connect Android devices to your linux box
    ii  anydesk                                   2.3.6-1                           amd64        the world's fastest remote desktop application
    ii  apache2                                   2.4.23-5                          amd64        Apache HTTP Server
    ii  apache2-bin                               2.4.23-5                          amd64        Apache HTTP Server (modules and other binary files)
    ii  apache2-data                              2.4.23-5                          all          Apache HTTP Server (common files)
    ii  apache2-utils                             2.4.23-5                          amd64        Apache HTTP Server (utility programs for web servers)
    ii  apps.com.evernote                         7.4.2-3                           all          For everything you’ll do, Evernote is the workspace to get it done.
    ii  apps.com.google.hangouts                  0.8.12                            all          google hangouts.
    ii  apps.com.google.map                       0.8.12                            all          google map server.
    ii  apps.com.hwadzanebook                     2.1.7                             all          Hwa Dzan Society is a platform for presenting information and live-broadcasting contents from HwaDzan.com.
    ii  apps.com.openapp                          3.2.9-3                           all          open course app from 163
    ii  apps.com.qq.im.light:i386                 7.9.14308deepin0                  i386         Tencent Light QQ Client on CrossOver Deepin
    ii  apps.com.wechat.web                       0.8.12                            all          WeChat web.
    ii  apps.com.xunlei.mini:i386                 1.5.3.288deepin3                  i386         Thunder Mini on CrossOver Deepin
    ii  apps.com.youdao.note                      0.8.12                            all          Youdao Note
    ii  apt                                       1.4~beta2+deepin                  amd64        commandline package manager
    ii  apt-transport-https                       1.4~beta2+deepin                  amd64        https download transport for APT
    ii  apt-utils                                 1.4~beta2+deepin                  amd64        package management related utility programs
    ii  aptdaemon                                 1.1.1+bzr982-1                    all          transaction based package management service
    ii  aptdaemon-data                            1.1.1+bzr982-1                    all          data files for clients
    ii  aptitude                                  0.8.3-1+b1                        amd64        terminal-based package manager
    ii  aptitude-common                           0.8.3-1                           all          architecture independent files for the aptitude package manager
    ii  archon-integration                        0.0~20150528                      amd64        <insert up to 60 chars description>
    ii  aspell                                    0.60.7~20110707-3+b1              amd64        GNU Aspell spell-checker
    ii  aspell-en                                 2016.06.26-0-0.1                  all          English dictionary for GNU Aspell
    ii  at-spi2-core                              2.22.0-3                          amd64        Assistive Technology Service Provider Interface (dbus core)
    ii  atom                                      1.12.8-1                          amd64        Atom text editor from GitHub
    ii  attr                                      1:2.4.47-2                        amd64        Utilities for manipulating filesystem extended attributes
    ii  authbind                                  2.1.1+nmu1                        amd64        Allows non-root programs to bind() to low ports
    ii  autoconf                                  2.69-10                           all          automatic configure script builder
    ii  automake                                  1:1.15-5                          all          Tool for generating GNU Standards-compliant Makefiles
    ii  autopoint                                 0.19.8.1-1                        all          The autopoint program from GNU gettext
    ii  autotools-dev                             20160430.1                        all          Update infrastructure for config.{guess,sub} files
    ii  avahi-daemon                              0.6.32-1                          amd64        Avahi mDNS/DNS-SD daemon
    rc  ax25-node                                 0.3.2-7.4                         amd64        Amateur Packet Radio Node program
    ii  bamfdaemon                                0.2.118-1.3                       amd64        Window matching library - daemon
    ii  base-files                                2015.5                            amd64        Debian base system miscellaneous files
    ii  base-passwd                               3.5.40                            amd64        Debian base system master password and group files
    ii  bash                                      4.4-1                             amd64        GNU Bourne Again SHell
    ii  bash-completion                           1:2.1-4.3                         all          programmable completion for the bash shell
    ii  bbswitch-dkms                             0.8-4                             amd64        Interface for toggling the power on NVIDIA Optimus video cards
    ii  bc                                        1.06.95-9+b2                      amd64        GNU bc arbitrary precision calculator language
    ii  bearychat                                 1.2.7~20160831                    amd64        Time for a new working style ————bearychat.
    ii  bind9-host                                1:9.10.3.dfsg.P4-10.1             amd64        Version of 'host' bundled with BIND 9.X
    ii  binfmt-support                            2.1.6-1                           amd64        Support for extra binary formats
    ii  binutils                                  2.27.51.20161105-2                amd64        GNU assembler, linker and binary utilities
    ii  bison                                     2:3.0.4.dfsg-1                    amd64        YACC-compatible parser generator
    ii  blt                                       2.5.3+dfsg-3                      amd64        graphics extension library for Tcl/Tk - run-time
    ii  bluez                                     5.43-1                            amd64        Bluetooth tools and daemons
    ii  bluez-firmware                            1.2-3deepin                       all          Firmware for Bluetooth devices
    ii  blur-effect                               1.1.2+r17                         amd64        <insert up to 60 chars description>
    ii  boot-info-script                          0.61-2                            all          inspect boot environment
    ii  bsdmainutils                              9.0.12                            amd64        collection of more utilities from FreeBSD
    ii  bsdutils                                  1:2.28.2-1                        amd64        basic utilities from 4.4BSD-Lite
    ii  build-essential                           12.2                              amd64        Informational list of build-essential packages
    ii  busybox                                   1:1.22.0-19                       amd64        Tiny utilities for small and embedded systems
    ii  byacc                                     20140715-1                        amd64        public domain Berkeley LALR Yacc parser generator
    ii  bzip2                                     1.0.6-8                           amd64        high-quality block-sorting file compressor - utilities
    ii  bzip2-doc                                 1.0.6-8                           all          high-quality block-sorting file compressor - documentation
    ii  ca-certificates                           20161102                          all          Common CA certificates
    ii  ca-certificates-java                      20161107                          all          Common CA certificates (JKS keystore)
    ii  cakephp                                   2.8.5-1                           all          rapid application development framework for PHP
    ii  cakephp-instaweb                          0.5-2                             all          Development webserver for CakePHP applications
    ii  cakephp-scripts                           2.8.5-1                           all          rapid application development framework for PHP (scripts)
    ii  cgroupfs-mount                            1.3                               all          Light-weight package to set up cgroupfs mounts
    ii  chkconfig                                 11.4.54.60.1debian1               all          system tool to enable or disable system services
    rc  chmsee                                    1.3.0-3                           amd64        A chm file viewer written in GTK+
    rc  chromium                                  52.0.2743.116-2                   amd64        web browser
    ii  clang                                     1:3.8-34                          amd64        C, C++ and Objective-C compiler (LLVM based)
    ii  clang-3.8                                 1:3.8.1-15                        amd64        C, C++ and Objective-C compiler (LLVM based)
    ii  cmake                                     3.6.2-2                           amd64        cross-platform, open-source make system
    ii  cmake-data                                3.6.2-2                           all          CMake data files (modules, templates and documentation)
    ii  coinor-libcbc3                            2.8.12-1+b1                       amd64        Coin-or branch-and-cut mixed integer programming solver (shared libraries)
    ii  coinor-libcgl1                            0.58.9-1+b1                       amd64        COIN-OR Cut Generation Library
    ii  coinor-libclp1                            1.15.10-3                         amd64        Coin-or linear programming solver (shared libraries)
    ii  coinor-libcoinmp1v5:amd64                 1.7.6+dfsg1-2                     amd64        Simple C API for COIN-OR Solvers Clp and Cbc -- library
    ii  coinor-libcoinutils3v5                    2.9.15-4                          amd64        Coin-or collection of utility classes (binaries and libraries)
    ii  coinor-libosi1v5                          0.106.9-2+b1                      amd64        COIN-OR Open Solver Interface
    rc  conky-std                                 1.10.2-1                          amd64        highly configurable system monitor (default version)
    ii  containerd                                0.2.1~ds1-3                       amd64        daemon to control runC
    ii  coreutils                                 8.25-2                            amd64        GNU core utilities
    ii  cpio                                      2.11+dfsg-5                       amd64        GNU cpio -- a program to manage archives of files
    ii  cpp                                       4:6.1.1-1                         amd64        GNU C preprocessor (cpp)
    ii  cpp-4.9                                   4.9.4-2                           amd64        GNU C preprocessor
    ii  cpp-5                                     5.4.1-3                           amd64        GNU C preprocessor
    ii  cpp-6                                     6.2.0-11                          amd64        GNU C preprocessor
    ii  cron                                      3.0pl1-128                        amd64        process scheduling daemon
    rc  crossover:i386                            14.1.11-1                         i386         Run Windows applications like MS Office
    ii  crossover-15:i386                         15.0.5-1                          i386         Run Windows applications like MS Office
    ii  csh                                       20110502-2.2                      amd64        Shell with C-like syntax
    ii  cups                                      2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD/driver support, web interface
    ii  cups-client                               2.2.1-2                           amd64        Common UNIX Printing System(tm) - client programs (SysV)
    ii  cups-common                               2.2.1-2                           all          Common UNIX Printing System(tm) - common files
    ii  cups-core-drivers                         2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD-less printing
    ii  cups-daemon                               2.2.1-2                           amd64        Common UNIX Printing System(tm) - daemon
    ii  cups-filters                              1.11.6-1+b1                       amd64        OpenPrinting CUPS Filters - Main Package
    ii  cups-filters-core-drivers                 1.11.6-1+b1                       amd64        OpenPrinting CUPS Filters - PPD-less printing
    ii  cups-ppdc                                 2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD manipulation utilities
    ii  cups-server-common                        2.2.1-2                           all          Common UNIX Printing System(tm) - server common files
    ii  curl                                      7.50.1-1                          amd64        command line tool for transferring data with URL syntax
    ii  dash                                      0.5.8-2.3                         amd64        POSIX-compliant shell
    ii  dbeaver-ce                                3.6.7                             amd64        DBeaver
    ii  dbus                                      1.10.12-1                         amd64        simple interprocess messaging system (daemon and utilities)
    ii  dbus-user-session                         1.10.12-1                         all          simple interprocess messaging system (systemd --user integration)
    ii  dbus-x11                                  1.10.12-1                         amd64        simple interprocess messaging system (X11 deps)
    ii  dconf-gsettings-backend:amd64             0.26.0-2                          amd64        simple configuration storage system - GSettings back-end
    ii  dconf-service                             0.26.0-2                          amd64        simple configuration storage system - D-Bus service
    ii  dde-account-faces                         1.0.10-1                          all          Deepin Account face Images
    ii  dde-api                                   3.0.15-2                          amd64        Go-lang bingdings for dde-daemon
    ii  dde-calendar                              1.0.2-2                           amd64        <insert up to 60 chars description>
    ii  dde-control-center                        3.0.23-1                          amd64        New control center for linux deepin
    ii  dde-daemon                                3.0.24-5                          amd64        daemon handling the DDE session settings
    ii  dde-desktop                               3.0.15-3                          amd64        deepin desktop-environment - desktop module
    ii  dde-dock                                  4.0.5-1                           amd64        deepin desktop-environment - dock module
    ii  dde-file-manager                          1.3.8-1                           amd64        File manager front end of Deepin OS
    ii  dde-help                                  15.3.1-1                          all          Help files for dde
    ii  dde-help-common                           15.3.1-1                          all          common files .
    ii  dde-help-enus                             15.3.1-1                          all          English (en_US) Help files for dde
    ii  dde-help-zhcn                             15.3.1-1                          all          Chinese Simplified (zh_CN) Help files for dde
    ii  dde-launcher                              4.0.3-1                           amd64        deepin desktop-environment - launcher module
    ii  dde-qml-dbus-factory                      3.0.6-1                           amd64        Go-lang dbus gen QML for dlib
    ii  dde-qt5integration                        0.0.6-1                           amd64        Qt platform theme integration plugins for DDE
    ii  dde-session-ui                            3.0.22-1                          amd64        deepin desktop-environment - dde-session-ui module
    ii  debconf                                   1.5.59                            all          Debian configuration management system
    ii  debconf-i18n                              1.5.59                            all          full internationalization support for debconf
    ii  debconf-utils                             1.5.59                            all          debconf utilities
    ii  debhelper                                 10.2.2                            all          helper programs for debian/rules
    ii  debian-archive-keyring                    2014.3                            all          GnuPG archive keys of the Debian archive
    ii  debianutils                               4.8                               amd64        Miscellaneous utilities specific to Debian
    ii  deepin-appstore                           4.0.9-2                           amd64        Deepin App Store
    ii  deepin-appstore-data                      4.0.9-2                           all          deepin appstore data file.
    ii  deepin-archon                             1.0.1                             amd64        ARChon,run apk on linux.
    ii  deepin-artwork                            2015.3                            all          Deepin Artwork
    ii  deepin-artwork-themes                     15.12.3-1                         all          Deepin artwork themes
    ii  deepin-boot-maker                         1.1.3-1                           amd64        Deepin Boot Maker is help for user to create a boot usb stick quick and easy
    ii  deepin-crossover-helper:i386              1.0deepin0                        i386         Deepin CrossOver
    ii  deepin-crosswalk                          18.46.461.0-1                     amd64        Runtime for hosted and packaged apps
    rc  deepin-cursor-theme                       2014~4-2                          all          Deepin Cursor Icons
    ii  deepin-default-settings                   2016.8.25-1                       all          Deepin default settings
    ii  deepin-default-settings-tuning            2016.8.25-1                       all          Deepin default settings tuning
    ii  deepin-desktop-base                       2016.11.28-1                      all          Base files for Deepin Desktop
    ii  deepin-desktop-schemas                    3.0.12-1                          amd64        GSettings deepin desktop-wide schemas
    ii  deepin-download-service                   1.0.1-1                           amd64        deepin download service
    ii  deepin-feedback                           1.0.8-3                           amd64        report crash information to deepin for debugging
    ii  deepin-file-manager-backend               0.1.16-1                          amd64        deepin file manager backend
    ii  deepin-gettext-tools                      1.0.1-2                           amd64        Deepin Internationalization utilities
    ii  deepin-gtk-theme                          15.12.8-1                         all          Deepin Gtk Themes
    ii  deepin-icon-theme                         15.12.32-1                        all          Deepin Icons
    ii  deepin-image-viewer                       1.2.1-1                           amd64        Deepin Image Viewer is the Image Viewer for Deepin Desktop Environment(DDE)
    ii  deepin-kernel-update                      1.4                               all          help deepin user to update kernel
    ii  deepin-keyring                            2015.10.09                        all          GnuPG keys of the Deepin archive
    ii  deepin-manual                             1.0.5-1                           all          Deepin Manual
    ii  deepin-menu                               3.0.6-1                           amd64        Deepin menu service for building beautiful menus.
    ii  deepin-metacity                           3.20.6-1                          amd64        lightweight GTK+ window manager
    ii  deepin-metacity-common                    3.20.6-1                          all          shared files for the Metacity window manager
    ii  deepin-movie                              2.2.10-1                          all          deepin movie for linuxdeepin desktop environment
    ii  deepin-music                              3.0.1                             amd64        Awesome music player with brilliant and tweakful UI
    ii  deepin-mutter-common                      3.20.6-2                          all          shared files for the Mutter window manager
    ii  deepin-nautilus-properties                3.14.3-1                          amd64        Nautilus properties plugin for deepin desktop environment
    ii  deepin-notifications                      2.3.8-1                           amd64        system notifications for linuxdeepin desktop environment
    ii  deepin-qml-widgets                        2.3.4-1                           amd64        Deepin QML widgets
    ii  deepin-remote-assistance                  1.0.10-1                          amd64        Deepin Remote Assistance
    ii  deepin-screenshot                         3.1.10-1                          amd64        Advanced screen shoting tool
    ii  deepin-sleep                              2.2-1                             all          deepin sleep optimize setting.
    ii  deepin-social-sharing                     1.1.4-1                           all          System-wide social sharing service for Deepin!
    rc  deepin-software-center                    3.0.60-2                          all          Software center for linux deepin
    ii  deepin-software-center-data               3.0.50                            all          Software center data for linux deepin
    ii  deepin-sound-theme                        15.10.01                          all          deepin sound theme
    ii  deepin-terminal                           2.1.7-1                           amd64        Deepin terminal, it sharpens your focus in the world of command line!
    ii  deepin-ui                                 1.0.5-1                           all          LinuxDeepin UI libs
    ii  deepin-wallpapers                         1.3-2                             all          Default wallpapers for dde
    ii  deepin-wm                                 1.2-2                             amd64        Deepin Window Manager
    ii  deepin-wm-switcher                        1.1.0-1                           amd64        deepin window manager monitoring and auto-switching service
    ii  deepinop                                  2.2-1                             all          deepin io optimize
    ii  deepinwine-aliwangwang:i386               8.10.24deepin1                    i386         AliWangWang Client on CrossOver Deepin
    rc  deepinwine-mailmaster:i386                1.1.1.20deepin1                   i386         NetEase MailMaster on CrossOver Deepin
    ii  deepinwine-qq:i386                        7.1.14522deepin5                  i386         Tencent QQ Client on CrossOver Deepin
    ii  default-jdk                               2:1.8-57                          amd64        Standard Java or Java compatible Development Kit
    ii  default-jdk-headless                      2:1.8-57                          amd64        Standard Java or Java compatible Development Kit (headless)
    ii  default-jre                               2:1.8-57                          amd64        Standard Java or Java compatible Runtime
    ii  default-jre-headless                      2:1.8-57                          amd64        Standard Java or Java compatible Runtime (headless)
    ii  desktop-file-utils                        0.23-1                            amd64        Utilities for .desktop files
    ii  dh-autoreconf                             12                                all          debhelper add-on to call autoreconf and clean up after the build
    ii  dh-python                                 2.20160818                        all          Debian helper tools for packaging Python libraries and applications
    ii  dh-strip-nondeterminism                   0.028-1                           all          file non-deterministic information stripper — Debhelper add-on
    ii  dictionaries-common                       1.27.2                            all          spelling dictionaries - common utilities
    ii  diffstat                                  1.61-1                            amd64        produces graph of changes introduced by a diff file
    ii  diffutils                                 1:3.5-1                           amd64        File comparison utilities
    ii  dirmngr                                   2.1.15-8                          amd64        GNU privacy guard - network certificate management service
    ii  distro-info-data                          0.32                              all          information about the distributions' releases (data files)
    ii  dkms                                      2.2.0.3-3+deepin                  all          Dynamic Kernel Module Support Framework
    ii  dleyna-renderer                           0.4.0-1                           amd64        DBus service to interact with DLNA Digital Media Renderers
    ii  dmeventd                                  2:1.02.133-1                      amd64        Linux Kernel Device Mapper event daemon
    ii  dmidecode                                 3.0-4                             amd64        SMBIOS/DMI table decoder
    ii  dmsetup                                   2:1.02.133-1                      amd64        Linux Kernel Device Mapper userspace library
    ii  dmz-cursor-theme                          0.4.4                             all          Style neutral, scalable cursor theme
    rc  docker                                    1.5-1                             amd64        System tray for KDE3/GNOME2 docklet applications
    ii  docker.io                                 1.11.2~ds1-6                      amd64        Linux container runtime
    ii  docutils-common                           0.12+dfsg-2                       all          text processing system for reStructuredText - common data
    ii  docutils-doc                              0.12+dfsg-2                       all          text processing system for reStructuredText - documentation
    ii  dosfstools                                4.0-2                             amd64        utilities for making and checking MS-DOS FAT filesystems
    ii  dpkg                                      1.18.13                           amd64        Debian package management system
    ii  dpkg-dev                                  1.18.13                           all          Debian package development tools
    ii  dra-chromium                              1.2.4.1                           amd64        Customized chromium used in Deepin Remote Assistance
    ii  e2fslibs:amd64                            1.43.3-1                          amd64        ext2/ext3/ext4 file system libraries
    ii  e2fsprogs                                 1.43.3-1                          amd64        ext2/ext3/ext4 file system utilities
    ii  eclipse-cpp                               4.6                               amd64        eclipse neon for cpp
    ii  eclipse-jee                               4.6                               amd64        eclipse neon for jee
    ii  efibootmgr                                14-1                              amd64        Interact with the EFI Boot Manager
    ii  eject                                     2.1.5+deb1+cvs20081104-13.1       amd64        ejects CDs and operates CD-Changers under Linux
    ii  emacsen-common                            2.0.8                             all          Common facilities for all emacsen
    ii  equalx                                    0.7.1-4                           amd64        graphical editor for LaTeX equations
    ii  evince                                    3.22.1-2                          amd64        Document (PostScript, PDF) viewer
    ii  evince-common                             3.22.1-2                          all          Document (PostScript, PDF) viewer - common files
    ii  expect                                    5.45-7                            amd64        Automates interactive applications
    ii  ext3grep                                  0.10.2-3+b1                       amd64        tool to help recover deleted files on ext3 filesystems
    ii  fakeroot                                  1.21-2                            amd64        tool for simulating superuser privileges
    ii  fcitx                                     1:4.2.9.1-11deepin                all          Flexible Input Method Framework
    ii  fcitx-bin                                 1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - essential binaries
    ii  fcitx-config-common                       0.4.8-4                           all          graphic Fcitx configuration tool - common files
    ii  fcitx-config-gtk                          0.4.8-4                           amd64        graphic Fcitx configuration tool - Gtk+ 3 version
    ii  fcitx-data                                1:4.2.9.1-11deepin                all          Flexible Input Method Framework - essential data files
    ii  fcitx-frontend-gtk2                       1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - GTK+ 2 IM Module frontend
    ii  fcitx-frontend-gtk3                       1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - GTK+ 3 IM Module frontend
    ii  fcitx-frontend-qt4                        1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - Qt4 IM Module frontend
    ii  fcitx-frontend-qt5:amd64                  1.0.5-3                           amd64        Free Chinese Input Toy of X - Qt5 IM Module frontend
    ii  fcitx-libs                                1:4.2.9.1-11deepin                all          transitional dummy package
    ii  fcitx-libs-gclient                        1:4.2.9.1-11deepin                all          transitional dummy package
    ii  fcitx-libs-qt5                            1.0.5-3                           all          transitional dummy package
    ii  fcitx-module-dbus                         1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - D-Bus module and IPC frontend
    ii  fcitx-module-kimpanel                     1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - KIMPanel protocol module
    ii  fcitx-module-lua                          1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - Lua module
    ii  fcitx-module-x11                          1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - X11 module and XIM frontend
    ii  fcitx-modules                             1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - core modules
    ii  fcitx-sogoupinyin-uk                      0.1.0                             all          Fcitx wrapper for Sogou Pinyin
    ii  fcitx-table                               1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - table engine
    ii  fcitx-table-wubi-large                    0.3.7-3                           all          Flexible Input Method Framework - Wubi-Large table
    ii  ffmpeg                                    7:3.2.2-1                         amd64        Tools for transcoding, streaming and playing of multimedia files
    ii  file                                      1:5.29-1                          amd64        Recognize the type of data in a file using "magic" numbers
    ii  file-roller                               3.20.2-5                          amd64        archive manager for GNOME
    ii  filezilla                                 3.21.0-2                          amd64        Full-featured graphical FTP/FTPS/SFTP client
    ii  filezilla-common                          3.21.0-2                          all          Architecture independent files for filezilla
    ii  findutils                                 4.6.0+git+20160703-2              amd64        utilities for finding files--find, xargs
    ii  firebird2.5-common                        2.5.6.27020.ds4-1                 all          common files for firebird 2.5 servers and clients
    ii  firebird2.5-common-doc                    2.5.6.27020.ds4-1                 all          copyright, licensing and changelogs of firebird2.5
    ii  firebird2.5-server-common                 2.5.6.27020.ds4-1+b1              amd64        common files for firebird 2.5 servers
    ii  firebird3.0-common                        3.0.1.32609.ds4-8                 all          common files for firebird 3.0 server, client and utilities
    ii  firebird3.0-common-doc                    3.0.1.32609.ds4-8                 all          copyright, licensing and changelogs of firebird3.0
    rc  firefox                                   48.0-1                            amd64        Mozilla Firefox web browser
    ii  firmware-adi                              0.44                              all          Binary firmware for Analog Devices Inc. DSL modem chips
    ii  firmware-atheros                          20161130-2                        all          Binary firmware for Atheros wireless cards
    ii  firmware-brcm80211                        20161130-2                        all          Binary firmware for Broadcom 802.11 wireless cards
    ii  firmware-crystalhd                        0.0~git20120110.fdd2f19-1         all          Crystal HD Video Decoder (firmware)
    ii  firmware-intelwimax                       20161130-2                        all          Binary firmware for Intel WiMAX Connection
    ii  firmware-iwlwifi                          20161130-2                        all          Binary firmware for Intel Wireless cards
    ii  firmware-linux-free                       3.4                               all          Binary firmware for various drivers in the Linux kernel
    ii  firmware-myricom                          20161130-2                        all          Binary firmware for Myri-10G Ethernet adapters
    ii  firmware-netxen                           20161130-2                        all          Binary firmware for QLogic Intelligent Ethernet (3000 and 3100 Series)
    ii  firmware-qlogic                           20161130-2                        all          Binary firmware for QLogic HBAs
    ii  firmware-ralink                           0.44                              all          Binary firmware for Ralink wireless cards
    ii  firmware-realtek                          20161130-2                        all          Binary firmware for Realtek wired/wifi/BT adapters
    ii  firmware-samsung                          20161130-2                        all          Binary firmware for Samsung MFC video codecs
    ii  firmware-zd1211                           1:1.5-4                           all          binary firmware for the zd1211rw wireless driver
    ii  flashplugin-nonfree                       1:3.7                             amd64        Adobe Flash Player - browser plugin
    ii  flattr-icon-theme                         1.3.1                             all          Falttr icon theme
    ii  flex                                      2.6.1-1+b1                        amd64        fast lexical analyzer generator
    ii  fontconfig                                2.12.1-1                          amd64        generic font configuration library - support binaries
    ii  fontconfig-config                         2.12.1-1                          all          generic font configuration library - configuration
    ii  fonts-adobe-source-han-sans-cn            1.004.is.1.004-1                  all          Adobe Source Han Sans Subset OTF - Simplified Chinese OpenType/CFF fonts
    ii  fonts-arphic-uming                        0.2.20080216.2-7                  all          "AR PL UMing" Chinese Unicode TrueType font collection Mingti style
    ii  fonts-dejavu                              2.37-1                            all          metapackage to pull in fonts-dejavu-core and fonts-dejavu-extra
    ii  fonts-dejavu-core                         2.37-1                            all          Vera font family derivate with additional characters
    ii  fonts-dejavu-extra                        2.37-1                            all          Vera font family derivate with additional characters (extra variants)
    rc  fonts-droid                               1:4.4.4r2-8                       all          handheld device font with extensive style and language support
    ii  fonts-droid-fallback                      1:6.0.1r16-1                      all          handheld device font with extensive style and language support (fallback)
    ii  fonts-elusive-icons                       2.0.0-1                           all          the iconic font and CSS framework
    ii  fonts-font-awesome                        4.6.3~dfsg-1                      all          iconic font designed for use with Twitter Bootstrap
    ii  fonts-freefont-ttf                        20120503-4                        all          Freefont Serif, Sans and Mono Truetype fonts
    ii  fonts-hanazono                            20160201-1                        all          Japanese TrueType mincho font by KAGE system and FontForge
    ii  fonts-lato                                2.0-1                             all          sans-serif typeface family font
    ii  fonts-liberation                          1:1.07.4-2                        all          Fonts with the same metrics as Times, Arial and Courier
    ii  fonts-lmodern                             2.004.5-3                         all          OpenType fonts based on Computer Modern
    ii  fonts-lyx                                 2.2.0-2                           all          TrueType versions of some TeX fonts used by LyX
    ii  fonts-mathjax                             2.7.0-1                           all          JavaScript display engine for LaTeX and MathML (fonts)
    ii  fonts-noto                                20160724-3                        all          metapackage to pull in all Noto fonts
    ii  fonts-noto-cjk                            1:1.004+repack2-1                 all          "No Tofu" font families with large Unicode coverage (CJK)
    ii  fonts-noto-hinted                         20160724-3                        all          "No Tofu" font families with large Unicode coverage (hinted)
    ii  fonts-noto-mono                           20160724-3                        all          "No Tofu" monospaced font family with large Unicode coverage
    ii  fonts-noto-unhinted                       20160724-3                        all          "No Tofu" font families with large Unicode coverage (unhinted)
    ii  fonts-opensymbol                          2:102.7+LibO5.1.5~rc2-1           all          OpenSymbol TrueType font
    ii  fonts-sil-gentium                         20081126:1.03-1                   all          extended Unicode Latin font ("a typeface for the nations")
    ii  fonts-sil-gentium-basic                   1.1-7                             all          smart Unicode font families (Basic and Book Basic) based on Gentium
    ii  fonts-texgyre                             20160520-1                        all          OpenType fonts based on URW Fonts
    ii  fonts-wqy-microhei                        0.2.0-beta-2                      all          Sans-serif style CJK font derived from Droid
    ii  foxitreader                               2.1.0805                          amd64        The best choice to read PDF documents.
    ii  freecad                                   0.16+dfsg2-1+b1                   amd64        Extensible Open Source CAx program (alpha)
    ii  freeglut3:amd64                           2.8.1-3                           amd64        OpenGL Utility Toolkit
    ii  friendly-recovery                         0.2.34.1                          all          Make recovery boot mode more user-friendly
    ii  ftp                                       0.17-33+b1                        amd64        classical file transfer client
    ii  fuse                                      2.9.7-1                           amd64        Filesystem in Userspace
    ii  g++                                       4:6.1.1-1                         amd64        GNU C++ compiler
    ii  g++-5                                     5.4.1-3                           amd64        GNU C++ compiler
    ii  g++-6                                     6.2.0-11                          amd64        GNU C++ compiler
    ii  gawk                                      1:4.1.3+dfsg-0.1+b1               amd64        GNU awk, a pattern scanning and processing language
    ii  gcc                                       4:6.1.1-1                         amd64        GNU C compiler
    ii  gcc-4.8-base:amd64                        4.8.5-4                           amd64        GCC, the GNU Compiler Collection (base package)
    ii  gcc-4.9                                   4.9.4-2                           amd64        GNU C compiler
    ii  gcc-4.9-base:amd64                        4.9.4-2                           amd64        GCC, the GNU Compiler Collection (base package)
    ii  gcc-5                                     5.4.1-3                           amd64        GNU C compiler
    ii  gcc-5-base:amd64                          5.4.1-3                           amd64        GCC, the GNU Compiler Collection (base package)
    ii  gcc-5-base:i386                           5.4.1-3                           i386         GCC, the GNU Compiler Collection (base package)
    ii  gcc-6                                     6.2.0-11                          amd64        GNU C compiler
    ii  gcc-6-base:amd64                          6.2.0-11                          amd64        GCC, the GNU Compiler Collection (base package)
    ii  gcc-6-base:i386                           6.2.0-11                          i386         GCC, the GNU Compiler Collection (base package)
    ii  gconf-service                             3.2.6-4                           amd64        GNOME configuration database system (D-Bus service)
    ii  gconf2                                    3.2.6-4                           amd64        GNOME configuration database system (support tools)
    ii  gconf2-common                             3.2.6-4                           all          GNOME configuration database system (common files)
    ii  gcr                                       3.20.0-3                          amd64        GNOME crypto services (daemon and tools)
    ii  gdb                                       7.11.1-2                          amd64        GNU Debugger
    ii  gdbserver                                 7.11.1-2                          amd64        GNU Debugger (remote server)
    ii  gdebi                                     0.9.5.7.1                         all          simple tool to view and install deb files - GNOME GUI
    ii  gdebi-core                                0.9.5.7.1                         all          simple tool to install deb files
    ii  gdisk                                     1.0.1-1                           amd64        GPT fdisk text-mode partitioning tool
    ii  gedit                                     3.22.0-1+deepin                   amd64        official text editor of the GNOME desktop environment
    ii  gedit-common                              3.22.0-1+deepin                   all          official text editor of the GNOME desktop environment (support files)
    ii  genymotion                                2.8.0-1                           amd64        Complete set of tools that provides a virtual environment for Android.
    ii  geoclue-2.0                               2.4.4-1                           amd64        geoinformation service
    ii  geoip-database                            20161017-1                        all          IP lookup command line tools that use the GeoIP library (country database)
    ii  gettext                                   0.19.8.1-1                        amd64        GNU Internationalization utilities
    ii  gettext-base                              0.19.8.1-1                        amd64        GNU Internationalization utilities for the base system
    ii  gfortran                                  4:6.1.1-1                         amd64        GNU Fortran 95 compiler
    ii  gfortran-5                                5.4.1-3                           amd64        GNU Fortran compiler
    ii  gfortran-6                                6.2.0-11                          amd64        GNU Fortran compiler
    ii  gftp                                      2.0.19-4                          all          X/GTK+ and console FTP client (metapackage)
    ii  gftp-common                               2.0.19-4+b2                       amd64        shared files for other gFTP packages
    ii  gftp-gtk                                  2.0.19-4+b2                       amd64        X/GTK+ FTP client
    ii  gftp-text                                 2.0.19-4+b2                       amd64        colored FTP client using GLib
    ii  ghostscript                               9.19~dfsg-3.1                     amd64        interpreter for the PostScript language and for PDF
    ii  giblib1:amd64                             1.2.4-11                          amd64        wrapper library for imlib2, and other stuff
    ii  gimp                                      2.8.18-1                          amd64        GNU Image Manipulation Program
    ii  gimp-data                                 2.8.18-1                          all          Data files for GIMP
    ii  gir1.2-atk-1.0:amd64                      2.22.0-1                          amd64        ATK accessibility toolkit (GObject introspection)
    ii  gir1.2-atspi-2.0:amd64                    2.22.0-3                          amd64        Assistive Technology Service Provider (GObject introspection)
    ii  gir1.2-clutter-1.0:amd64                  1.26.0+dfsg-1                     amd64        GObject introspection data for the Clutter 1.0 library
    ii  gir1.2-clutter-gst-2.0                    2.0.18-1                          amd64        Gobject introspection data for Clutter GStreamer elements
    ii  gir1.2-cogl-1.0:amd64                     1.22.0-2+deepin3                  amd64        GObject introspection data for the Cogl 1.0 library
    ii  gir1.2-coglpango-1.0:amd64                1.22.0-2+deepin3                  amd64        GObject introspection data for the CoglPango 1.0 library
    ii  gir1.2-evince-3.0:amd64                   3.22.1-2                          amd64        GObject introspection data for the evince libraries
    ii  gir1.2-freedesktop:amd64                  1.50.0-1                          amd64        Introspection data for some FreeDesktop components
    ii  gir1.2-gdkpixbuf-2.0:amd64                2.36.0-1                          amd64        GDK Pixbuf library - GObject-Introspection
    ii  gir1.2-gee-0.8:amd64                      0.18.1-1                          amd64        GObject based collection and utility library (GObject-Introspection)
    ii  gir1.2-gee-1.0:amd64                      0.6.8-2                           amd64        GLib Telepathy connection manager library (GObject-Introspection)
    ii  gir1.2-glib-2.0:amd64                     1.50.0-1                          amd64        Introspection data for GLib, GObject, Gio and GModule
    ii  gir1.2-gnomekeyring-1.0                   3.12.0-1+b1                       amd64        GNOME keyring services library - introspection data
    ii  gir1.2-gst-plugins-base-1.0               1.10.0-1                          amd64        GObject introspection data for the GStreamer Plugins Base library
    ii  gir1.2-gstreamer-1.0                      1.10.0-1                          amd64        GObject introspection data for the GStreamer library
    ii  gir1.2-gtk-2.0                            2.24.31-1                         amd64        GTK+ graphical user interface library -- gir bindings
    ii  gir1.2-gtk-3.0:amd64                      3.22.2-1                          amd64        GTK+ graphical user interface library -- gir bindings
    ii  gir1.2-gtkclutter-1.0:amd64               1.8.2-1                           amd64        GObject introspection data for the GTK+ Clutter library
    ii  gir1.2-gtksource-3.0:amd64                3.22.1-1                          amd64        gir files for the GTK+ syntax highlighting widget
    ii  gir1.2-javascriptcoregtk-4.0:amd64        2.14.2-1                          amd64        JavaScript engine library from WebKitGTK+ - GObject introspection data
    ii  gir1.2-json-1.0:amd64                     1.2.2-1                           amd64        GLib JSON manipulation library (introspection data)
    ii  gir1.2-notify-0.7:amd64                   0.7.7-1                           amd64        sends desktop notifications to a notification daemon (Introspection files)
    ii  gir1.2-packagekitglib-1.0                 1.1.4-3                           amd64        GObject introspection data for the PackageKit GLib library
    ii  gir1.2-pango-1.0:amd64                    1.40.3-3                          amd64        Layout and rendering of internationalized text - gir bindings
    ii  gir1.2-peas-1.0:amd64                     1.20.0-1                          amd64        Application plugin library (introspection files)
    ii  gir1.2-rsvg-2.0:amd64                     2.40.16-1                         amd64        gir files for renderer library for SVG files
    ii  gir1.2-secret-1:amd64                     0.18.5-2                          amd64        Secret store (GObject-Introspection)
    ii  gir1.2-soup-2.4:amd64                     2.56.0-1                          amd64        GObject introspection data for the libsoup HTTP library
    ii  gir1.2-vte-2.91:amd64                     0.46.0-1                          amd64        GObject introspection data for the VTE library
    ii  gir1.2-webkit2-4.0:amd64                  2.14.2-1                          amd64        Web content engine library for GTK+ - GObject introspection data
    ii  gir1.2-wnck-3.0:amd64                     3.20.1-2                          amd64        GObject introspection data for the WNCK library
    ii  git                                       1:2.10.2-2                        amd64        fast, scalable, distributed revision control system
    ii  git-core                                  1:2.10.2-2                        all          fast, scalable, distributed revision control system (obsolete)
    ii  git-man                                   1:2.10.2-2                        all          fast, scalable, distributed revision control system (manual pages)
    ii  gksu                                      2.0.2-60                          amd64        graphical front-end to su and sudo
    ii  glib-networking:amd64                     2.50.0-1                          amd64        network-related giomodules for GLib
    ii  glib-networking-common                    2.50.0-1                          all          network-related giomodules for GLib - data files
    ii  glib-networking-services                  2.50.0-1                          amd64        network-related giomodules for GLib - D-Bus services
    ii  gnome-calculator                          3.22.1-1                          amd64        GNOME desktop calculator
    ii  gnome-desktop3-data                       3.22.1-1                          all          Common files for GNOME desktop apps
    ii  gnome-font-viewer                         3.20.2-1                          amd64        font viewer for GNOME
    ii  gnome-icon-theme                          3.12.0-2                          all          GNOME Desktop icon theme
    ii  gnome-icon-theme-symbolic                 3.12.1                            all          GNOME desktop icon theme (symbolic icons)
    ii  gnome-keyring                             3.20.0-3                          amd64        GNOME keyring services (daemon and tools)
    ii  gnome-mime-data                           2.18.0-1                          all          base MIME and Application database for GNOME.
    ii  gnome-system-monitor                      3.20.1-9                          amd64        Process viewer and system resource monitor for GNOME
    ii  gnupg                                     2.1.15-8                          amd64        GNU privacy guard - a free PGP replacement
    ii  gnupg-agent                               2.1.15-8                          amd64        GNU privacy guard - cryptographic agent
    ii  gnupg-l10n                                2.1.15-8                          all          GNU privacy guard - localization files
    ii  gnupg2                                    2.1.15-8                          all          GNU privacy guard - a free PGP replacement (dummy transitional package)
    ii  gnuplot                                   4.6.6-3                           all          Command-line driven interactive plotting program
    ii  gnuplot-tex                               4.6.6-3                           all          Command-line driven interactive plotting program. Tex-files
    ii  gnuplot5-data                             5.0.3+dfsg2-1                     all          Command-line driven interactive plotting program. Data-files
    ii  gnuplot5-qt                               5.0.3+dfsg2-1                     amd64        Command-line driven interactive plotting program. QT-package
    ii  google-android-sdk                        2.1.2.0~r1                        amd64        Google Android SDK.
    ii  google-chrome-stable                      56.0.2924.87-1                    amd64        The web browser from Google
    ii  gparted                                   0.25.0-1                          amd64        GNOME partition editor
    ii  gpgv                                      2.1.15-8                          amd64        GNU privacy guard - signature verification tool
    ii  grep                                      2.26-1                            amd64        GNU grep, egrep and fgrep
    ii  groff-base                                1.22.3-8                          amd64        GNU troff text-formatting system (base system components)
    ii  grub-common                               2.02~beta3-4                      amd64        GRand Unified Bootloader (common files)
    ii  grub-pc                                   2.02~beta3-4                      amd64        GRand Unified Bootloader, version 2 (PC/BIOS version)
    ii  grub-pc-bin                               2.02~beta3-4                      amd64        GRand Unified Bootloader, version 2 (PC/BIOS binaries)
    ii  grub-themes-deepin                        1.0.0-1                           all          Deepin theme for grub2
    ii  grub2-common                              2.02~beta3-4                      amd64        GRand Unified Bootloader (common files for version 2)
    ii  gsettings-desktop-schemas                 3.22.0-1                          all          GSettings desktop-wide schemas
    ii  gsfonts                                   1:8.11+urwcyr1.0.7~pre44-4.3      all          Fonts for the Ghostscript interpreter(s)
    ii  gstreamer0.10-gconf:amd64                 0.10.31-3+nmu4+b2                 amd64        GStreamer plugin for getting the sink/source information from GConf
    ii  gstreamer0.10-plugins-bad:amd64           0.10.23-9                         amd64        GStreamer plugins from the "bad" set
    ii  gstreamer0.10-plugins-base:amd64          0.10.36-2                         amd64        GStreamer plugins from the "base" set
    ii  gstreamer0.10-plugins-good:amd64          0.10.31-3+nmu4+b2                 amd64        GStreamer plugins from the "good" set
    ii  gstreamer0.10-plugins-ugly:amd64          0.10.19-2.1+b3                    amd64        GStreamer plugins from the "ugly" set
    ii  gstreamer1.0-libav:amd64                  1.10.0-1                          amd64        libav plugin for GStreamer
    ii  gstreamer1.0-plugins-bad:amd64            1.10.2-1                          amd64        GStreamer plugins from the "bad" set
    ii  gstreamer1.0-plugins-base:amd64           1.10.0-1                          amd64        GStreamer plugins from the "base" set
    ii  gstreamer1.0-plugins-good:amd64           1.10.2-1                          amd64        GStreamer plugins from the "good" set
    ii  gstreamer1.0-plugins-ugly:amd64           1.10.0-1                          amd64        GStreamer plugins from the "ugly" set
    ii  gstreamer1.0-pulseaudio:amd64             1.10.2-1                          amd64        GStreamer plugin for PulseAudio
    ii  gtk-update-icon-cache                     3.22.2-1                          amd64        icon theme caching utility
    ii  gtk2-engines:amd64                        1:2.20.2-3                        amd64        theme engines for GTK+ 2.x
    ii  gtk2-engines-murrine:amd64                0.98.1.1-6                        amd64        cairo-based gtk+-2.0 theme engine
    ii  gtk2-engines-pixbuf:amd64                 2.24.31-1                         amd64        pixbuf-based theme for GTK+ 2.x
    ii  gtk3-engines-unico:amd64                  1.0.3+bzr152-1                    amd64        Unico Gtk+ 3 theme engine
    ii  gvfs:amd64                                1.27.3-1                          amd64        userspace virtual filesystem - GIO module
    ii  gvfs-backends                             1.27.3-1                          amd64        userspace virtual filesystem - backends
    ii  gvfs-bin                                  1.27.3-1                          amd64        userspace virtual filesystem - binaries
    ii  gvfs-common                               1.27.3-1                          all          userspace virtual filesystem - common data files
    ii  gvfs-daemons                              1.27.3-1                          amd64        userspace virtual filesystem - servers
    ii  gvfs-libs:amd64                           1.27.3-1                          amd64        userspace virtual filesystem - private libraries
    ii  gzip                                      1.6-5                             amd64        GNU compression utilities
    ii  h5utils                                   1.12.1-6                          amd64        HDF5 files visualization tools
    ii  hdf5-tools                                1.10.0-patch1+docs-3              amd64        Hierarchical Data Format 5 (HDF5) - Runtime tools
    ii  hdfview                                   2.11.0+dfsg-2deepin               amd64        Java HDF Object viewer
    ii  hexchat                                   2.12.0-2+b1                       amd64        IRC client for X based on X-Chat 2
    ii  hexchat-common                            2.12.0-2                          all          Common files for HexChat
    ii  hexchat-perl                              2.12.0-2+b1                       amd64        Perl plugin for HexChat
    ii  hexchat-plugins                           2.12.0-2+b1                       amd64        Common plugins for HexChat
    ii  hexchat-python3                           2.12.0-2+b1                       amd64        Python 3 plugin for HexChat
    ii  hfsprogs                                  332.25-11+b1                      amd64        mkfs and fsck for HFS and HFS+ file systems
    ii  hicolor-icon-theme                        0.15-1                            all          default fallback theme for FreeDesktop.org icon themes
    ii  host                                      1:9.10.3.dfsg.P4-10.1             all          Transitional package
    ii  hostname                                  3.18                              amd64        utility to set/show the host name or domain name
    ii  hunspell-en-gb                            1:5.2.1-2                         all          English (GB) dictionary for hunspell
    ii  hwloc-nox                                 1.11.4-1                          amd64        Hierarchical view of the machine - non-X version of utilities
    ii  i965-va-driver:i386                       1.7.2-1                           i386         VAAPI driver for Intel G45 & HD Graphics family
    rc  icedtea-netx-common                       1.6.2-3                           all          NetX - implementation of the Java Network Launching Protocol (JNLP)
    ii  icu-devtools                              57.1-5                            amd64        Development utilities for International Components for Unicode
    ii  idea-community                            2016.2.5-1                        all          lightweight java ide
    ii  ifupdown                                  0.8.16                            amd64        high level tools to configure network interfaces
    ii  iio-sensor-proxy                          1.3-2                             amd64        IIO sensors to D-Bus proxy
    ii  im-config                                 0.29-6                            all          Input method configuration framework
    ii  imagemagick                               8:6.9.7.0+dfsg-2+deepin           amd64        image manipulation programs -- binaries
    ii  imagemagick-6-common                      8:6.9.7.0+dfsg-2+deepin           all          image manipulation programs -- infrastructure
    ii  imagemagick-6.q16                         8:6.9.7.0+dfsg-2+deepin           amd64        image manipulation programs -- quantum depth Q16
    rc  imagemagick-common                        8:6.9.7.0+dfsg-2+deepin           all          image manipulation programs -- infrastructure dummy package
    ii  init                                      1.46                              amd64        metapackage ensuring an init system is installed
    ii  init-system-helpers                       1.46                              all          helper tools for all init systems
    ii  initramfs-tools                           0.125                             all          generic modular initramfs generator (automation)
    ii  initramfs-tools-core                      0.125                             all          generic modular initramfs generator (core tools)
    ii  initscripts                               2.88dsf-59.8                      amd64        scripts for initializing and shutting down the system
    ii  insserv                                   1.14.0-5.4                        amd64        boot sequence organizer using LSB init.d script dependency information
    ii  intel-microcode                           3.20160714.1                      amd64        Processor microcode firmware for Intel CPUs
    ii  intltool-debian                           0.35.0+20060710.4                 all          Help i18n of RFC822 compliant config files
    ii  iproute                                   1:4.8.0-1                         all          transitional dummy package for iproute2
    ii  iproute2                                  4.8.0-1                           amd64        networking and traffic control tools
    ii  iptables                                  1.6.0-4                           amd64        administration tools for packet filtering and NAT
    ii  iputils-ping                              3:20150815-2                      amd64        Tools to test the reachability of network hosts
    ii  ipxe-qemu                                 1.0.0+git-20150424.a25a16d-1      all          PXE boot firmware - ROM images for qemu
    ii  ipython                                   5.1.0-2                           all          Enhanced interactive Python 2 shell
    rc  ipython-qtconsole                         4.2.1-2                           all          transitional dummy package for python-qtconsole
    ii  irqbalance                                1.1.0-2                           amd64        Daemon to balance interrupts for SMP systems
    ii  isc-dhcp-client                           4.3.5~b1-1                        amd64        DHCP client for automatically obtaining an IP address
    ii  isc-dhcp-common                           4.3.5~b1-1                        amd64        common files used by all of the isc-dhcp packages
    ii  iso-codes                                 3.70-1                            all          ISO language, territory, currency, script codes and their translations
    ii  iucode-tool                               2.0-1                             amd64        Intel processor microcode tool
    ii  java-common                               0.57                              all          Base package for Java runtimes
    ii  java-wrappers                             0.1.28                            all          wrappers for java executables
    ii  javascript-common                         11                                all          Base support for JavaScript library packages
    ii  jfsutils                                  1.1.15-2.2                        amd64        utilities for managing the JFS filesystem
    ii  jieba                                     0.36-2                            all          Chinese Words Segementation Utilities
    ii  jq                                        1.5+dfsg-1+b1                     amd64        lightweight and flexible command-line JSON processor
    ii  keyboard-configuration                    1.152                             all          system-wide keyboard preferences
    ii  klibc-utils                               2.0.4-9                           amd64        small utilities built with klibc for early boot
    ii  kmod                                      23-1                              amd64        tools for managing Linux kernel modules
    ii  lastore-daemon                            0.9.39-2                          amd64        daemon of lastore
    ii  less                                      481-2.1                           amd64        pager program similar to more
    ii  liba52-0.7.4:amd64                        0.7.4-18                          amd64        library for decoding ATSC A/52 streams
    ii  libaa1:amd64                              1.4p5-44                          amd64        ASCII art library
    ii  libabw-0.1-1:amd64                        0.1.1-4                           amd64        library for reading and writing AbiWord(tm) documents
    ii  libaccountsservice0                       0.6.40-3                          amd64        query and manipulate user account information - shared libraries
    ii  libacl1:amd64                             2.2.52-3                          amd64        Access control list shared library
    ii  libaec0:amd64                             0.3.2-1                           amd64        Adaptive Entropy Coding library
    ii  libaio1:amd64                             0.3.110-3                         amd64        Linux kernel AIO access library - shared library
    ii  libamd2:amd64                             1:4.5.3-2                         amd64        approximate minimum degree ordering library for sparse matrices
    ii  libapache-pom-java                        10-2                              all          Maven metadata for all Apache Software projects
    ii  libapache2-mod-jk                         1:1.2.42-1                        amd64        Apache 2 connector for the Tomcat Java servlet engine
    ii  libapparmor1:amd64                        2.10.95-5                         amd64        changehat AppArmor library
    ii  libappindicator-dev                       0.4.92-4                          amd64        allow applications to export a menu into the panel -- development
    ii  libappindicator1:amd64                    0.4.92-4                          amd64        allow applications to export a menu into the panel
    ii  libapr1:amd64                             1.5.2-4                           amd64        Apache Portable Runtime Library
    ii  libaprutil1:amd64                         1.5.4-2                           amd64        Apache Portable Runtime Utility Library
    ii  libaprutil1-dbd-sqlite3:amd64             1.5.4-2                           amd64        Apache Portable Runtime Utility Library - SQLite3 Driver
    ii  libaprutil1-ldap:amd64                    1.5.4-2                           amd64        Apache Portable Runtime Utility Library - LDAP Driver
    ii  libapt-inst1.5:amd64                      1.0.9.10                          amd64        deb package format runtime library
    ii  libapt-inst1.7:amd64                      1.0.10.2.4                        amd64        deb package format runtime library
    ii  libapt-inst2.0:amd64                      1.4~beta2+deepin                  amd64        deb package format runtime library
    ii  libapt-pkg-perl                           0.1.30                            amd64        Perl interface to libapt-pkg
    ii  libapt-pkg4.12:amd64                      1.0.9.10                          amd64        package management runtime library
    ii  libapt-pkg4.16:amd64                      1.0.10.2.4                        amd64        package management runtime library
    ii  libapt-pkg5.0:amd64                       1.4~beta2+deepin                  amd64        package management runtime library
    ii  libarchive-zip-perl                       1.59-1                            all          Perl module for manipulation of ZIP archives
    ii  libarchive13:amd64                        3.2.1-5                           amd64        Multi-format archive and compression library (shared library)
    ii  libarmadillo7                             1:7.500.0+dfsg-1                  amd64        streamlined C++ linear algebra library
    ii  libarpack2                                3.4.0-1+b1                        amd64        Fortran77 subroutines to solve large scale eigenvalue problems
    rc  libart-2.0-2:amd64                        2.3.21-2                          amd64        Library of functions for 2D graphics - runtime files
    ii  libasan1:amd64                            4.9.4-2                           amd64        AddressSanitizer -- a fast memory error detector
    ii  libasan2:amd64                            5.4.1-3                           amd64        AddressSanitizer -- a fast memory error detector
    ii  libasan3:amd64                            6.2.0-11                          amd64        AddressSanitizer -- a fast memory error detector
    ii  libasn1-8-heimdal:amd64                   1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - ASN.1 library
    ii  libasound2:amd64                          1.1.2-1                           amd64        shared library for ALSA applications
    ii  libasound2:i386                           1.1.2-1                           i386         shared library for ALSA applications
    ii  libasound2-data                           1.1.2-1                           all          Configuration files and profiles for ALSA drivers
    ii  libasound2-plugins:amd64                  1.1.1-1                           amd64        ALSA library additional plugins
    ii  libasound2-plugins:i386                   1.1.1-1                           i386         ALSA library additional plugins
    ii  libaspell15:amd64                         0.60.7~20110707-3+b1              amd64        GNU Aspell spell-checker runtime library
    ii  libass5:amd64                             0.13.4-1                          amd64        library for SSA/ASS subtitles rendering
    ii  libassuan0:amd64                          2.4.3-1                           amd64        IPC library for the GnuPG components
    ii  libasyncns0:amd64                         0.8-6                             amd64        Asynchronous name service query library
    ii  libasyncns0:i386                          0.8-6                             i386         Asynchronous name service query library
    ii  libatasmart4:amd64                        0.19-4                            amd64        ATA S.M.A.R.T. reading and parsing library
    ii  libatk-bridge2.0-0:amd64                  2.22.0-1                          amd64        AT-SPI 2 toolkit bridge - shared library
    ii  libatk-bridge2.0-dev:amd64                2.22.0-1                          amd64        Development files for the AT-SPI 2 toolkit bridge
    ii  libatk-wrapper-java                       0.33.3-9                          all          ATK implementation for Java using JNI
    ii  libatk-wrapper-java-jni:amd64             0.33.3-9                          amd64        ATK implementation for Java using JNI (JNI bindings)
    ii  libatk1.0-0:amd64                         2.22.0-1                          amd64        ATK accessibility toolkit
    ii  libatk1.0-data                            2.22.0-1                          all          Common files for the ATK accessibility toolkit
    ii  libatk1.0-dev:amd64                       2.22.0-1                          amd64        Development files for the ATK accessibility toolkit
    ii  libatkmm-1.6-1v5:amd64                    2.24.2-2                          amd64        C++ wrappers for ATK accessibility toolkit (shared libraries)
    ii  libatomic1:amd64                          6.2.0-11                          amd64        support library providing __atomic built-in functions
    ii  libatspi2.0-0:amd64                       2.22.0-3                          amd64        Assistive Technology Service Provider Interface - shared library
    ii  libatspi2.0-dev:amd64                     2.22.0-3                          amd64        Development files for the assistive technology service provider
    ii  libattr1:amd64                            1:2.4.47-2                        amd64        Extended attribute shared library
    ii  libattr1:i386                             1:2.4.47-2                        i386         Extended attribute shared library
    ii  libaudio2:amd64                           1.9.4-5                           amd64        Network Audio System - shared libraries
    ii  libaudit-common                           1:2.6.7-1                         all          Dynamic library for security auditing - common files
    ii  libaudit1:amd64                           1:2.6.7-1                         amd64        Dynamic library for security auditing
    ii  libauthen-sasl-perl                       2.1600-1                          all          Authen::SASL - SASL Authentication framework
    ii  libavahi-client3:amd64                    0.6.32-1                          amd64        Avahi client library
    ii  libavahi-client3:i386                     0.6.32-1                          i386         Avahi client library
    ii  libavahi-common-data:amd64                0.6.32-1                          amd64        Avahi common data files
    ii  libavahi-common-data:i386                 0.6.32-1                          i386         Avahi common data files
    ii  libavahi-common3:amd64                    0.6.32-1                          amd64        Avahi common library
    ii  libavahi-common3:i386                     0.6.32-1                          i386         Avahi common library
    ii  libavahi-core7:amd64                      0.6.32-1                          amd64        Avahi's embeddable mDNS/DNS-SD library
    ii  libavahi-glib1:amd64                      0.6.32-1                          amd64        Avahi GLib integration library
    ii  libavalon-framework-java                  4.2.0-9                           all          Common framework for Java server applications
    ii  libavc1394-0:amd64                        0.5.4-4                           amd64        control IEEE 1394 audio/video devices
    ii  libavcodec-ffmpeg56:amd64                 7:2.8.6-1+b2                      amd64        FFmpeg library with de/encoders for audio/video codecs - runtime files
    ii  libavcodec57:amd64                        7:3.2.2-1                         amd64        FFmpeg library with de/encoders for audio/video codecs - runtime files
    ii  libavcodec57:i386                         7:3.2.2-1                         i386         FFmpeg library with de/encoders for audio/video codecs - runtime files
    ii  libavdevice57:amd64                       7:3.2.2-1                         amd64        FFmpeg library for handling input and output devices - runtime files
    ii  libavfilter-ffmpeg5:amd64                 7:2.8.6-1+b2                      amd64        FFmpeg library containing media filters - runtime files
    ii  libavfilter6:amd64                        7:3.2.2-1                         amd64        FFmpeg library containing media filters - runtime files
    ii  libavformat-ffmpeg56:amd64                7:2.8.6-1+b2                      amd64        FFmpeg library with (de)muxers for multimedia containers - runtime files
    ii  libavformat57:amd64                       7:3.2.2-1                         amd64        FFmpeg library with (de)muxers for multimedia containers - runtime files
    ii  libavresample-ffmpeg2:amd64               7:2.8.6-1+b2                      amd64        FFmpeg compatibility library for resampling - runtime files
    ii  libavresample3:amd64                      7:3.2.2-1                         amd64        FFmpeg compatibility library for resampling - runtime files
    ii  libavresample3:i386                       7:3.2.2-1                         i386         FFmpeg compatibility library for resampling - runtime files
    ii  libavutil-ffmpeg54:amd64                  7:2.8.6-1+b2                      amd64        FFmpeg library with functions for simplifying programming - runtime files
    ii  libavutil55:amd64                         7:3.2.2-1                         amd64        FFmpeg library with functions for simplifying programming - runtime files
    ii  libavutil55:i386                          7:3.2.2-1                         i386         FFmpeg library with functions for simplifying programming - runtime files
    rc  libax25                                   0.0.12-rc4-1                      amd64        ax25 library for hamradio applications
    ii  libbabeltrace-ctf1:amd64                  1.5.1-1                           amd64        Common Trace Format (CTF) library
    ii  libbabeltrace1:amd64                      1.5.1-1                           amd64        Babeltrace conversion libraries
    ii  libbabl-0.1-0:amd64                       0.1.18-1                          amd64        Dynamic, any to any, pixel format conversion library
    ii  libbamf3-0:amd64                          0.2.118-1.3                       amd64        Window matching library - shared library
    rc  libbasicusageenvironment0                 2014.01.13-1                      amd64        multimedia RTSP streaming library (BasicUsageEnvironment class)
    ii  libbasicusageenvironment1:amd64           2016.11.06-1                      amd64        multimedia RTSP streaming library (BasicUsageEnvironment class)
    rc  libbcprov-java                            1.54-1                            all          Bouncy Castle Java Cryptographic Service Provider
    ii  libbind9-140:amd64                        1:9.10.3.dfsg.P4-10.1             amd64        BIND9 Shared Library used by BIND
    ii  libbind9-90                               1:9.9.5.dfsg-12.1                 amd64        BIND9 Shared Library used by BIND
    ii  libbison-dev:amd64                        2:3.0.4.dfsg-1                    amd64        YACC-compatible parser generator - development library
    ii  libblas-common                            3.6.1-2                           amd64        Dependency package for all BLAS implementations
    ii  libblas-dev                               3.6.1-2                           amd64        Basic Linear Algebra Subroutines 3, static library
    ii  libblas3                                  3.6.1-2                           amd64        Basic Linear Algebra Reference implementations, shared library
    ii  libblkid1:amd64                           2.28.2-1                          amd64        block device ID library
    ii  libblkid1:i386                            2.28.2-1                          i386         block device ID library
    ii  libblosc1                                 1.11.1+ds1-2                      amd64        high performance meta-compressor optimized for binary data
    ii  libbluetooth3:amd64                       5.43-1                            amd64        Library to use the BlueZ Linux Bluetooth stack
    ii  libbluray1:amd64                          1:0.9.3-2                         amd64        Blu-ray disc playback support library (shared library)
    ii  libbonobo2-0:amd64                        2.32.1-3                          amd64        Bonobo CORBA interfaces library
    ii  libbonobo2-common                         2.32.1-3                          all          Bonobo CORBA interfaces library -- support files
    ii  libboost-atomic1.61.0:amd64               1.61.0+dfsg-3+b1                  amd64        atomic data types, operations, and memory ordering constraints
    ii  libboost-chrono1.61.0:amd64               1.61.0+dfsg-3+b1                  amd64        C++ representation of time duration, time point, and clocks
    ii  libboost-date-time1.58.0:amd64            1.58.0+dfsg-5.1                   amd64        set of date-time libraries based on generic programming concepts
    ii  libboost-date-time1.61.0:amd64            1.61.0+dfsg-3+b1                  amd64        set of date-time libraries based on generic programming concepts
    ii  libboost-filesystem1.58.0:amd64           1.58.0+dfsg-5.1                   amd64        filesystem operations (portable paths, iteration over directories, etc) in C++
    ii  libboost-filesystem1.61.0:amd64           1.61.0+dfsg-3+b1                  amd64        filesystem operations (portable paths, iteration over directories, etc) in C++
    ii  libboost-iostreams1.54.0:amd64            1.54.0+dfsg-7                     amd64        Boost.Iostreams Library
    ii  libboost-iostreams1.55.0:amd64            1.55.0+dfsg-4                     amd64        Boost.Iostreams Library
    ii  libboost-iostreams1.58.0:amd64            1.58.0+dfsg-5.1                   amd64        Boost.Iostreams Library
    ii  libboost-iostreams1.61.0:amd64            1.61.0+dfsg-3+b1                  amd64        Boost.Iostreams Library
    ii  libboost-program-options1.61.0:amd64      1.61.0+dfsg-3+b1                  amd64        program options library for C++
    ii  libboost-python1.61.0                     1.61.0+dfsg-3+b1                  amd64        Boost.Python Library
    ii  libboost-random1.61.0:amd64               1.61.0+dfsg-3+b1                  amd64        Boost Random Number Library
    ii  libboost-regex1.61.0:amd64                1.61.0+dfsg-3+b1                  amd64        regular expression library for C++
    ii  libboost-signals1.61.0:amd64              1.61.0+dfsg-3+b1                  amd64        managed signals and slots library for C++
    ii  libboost-system1.58.0:amd64               1.58.0+dfsg-5.1                   amd64        Operating system (e.g. diagnostics support) library
    ii  libboost-system1.61.0:amd64               1.61.0+dfsg-3+b1                  amd64        Operating system (e.g. diagnostics support) library
    ii  libboost-thread1.61.0:amd64               1.61.0+dfsg-3+b1                  amd64        portable C++ multi-threading
    ii  libbotan-1.10-1                           1.10.13-1                         amd64        multiplatform crypto library
    ii  libbotan1.10-dev                          1.10.13-1                         amd64        multiplatform crypto library (development)
    ii  libbrlapi0.6:amd64                        5.4-1                             amd64        braille display access via BRLTTY - shared library
    ii  libbs2b0:amd64                            3.1.0+dfsg-2.2                    amd64        Bauer stereophonic-to-binaural DSP library
    ii  libbsd0:amd64                             0.8.3-1                           amd64        utility functions from BSD systems - shared library
    ii  libbsd0:i386                              0.8.3-1                           i386         utility functions from BSD systems - shared library
    ii  libbz2-1.0:amd64                          1.0.6-8                           amd64        high-quality block-sorting file compressor library - runtime
    ii  libbz2-dev:amd64                          1.0.6-8                           amd64        high-quality block-sorting file compressor library - development
    ii  libc-ares2:amd64                          1.12.0-1                          amd64        asynchronous name resolver
    ii  libc-bin                                  2.24-5                            amd64        GNU C Library: Binaries
    ii  libc-dev-bin                              2.24-5                            amd64        GNU C Library: Development binaries
    ii  libc-l10n                                 2.24-5                            all          GNU C Library: localization files
    ii  libc6:amd64                               2.24-5                            amd64        GNU C Library: Shared libraries
    ii  libc6:i386                                2.24-5                            i386         GNU C Library: Shared libraries
    ii  libc6-dbg:amd64                           2.24-5                            amd64        GNU C Library: detached debugging symbols
    ii  libc6-dev:amd64                           2.24-5                            amd64        GNU C Library: Development Libraries and Header Files
    ii  libcaca0:amd64                            0.99.beta19-2+b1                  amd64        colour ASCII art library
    ii  libcacard0:amd64                          1:2.5.0-2                         amd64        Virtual Common Access Card (CAC) Emulator (runtime library)
    ii  libcairo-gobject2:amd64                   1.14.6-1.1                        amd64        Cairo 2D vector graphics library (GObject library)
    ii  libcairo-perl                             1.106-1+b2                        amd64        Perl interface to the Cairo graphics library
    ii  libcairo-script-interpreter2:amd64        1.14.6-1.1                        amd64        Cairo 2D vector graphics library (script interpreter)
    ii  libcairo2:amd64                           1.14.6-1.1                        amd64        Cairo 2D vector graphics library
    ii  libcairo2:i386                            1.14.6-1.1                        i386         Cairo 2D vector graphics library
    ii  libcairo2-dev                             1.14.6-1.1                        amd64        Development files for the Cairo 2D graphics library
    ii  libcairomm-1.0-1v5:amd64                  1.12.0-1+b1                       amd64        C++ wrappers for Cairo (shared libraries)
    ii  libcamd2:amd64                            1:4.5.3-2                         amd64        symmetric approximate minimum degree library for sparse matrices
    ii  libcanberra-gtk3-0:amd64                  0.30-3                            amd64        GTK+ 3.0 helper for playing widget event sounds with libcanberra
    ii  libcanberra-pulse:amd64                   0.30-3                            amd64        PulseAudio backend for libcanberra
    ii  libcanberra0:amd64                        0.30-3                            amd64        simple abstract interface for playing event sounds
    ii  libcap-ng0:amd64                          0.7.7-3                           amd64        An alternate POSIX capabilities library
    ii  libcap2:amd64                             1:2.25-1                          amd64        POSIX 1003.1e capabilities (library)
    ii  libcap2:i386                              1:2.25-1                          i386         POSIX 1003.1e capabilities (library)
    ii  libcap2-bin                               1:2.25-1                          amd64        POSIX 1003.1e capabilities (utilities)
    ii  libcapi20-3:i386                          1:3.27-1                          i386         ISDN utilities - CAPI support libraries
    ii  libcc1-0:amd64                            6.2.0-11                          amd64        GCC cc1 plugin for GDB
    ii  libccolamd2:amd64                         1:4.5.3-2                         amd64        constrained column approximate library for sparse matrices
    ii  libcdaudio1:amd64                         0.99.12p2-14                      amd64        library for controlling a CD-ROM when playing audio CDs
    ii  libcddb2                                  1.3.2-5                           amd64        library to access CDDB data - runtime files
    ii  libcdio-cdda1                             0.83-4.2+b1                       amd64        library to read and control digital audio CDs
    ii  libcdio-paranoia1                         0.83-4.2+b1                       amd64        library to read digital audio CDs with error correction
    ii  libcdio13                                 0.83-4.2+b1                       amd64        library to read and control CD-ROM
    ii  libcdparanoia0:amd64                      3.10.2+debian-11                  amd64        audio extraction tool for sampling CDs (library)
    rc  libcdparanoia0:i386                       3.10.2+debian-11                  i386         audio extraction tool for sampling CDs (library)
    ii  libcdr-0.1-1:amd64                        0.1.3-3                           amd64        library for reading and converting Corel DRAW files
    ii  libcdt5                                   2.38.0-16                         amd64        rich set of graph drawing tools - cdt library
    ii  libcgi-fast-perl                          1:2.10-1                          all          CGI subclass for work with FCGI
    ii  libcgi-pm-perl                            4.35-1                            all          module for Common Gateway Interface applications
    ii  libcgraph6                                2.38.0-16                         amd64        rich set of graph drawing tools - cgraph library
    ii  libchm1                                   2:0.40a-3+b1                      amd64        library for dealing with Microsoft CHM files
    ii  libcholmod3:amd64                         1:4.5.3-2                         amd64        sparse Cholesky factorization library for sparse matrices
    ii  libchromaprint0:amd64                     1.3-1+b1                          amd64        audio fingerprint library
    ii  libchromaprint1:amd64                     1.3.2-2                           amd64        audio fingerprint library
    ii  libcilkrts5:amd64                         6.2.0-11                          amd64        Intel Cilk Plus language extensions (runtime)
    ii  libclang-common-3.8-dev                   1:3.8.1-15                        amd64        clang library - Common development package
    ii  libclang1-3.6:amd64                       1:3.6.2-3                         amd64        C interface to the clang library
    ii  libclang1-3.8:amd64                       1:3.8.1-15                        amd64        C interface to the clang library
    ii  libclass-accessor-perl                    0.34-1                            all          Perl module that automatically generates accessors
    ii  libclone-perl                             0.38-2+b1                         amd64        module for recursively copying Perl datatypes
    ii  libcloog-isl4:amd64                       0.18.4-1                          amd64        Chunky Loop Generator (runtime library)
    ii  libclucene-contribs1v5:amd64              2.3.3.4-4.2                       amd64        language specific text analyzers (runtime)
    ii  libclucene-core1v5:amd64                  2.3.3.4-4.2                       amd64        core library for full-featured text search engine (runtime)
    ii  libclutter-1.0-0:amd64                    1.26.0+dfsg-1                     amd64        Open GL based interactive canvas library
    ii  libclutter-gst-2.0-0:amd64                2.0.18-1                          amd64        Open GL based interactive canvas library GStreamer elements
    ii  libclutter-gtk-1.0-0:amd64                1.8.2-1                           amd64        Open GL based interactive canvas library GTK+ widget
    ii  libcmis-0.5-5v5                           0.5.1+git20160603-3               amd64        CMIS protocol client library
    ii  libcogl-pango20:amd64                     1.22.0-2+deepin3                  amd64        Object oriented GL/GLES Abstraction/Utility Layer
    ii  libcogl-path20:amd64                      1.22.0-2+deepin3                  amd64        Object oriented GL/GLES Abstraction/Utility Layer
    ii  libcogl20:amd64                           1.22.0-2+deepin3                  amd64        Object oriented GL/GLES Abstraction/Utility Layer
    ii  libcoin80v5                               3.1.4~abc9f50+dfsg1-2             amd64        high-level 3D graphics kit implementing the Open Inventor API
    ii  libcolamd2:amd64                          1:4.5.3-2                         amd64        column approximate minimum degree ordering library for sparse matrices
    ii  libcolord2:amd64                          1.3.3-2                           amd64        system service to manage device colour profiles -- runtime
    ii  libcomerr2:amd64                          1.43.3-1                          amd64        common error description library
    ii  libcomerr2:i386                           1.43.3-1                          i386         common error description library
    ii  libcommons-dbcp-java                      1.4-5                             all          Database Connection Pooling Services
    ii  libcommons-logging-java                   1.2-1                             all          common wrapper interface for several logging APIs
    ii  libcommons-parent-java                    39-3                              all          Maven metadata for Apache Commons project
    ii  libcommons-pool-java                      1.6-3                             all          pooling implementation for Java objects
    ii  libcr-dev                                 0.8.5-2.3                         amd64        Development files for BLCR
    ii  libcr0                                    0.8.5-2.3                         amd64        Libraries to Checkpoint and Restart Linux processes
    ii  libcroco3:amd64                           0.6.11-2                          amd64        Cascading Style Sheet (CSS) parsing and manipulation toolkit
    ii  libcrypt-blowfish-perl                    2.14-1+b4                         amd64        Blowfish cryptography for Perl
    ii  libcrypt-cbc-perl                         2.33-1                            all          implementation of cipher block chaining (CBC) mode
    ii  libcrypt-rijndael-perl                    1.13-1+b2                         amd64        Perl module implementing the Rijndael algorithm
    ii  libcrypto++6                              5.6.4-6                           amd64        General purpose cryptographic library - shared library
    ii  libcryptsetup4:amd64                      2:1.7.3-2                         amd64        disk encryption support - shared library
    ii  libcrystalhd3:amd64                       1:0.0~git20110715.fdd2f19-11+b1   amd64        Crystal HD Video Decoder (shared library)
    ii  libcrystalhd3:i386                        1:0.0~git20110715.fdd2f19-11+b1   i386         Crystal HD Video Decoder (shared library)
    rc  libcue1                                   1.4.0-1                           amd64        CUE Sheet Parser Library
    ii  libcups2:amd64                            2.2.1-2                           amd64        Common UNIX Printing System(tm) - Core library
    ii  libcups2:i386                             2.2.1-2                           i386         Common UNIX Printing System(tm) - Core library
    ii  libcupscgi1:amd64                         2.2.1-2                           amd64        Common UNIX Printing System(tm) - CGI library
    ii  libcupsfilters1:amd64                     1.11.6-1+b1                       amd64        OpenPrinting CUPS Filters - Shared library
    ii  libcupsimage2:amd64                       2.2.1-2                           amd64        Common UNIX Printing System(tm) - Raster image library
    ii  libcupsmime1:amd64                        2.2.1-2                           amd64        Common UNIX Printing System(tm) - MIME library
    ii  libcupsppdc1:amd64                        2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD manipulation library
    ii  libcurl3:amd64                            7.50.1-1                          amd64        easy-to-use client-side URL transfer library (OpenSSL flavour)
    ii  libcurl3-gnutls:amd64                     7.50.1-1                          amd64        easy-to-use client-side URL transfer library (GnuTLS flavour)
    ii  libcwidget3v5:amd64                       0.5.17-4+b1                       amd64        high-level terminal interface library for C++ (runtime files)
    ii  libdaemon0:amd64                          0.14-6                            amd64        lightweight C library for daemons - runtime library
    ii  libdap23:amd64                            3.18.2-1                          amd64        Open-source Project for a Network Data Access Protocol library
    ii  libdapclient6v5:amd64                     3.18.2-1                          amd64        Client library for the Network Data Access Protocol
    ii  libdapserver7v5:amd64                     3.18.2-1                          amd64        Server library for the Network Data Access Protocol
    ii  libdatrie1:amd64                          0.2.10-4                          amd64        Double-array trie library
    ii  libdb5.3:amd64                            5.3.28-12                         amd64        Berkeley v5.3 Database Libraries [runtime]
    ii  libdb5.3:i386                             5.3.28-12                         i386         Berkeley v5.3 Database Libraries [runtime]
    ii  libdbd-mysql-perl                         4.037-5                           amd64        Perl5 database interface to the MariaDB/MySQL database
    ii  libdbi-perl                               1.636-1+b1                        amd64        Perl Database Interface (DBI)
    ii  libdbus-1-3:amd64                         1.10.12-1                         amd64        simple interprocess messaging system (library)
    ii  libdbus-1-3:i386                          1.10.12-1                         i386         simple interprocess messaging system (library)
    ii  libdbus-1-dev:amd64                       1.10.12-1                         amd64        simple interprocess messaging system (development headers)
    ii  libdbus-glib-1-2:amd64                    0.108-1                           amd64        simple interprocess messaging system (GLib-based shared library)
    ii  libdbus-glib-1-dev                        0.108-1                           amd64        simple interprocess messaging system (GLib interface)
    ii  libdbusmenu-glib-dev:amd64                12.10.2-1                         amd64        library for passing menus over DBus - development files
    ii  libdbusmenu-glib4:amd64                   12.10.2-1                         amd64        library for passing menus over DBus
    ii  libdbusmenu-gtk4:amd64                    12.10.2-1                         amd64        library for passing menus over DBus - GTK+ version
    ii  libdc1394-22:amd64                        2.2.4-1                           amd64        high level programming interface for IEEE 1394 digital cameras
    ii  libdca0:amd64                             0.0.5-10                          amd64        decoding library for DTS Coherent Acoustics streams
    ii  libdconf1:amd64                           0.26.0-2                          amd64        simple configuration storage system - runtime library
    ii  libdde-file-manager:amd64                 1.3.8-1                           amd64        DDE File Manager library
    ii  libde265-0:amd64                          1.0.2-2+b1                        amd64        Open H.265 video codec implementation
    ii  libdebconfclient0:amd64                   0.218                             amd64        Debian Configuration Management System (C-implementation library)
    ii  libdeepin-metacity-private3               3.20.6-1                          amd64        library for the Metacity window manager
    ii  libdeepin-mutter0g                        3.20.6-2                          amd64        window manager library from the Mutter window manager
    ii  libdeepin-webkit-3.0-0                    1.2.2-2                           amd64        Web content engine library for GTK+
    ii  libdeepin-wm0:amd64                       1.2-2                             amd64        Library to build plugins for Deepin Window Manager
    ii  libdevmapper-event1.02.1:amd64            2:1.02.133-1                      amd64        Linux Kernel Device Mapper event support library
    ii  libdevmapper1.02.1:amd64                  2:1.02.133-1                      amd64        Linux Kernel Device Mapper userspace library
    ii  libdigest-hmac-perl                       1.03+dfsg-1                       all          module for creating standard message integrity checks
    ii  libdirectfb-1.2-9:amd64                   1.2.10.0-5.2+b1                   amd64        direct frame buffer graphics - shared libraries
    ii  libdjvulibre-dev:amd64                    3.5.27.1-7                        amd64        Development files for the DjVu image format
    ii  libdjvulibre-text                         3.5.27.1-7                        all          Linguistic support files for libdjvulibre
    ii  libdjvulibre21:amd64                      3.5.27.1-7                        amd64        Runtime support for the DjVu image format
    ii  libdleyna-connector-dbus-1.0-1:amd64      0.2.0-1                           amd64        DBus connector module for the dLeyna services
    ii  libdleyna-core-1.0-3:amd64                0.4.0-1                           amd64        Utility functions for higher level dLeyna components
    ii  libdns-export100                          1:9.9.5.dfsg-12.1                 amd64        Exported DNS Shared Library
    ii  libdns-export162                          1:9.10.3.dfsg.P4-10.1             amd64        Exported DNS Shared Library
    ii  libdns100                                 1:9.9.5.dfsg-12.1                 amd64        DNS Shared Library used by BIND
    ii  libdns162:amd64                           1:9.10.3.dfsg.P4-10.1             amd64        DNS Shared Library used by BIND
    ii  libdouble-conversion1:amd64               2.0.1-4                           amd64        routines to convert IEEE floats to and from strings
    ii  libdpkg-perl                              1.18.13                           all          Dpkg perl modules
    ii  libdrm-amdgpu1:amd64                      2.4.71-1                          amd64        Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-amdgpu1:i386                       2.4.71-1                          i386         Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-dev:amd64                          2.4.71-1                          amd64        Userspace interface to kernel DRM services -- development files
    ii  libdrm-intel1:amd64                       2.4.71-1                          amd64        Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-intel1:i386                        2.4.71-1                          i386         Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:amd64                     2.4.71-1                          amd64        Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:i386                      2.4.71-1                          i386         Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:amd64                      2.4.71-1                          amd64        Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:i386                       2.4.71-1                          i386         Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm2:amd64                             2.4.71-1                          amd64        Userspace interface to kernel DRM services -- runtime
    ii  libdrm2:i386                              2.4.71-1                          i386         Userspace interface to kernel DRM services -- runtime
    ii  libdsdp-5.8gf                             5.8-9.1+b1                        amd64        Software for Semidefinite Programming
    ii  libdtkbase:amd64                          0.1.9                             amd64        Deepin Tool Kit Base library
    ii  libdtkbase-0.2:amd64                      0.2.3                             amd64        Deepin Tool Kit Base library
    ii  libdtkbase-dev                            0.1.9                             amd64        Deepin Tool Kit Base Devel library
    ii  libdtkutil:amd64                          0.1.9                             amd64        Deepin Tool Kit Util library
    ii  libdtkutil-0.2:amd64                      0.2.3                             amd64        Deepin Tool Kit Util library
    ii  libdtkutil-dev                            0.1.9                             amd64        Deepin Tool Kit Util library
    ii  libdtkwidget:amd64                        0.1.9                             amd64        Deepin graphical user interface library
    ii  libdtkwidget-0.2:amd64                    0.2.3                             amd64        Deepin graphical user interface library
    ii  libdtkwidget-dev                          0.1.9                             amd64        Deepin graphical user interface library
    ii  libdv4:amd64                              1.0.0-11                          amd64        software library for DV format digital video (runtime lib)
    ii  libdvbpsi10:amd64                         1.3.0-4                           amd64        library for MPEG TS and DVB PSI tables decoding and generating
    ii  libdvdnav4:amd64                          5.0.3-2                           amd64        DVD navigation library
    ii  libdvdread4:amd64                         5.0.3-2                           amd64        library for reading DVDs
    ii  libdw1:amd64                              0.166-2.2                         amd64        library that provides access to the DWARF debug information
    ii  libe-book-0.1-1:amd64                     0.1.2-4                           amd64        library for reading and converting various  e-book formats
    ii  libebml4v5:amd64                          1.3.4-1                           amd64        access library for the EBML format (shared library)
    ii  libebur128-1:amd64                        1.2.0-1                           amd64        implementation of the EBU R128 loudness standard
    ii  libecj-java                               3.11.0-7                          all          Eclipse Java compiler (library)
    ii  libedit2:amd64                            3.1-20150325-1+b1                 amd64        BSD editline and history libraries
    ii  libedit2:i386                             3.1-20150325-1+b1                 i386         BSD editline and history libraries
    ii  libefiboot1:amd64                         30-1                              amd64        Library to manage UEFI variables
    ii  libefivar0:amd64                          0.23-2                            amd64        Library to manage UEFI variables
    ii  libefivar1:amd64                          30-1                              amd64        Library to manage UEFI variables
    ii  libegl1-mesa:amd64                        12.0.3-3                          amd64        free implementation of the EGL API -- runtime
    ii  libegl1-mesa-dev:amd64                    12.0.3-3                          amd64        free implementation of the EGL API -- development files
    ii  libelf1:amd64                             0.166-2.2                         amd64        library to read and write ELF files
    ii  libelf1:i386                              0.166-2.2                         i386         library to read and write ELF files
    ii  libemail-valid-perl                       1.202-1                           all          Perl module for checking the validity of Internet email addresses
    ii  libenca0:amd64                            1.19-1                            amd64        Extremely Naive Charset Analyser - shared library files
    ii  libenchant1c2a:amd64                      1.6.0-11+b1                       amd64        Wrapper library for various spell checker engines (runtime libs)
    ii  libencode-locale-perl                     1.05-1                            all          utility to determine the locale encoding
    ii  libeot0:amd64                             0.01-4                            amd64        Library for parsing/converting Embedded OpenType files
    ii  libepoxy-dev:amd64                        1.3.1-1                           amd64        OpenGL function pointer management library- development
    ii  libepoxy0:amd64                           1.3.1-1                           amd64        OpenGL function pointer management library
    ii  libepsilon1:amd64                         0.9.2+dfsg-2                      amd64        Library for wavelet image compression
    ii  liberror-perl                             0.17024-1                         all          Perl module for error/exception handling in an OO-ish way
    ii  libestr0                                  0.1.10-2                          amd64        Helper functions for handling strings (lib)
    ii  libetonyek-0.1-1:amd64                    0.1.6-5                           amd64        library for reading and converting Apple Keynote presentations
    ii  libevdev2:amd64                           1.5.4+dfsg-2                      amd64        wrapper library for evdev devices
    ii  libevdocument3-4:amd64                    3.22.1-2                          amd64        Document (PostScript, PDF) rendering library
    ii  libevent-2.0-5:amd64                      2.0.21-stable-2.1                 amd64        Asynchronous event notification library
    ii  libevview3-3:amd64                        3.22.1-2                          amd64        Document (PostScript, PDF) rendering library - Gtk+ widgets
    ii  libexempi3:amd64                          2.3.0-2                           amd64        library to parse XMP metadata (Library)
    ii  libexif-dev                               0.6.21-2                          amd64        library to parse EXIF files (development files)
    ii  libexif12:amd64                           0.6.21-2                          amd64        library to parse EXIF files
    ii  libexif12:i386                            0.6.21-2                          i386         library to parse EXIF files
    ii  libexpat1:amd64                           2.2.0-1                           amd64        XML parsing C library - runtime library
    ii  libexpat1:i386                            2.2.0-1                           i386         XML parsing C library - runtime library
    ii  libexpat1-dev:amd64                       2.2.0-1                           amd64        XML parsing C library - development kit
    ii  libexpect-perl                            1.21-1                            all          Expect.pm - Perl Expect interface
    ii  libexporter-tiny-perl                     0.042-1                           all          tiny exporter similar to Sub::Exporter
    ii  libexttextcat-2.0-0:amd64                 3.4.4-2                           amd64        Language detection library
    ii  libexttextcat-data                        3.4.4-2                           all          Language detection library - data files
    ii  libfaad2:amd64                            2.8.0~cvs20150510-1               amd64        freeware Advanced Audio Decoder - runtime files
    ii  libfabric1                                1.4.0-1                           amd64        libfabric communication library
    ii  libfakeroot:amd64                         1.21-2                            amd64        tool for simulating superuser privileges - shared libraries
    ii  libfastjson4:amd64                        0.99.4-1                          amd64        fast json library for C
    ii  libfbclient2:amd64                        3.0.1.32609.ds4-8                 amd64        Firebird client library
    ii  libfbembed2.5                             2.5.6.27020.ds4-1+b1              amd64        Firebird embedded client/server library
    ii  libfcgi-perl                              0.78-2                            amd64        helper module for FastCGI
    ii  libfcitx-config4:amd64                    1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - configuration support library
    ii  libfcitx-core0:amd64                      1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - library of core funtions
    ii  libfcitx-gclient0:amd64                   1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - D-Bus client library for Glib
    ii  libfcitx-qt0:amd64                        1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - Meta package for Qt library
    ii  libfcitx-qt5-1:amd64                      1.0.5-3                           amd64        Free Chinese Input Toy of X - D-Bus client libraries for Qt5
    ii  libfcitx-utils0:amd64                     1:4.2.9.1-11deepin                amd64        Flexible Input Method Framework - utility support library
    ii  libfdisk1:amd64                           2.28.2-1                          amd64        fdisk partitioning library
    ii  libfdt1:amd64                             1.4.0+dfsg-2                      amd64        Flat Device Trees manipulation library
    ii  libffi-dev:amd64                          3.2.1-6                           amd64        Foreign Function Interface library (development files)
    ii  libffi6:amd64                             3.2.1-6                           amd64        Foreign Function Interface library runtime
    ii  libffi6:i386                              3.2.1-6                           i386         Foreign Function Interface library runtime
    ii  libffmpegthumbnailer4v5                   2.1.1-0.1+b2                      amd64        shared library for ffmpegthumbnailer
    ii  libfftw3-double3:amd64                    3.3.5-1                           amd64        Library for computing Fast Fourier Transforms - Double precision
    ii  libfftw3-single3:amd64                    3.3.5-1                           amd64        Library for computing Fast Fourier Transforms - Single precision
    ii  libfile-basedir-perl                      0.07-1                            all          Perl module to use the freedesktop basedir specification
    ii  libfile-copy-recursive-perl               0.38-1                            all          Perl extension for recursively copying files and directories
    ii  libfile-desktopentry-perl                 0.22-1                            all          Perl module to handle freedesktop .desktop files
    ii  libfile-homedir-perl                      1.00-1                            all          Perl module for finding user directories across platforms
    ii  libfile-listing-perl                      6.04-1                            all          module to parse directory listings
    ii  libfile-mimeinfo-perl                     0.27-1                            all          Perl module to determine file types
    ii  libfile-stripnondeterminism-perl          0.028-1                           all          file non-deterministic information stripper — Perl module
    ii  libfile-which-perl                        1.21-1                            all          Perl module for searching paths for executable programs
    ii  libfilezilla0                             0.7.0-1                           amd64        build high-performing platform-independent programs (runtime lib)
    ii  libfl-dev:amd64                           2.6.1-1+b1                        amd64        static library for flex (a fast lexical analyzer generator)
    ii  libflac8:amd64                            1.3.1-4                           amd64        Free Lossless Audio Codec - runtime C library
    ii  libflac8:i386                             1.3.1-4                           i386         Free Lossless Audio Codec - runtime C library
    ii  libflashplugin                            24.0.0.186-1                      amd64        flashplayer plugin for internet browser
    ii  libflite1:amd64                           2.0.0-release-3                   amd64        Small run-time speech synthesis engine - shared libraries
    ii  libfluidsynth1:amd64                      1.1.6-3+b1                        amd64        Real-time MIDI software synthesizer (runtime library)
    ii  libfont-afm-perl                          1.20-1                            all          Font::AFM - Interface to Adobe Font Metrics files
    ii  libfontconfig1:amd64                      2.12.1-1                          amd64        generic font configuration library - runtime
    ii  libfontconfig1:i386                       2.12.1-1                          i386         generic font configuration library - runtime
    ii  libfontconfig1-dev:amd64                  2.12.1-1                          amd64        generic font configuration library - development
    ii  libfontembed1:amd64                       1.11.6-1+b1                       amd64        OpenPrinting CUPS Filters - Font Embed Shared library
    ii  libfontenc1:amd64                         1:1.1.3-1                         amd64        X11 font encoding library
    ii  libfreehand-0.1-1                         0.1.1-2                           amd64        Library for parsing the FreeHand file format structure
    ii  libfreeimage3:amd64                       3.17.0+ds1-3                      amd64        Support library for graphics image formats (library)
    ii  libfreetype6:amd64                        2.6.5-5.0                         amd64        FreeType 2 font engine, shared library files
    ii  libfreetype6:i386                         2.6.5-5.0                         i386         FreeType 2 font engine, shared library files
    ii  libfreetype6-dev                          2.6.5-5.0                         amd64        FreeType 2 font engine, development files
    ii  libfreexl1:amd64                          1.0.2-2                           amd64        library for direct reading of Microsoft Excel spreadsheets
    ii  libfribidi0:amd64                         0.19.7-1                          amd64        Free Implementation of the Unicode BiDi algorithm
    ii  libfuse2:amd64                            2.9.7-1                           amd64        Filesystem in Userspace (library)
    ii  libgail-3-0:amd64                         3.22.2-1                          amd64        GNOME Accessibility Implementation Library -- shared libraries
    ii  libgail-common:amd64                      2.24.31-1                         amd64        GNOME Accessibility Implementation Library -- common modules
    ii  libgail18:amd64                           2.24.31-1                         amd64        GNOME Accessibility Implementation Library -- shared libraries
    ii  libgbm1:amd64                             12.0.3-3                          amd64        generic buffer management API -- runtime
    ii  libgcc-4.9-dev:amd64                      4.9.4-2                           amd64        GCC support library (development files)
    ii  libgcc-5-dev:amd64                        5.4.1-3                           amd64        GCC support library (development files)
    ii  libgcc-6-dev:amd64                        6.2.0-11                          amd64        GCC support library (development files)
    ii  libgcc1:amd64                             1:6.2.0-11                        amd64        GCC support library
    ii  libgcc1:i386                              1:6.2.0-11                        i386         GCC support library
    ii  libgck-1-0:amd64                          3.20.0-3                          amd64        Glib wrapper library for PKCS#11 - runtime
    ii  libgconf-2-4:amd64                        3.2.6-4                           amd64        GNOME configuration database system (shared libraries)
    ii  libgcr-3-common                           3.20.0-3                          all          Library for Crypto UI related tasks - common files
    ii  libgcr-base-3-1:amd64                     3.20.0-3                          amd64        Library for Crypto related tasks
    ii  libgcr-ui-3-1:amd64                       3.20.0-3                          amd64        Library for Crypto UI related tasks
    ii  libgcrypt11:amd64                         1.5.4-1                           amd64        LGPL Crypto library - runtime library
    ii  libgcrypt20:amd64                         1.7.3-2                           amd64        LGPL Crypto library - runtime library
    ii  libgcrypt20:i386                          1.7.3-2                           i386         LGPL Crypto library - runtime library
    ii  libgcrypt20-dev                           1.7.3-2                           amd64        LGPL Crypto library - development files
    ii  libgd3:amd64                              2.2.3-87-gd0fec80-3               amd64        GD Graphics Library
    ii  libgd3:i386                               2.2.3-87-gd0fec80-3               i386         GD Graphics Library
    ii  libgdal20                                 2.1.2+dfsg-1+b1                   amd64        Geospatial Data Abstraction Library
    ii  libgdata-common                           0.17.6-2                          all          Library for accessing GData webservices - common data files
    ii  libgdata22:amd64                          0.17.6-2                          amd64        Library for accessing GData webservices - shared libraries
    ii  libgdbm3:amd64                            1.8.3-14                          amd64        GNU dbm database routines (runtime version)
    ii  libgdk-pixbuf2.0-0:amd64                  2.36.0-1                          amd64        GDK Pixbuf library
    rc  libgdk-pixbuf2.0-0:i386                   2.34.0-1                          i386         GDK Pixbuf library
    ii  libgdk-pixbuf2.0-common                   2.36.0-1                          all          GDK Pixbuf library - data files
    ii  libgdk-pixbuf2.0-dev                      2.36.0-1                          amd64        GDK Pixbuf library (development files)
    ii  libgee-0.8-2:amd64                        0.18.1-1                          amd64        GObject based collection and utility library
    ii  libgee-0.8-dev:amd64                      0.18.1-1                          amd64        GObject based collection and utility library (development files)
    ii  libgee-dev                                0.6.8-2                           amd64        GObject based collection library (development files)
    ii  libgee2:amd64                             0.6.8-2                           amd64        GObject based collection library
    ii  libgegl-0.3-0:amd64                       0.3.8-3                           amd64        Generic Graphics Library
    ii  libgeoclue-2-0:amd64                      2.4.4-1                           amd64        convenience library to interact with geoinformation service
    ii  libgeoclue0:amd64                         0.12.99-4                         amd64        C API for GeoClue
    ii  libgeoip1:amd64                           1.6.9-4                           amd64        non-DNS IP-to-country resolver library
    ii  libgeos-3.5.1                             3.5.1-3                           amd64        Geometry engine for Geographic Information Systems - C++ Library
    ii  libgeos-c1v5                              3.5.1-3                           amd64        Geometry engine for Geographic Information Systems - C Library
    ii  libgeotiff2:amd64                         1.4.2-2+b1                        amd64        GeoTIFF (geografic enabled TIFF) library -- run-time files
    ii  libgettextpo0:amd64                       0.19.8.1-1                        amd64        GNU Internationalization library
    ii  libgfortran-5-dev:amd64                   5.4.1-3                           amd64        Runtime library for GNU Fortran applications (development files)
    ii  libgfortran-6-dev:amd64                   6.2.0-11                          amd64        Runtime library for GNU Fortran applications (development files)
    ii  libgfortran3:amd64                        6.2.0-11                          amd64        Runtime library for GNU Fortran applications
    ii  libgif4:amd64                             4.1.6-11                          amd64        library for GIF images (library)
    ii  libgif4:i386                              4.1.6-11                          i386         library for GIF images (library)
    ii  libgif7:amd64                             5.1.4-0.4                         amd64        library for GIF images (library)
    ii  libgimp2.0                                2.8.18-1                          amd64        Libraries for the GNU Image Manipulation Program
    ii  libgirepository-1.0-1:amd64               1.50.0-1                          amd64        Library for handling GObject introspection data (runtime library)
    ii  libgjs0e                                  1.46.0-1+b1                       amd64        Mozilla-based javascript bindings for the GNOME platform
    ii  libgksu2-0                                2.0.13~pre1-60                    amd64        library providing su and sudo functionality
    ii  libgl1-mesa-dev:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX development files
    ii  libgl1-mesa-dri:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-dri:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-glx:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX runtime
    ii  libgl1-mesa-glx:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- GLX runtime
    ii  libgl2ps1                                 1.3.9-4                           amd64        Lib providing high quality vector output for OpenGL application
    ii  libglade2-0:amd64                         1:2.6.4-2                         amd64        library to load .glade files at runtime
    ii  libglapi-mesa:amd64                       12.0.3-3                          amd64        free implementation of the GL API -- shared library
    ii  libglapi-mesa:i386                        12.0.3-3                          i386         free implementation of the GL API -- shared library
    ii  libgles1-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 1.x API -- runtime
    ii  libgles2-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 2.x API -- runtime
    ii  libglew1.13:amd64                         1.13.0-2                          amd64        OpenGL Extension Wrangler - runtime environment
    ii  libglew2.0:amd64                          2.0.0-3                           amd64        OpenGL Extension Wrangler - runtime environment
    ii  libglib-perl                              3:1.323-1                         amd64        interface to the GLib and GObject libraries
    ii  libglib2.0-0:amd64                        2.50.2-1                          amd64        GLib library of C routines
    ii  libglib2.0-0:i386                         2.50.2-1                          i386         GLib library of C routines
    ii  libglib2.0-bin                            2.50.2-1                          amd64        Programs for the GLib library
    ii  libglib2.0-data                           2.50.2-1                          all          Common files for GLib library
    ii  libglib2.0-dev                            2.50.2-1                          amd64        Development files for the GLib library
    ii  libglibmm-2.4-1v5:amd64                   2.50.0-1                          amd64        C++ wrapper for the GLib toolkit (shared libraries)
    ii  libglpk40:amd64                           4.60-2+b1                         amd64        linear programming kit with integer (MIP) support
    ii  libgltf-0.0-0v5:amd64                     0.0.2-5                           amd64        Library for rendering glTF models
    ii  libglu1-mesa:amd64                        9.0.0-2.1                         amd64        Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa:i386                         9.0.0-2.1                         i386         Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa-dev:amd64                    9.0.0-2.1                         amd64        Mesa OpenGL utility library -- development files
    ii  libgme0:amd64                             0.6.0-4                           amd64        Playback library for video game music files - shared library
    ii  libgmp-dev:amd64                          2:6.1.1+dfsg-1                    amd64        Multiprecision arithmetic library developers tools
    ii  libgmp10:amd64                            2:6.1.1+dfsg-1                    amd64        Multiprecision arithmetic library
    ii  libgmp10:i386                             2:6.1.1+dfsg-1                    i386         Multiprecision arithmetic library
    ii  libgmp3-dev                               2:6.1.1+dfsg-1                    amd64        Multiprecision arithmetic library developers tools
    ii  libgmpxx4ldbl:amd64                       2:6.1.1+dfsg-1                    amd64        Multiprecision arithmetic library (C++ bindings)
    ii  libgnome-2-0:amd64                        2.32.1-5                          amd64        The GNOME library - runtime files
    ii  libgnome-desktop-3-12:amd64               3.22.1-1                          amd64        Utility library for loading .desktop files - runtime files
    ii  libgnome-keyring-common                   3.12.0-1                          all          GNOME keyring services library - data files
    ii  libgnome-keyring0:amd64                   3.12.0-1+b1                       amd64        GNOME keyring services library
    ii  libgnome2-bin                             2.32.1-5                          amd64        The GNOME library - binary files
    ii  libgnome2-common                          2.32.1-5                          all          The GNOME library - common files
    ii  libgnome2-gconf-perl                      1.044-6+b1                        amd64        Perl interface to the GNOME GConf library
    ii  libgnomevfs2-0:amd64                      1:2.24.4-6.1+b1                   amd64        GNOME Virtual File System (runtime libraries)
    ii  libgnomevfs2-common                       1:2.24.4-6.1                      all          GNOME Virtual File System (common files)
    ii  libgnutls-dane0:amd64                     3.5.7-3                           amd64        GNU TLS library - DANE security support
    ii  libgnutls-deb0-28:amd64                   3.3.20-1                          amd64        GNU TLS library - main runtime library
    ii  libgnutls-deb0-28:i386                    3.3.20-1                          i386         GNU TLS library - main runtime library
    ii  libgnutls-openssl27:amd64                 3.5.7-3                           amd64        GNU TLS library - OpenSSL wrapper
    ii  libgnutls28-dev:amd64                     3.5.7-3                           amd64        GNU TLS library - development files
    ii  libgnutls30:amd64                         3.5.7-3                           amd64        GNU TLS library - main runtime library
    ii  libgnutls30:i386                          3.5.7-3                           i386         GNU TLS library - main runtime library
    ii  libgnutlsxx28:amd64                       3.5.7-3                           amd64        GNU TLS library - C++ runtime library
    ii  libgoa-1.0-0b:amd64                       3.22.1-1                          amd64        library for GNOME Online Accounts
    ii  libgoa-1.0-common                         3.22.1-1                          all          library for GNOME Online Accounts - common files
    ii  libgomp1:amd64                            6.2.0-11                          amd64        GCC OpenMP (GOMP) support library
    ii  libgomp1:i386                             6.2.0-11                          i386         GCC OpenMP (GOMP) support library
    ii  libgpg-error-dev                          1.24-1                            amd64        library for common error values and messages in GnuPG components (development)
    ii  libgpg-error0:amd64                       1.24-1                            amd64        library for common error values and messages in GnuPG components
    ii  libgpg-error0:i386                        1.24-1                            i386         library for common error values and messages in GnuPG components
    ii  libgpgme11:amd64                          1.7.0-1                           amd64        GPGME - GnuPG Made Easy (library)
    ii  libgphoto2-6:amd64                        2.5.10-3                          amd64        gphoto2 digital camera library
    ii  libgphoto2-6:i386                         2.5.10-3                          i386         gphoto2 digital camera library
    ii  libgphoto2-l10n                           2.5.10-3                          all          gphoto2 digital camera library - localized messages
    ii  libgphoto2-port12:amd64                   2.5.10-3                          amd64        gphoto2 digital camera port library
    ii  libgphoto2-port12:i386                    2.5.10-3                          i386         gphoto2 digital camera port library
    ii  libgpm2:amd64                             1.20.4-6.2                        amd64        General Purpose Mouse - shared library
    ii  libgraphite2-3:amd64                      1.3.8-1                           amd64        Font rendering engine for Complex Scripts -- library
    ii  libgraphite2-3:i386                       1.3.8-1                           i386         Font rendering engine for Complex Scripts -- library
    ii  libgraphite2-dev                          1.3.8-1                           amd64        Development files for libgraphite2
    ii  libgraphviz-dev                           2.38.0-16                         amd64        graphviz libs and headers against which to build applications
    rc  libgroupsock1                             2014.01.13-1                      amd64        multimedia RTSP streaming library (network interfaces and sockets)
    ii  libgroupsock8:amd64                       2016.11.06-1                      amd64        multimedia RTSP streaming library (network interfaces and sockets)
    ii  libgs9:amd64                              9.19~dfsg-3.1                     amd64        interpreter for the PostScript language and for PDF - Library
    ii  libgs9-common                             9.19~dfsg-3.1                     all          interpreter for the PostScript language and for PDF - common files
    ii  libgsettings-qt1:amd64                    0.1+16.04.20160329~1              amd64        Library to access GSettings from Qt
    rc  libgsl0ldbl:amd64                         1.16+dfsg-4                       amd64        GNU Scientific Library (GSL) -- library package
    ii  libgsl2:amd64                             2.2.1+dfsg-1                      amd64        GNU Scientific Library (GSL) -- library package
    ii  libgsm1:amd64                             1.0.13-4                          amd64        Shared libraries for GSM speech compressor
    ii  libgsm1:i386                              1.0.13-4                          i386         Shared libraries for GSM speech compressor
    ii  libgsoap10:amd64                          2.8.35-3                          amd64        Runtime libraries for gSOAP
    ii  libgspell-1-1:amd64                       1.2.0-2                           amd64        spell-checking library for GTK+ applications
    ii  libgspell-1-common                        1.2.0-2                           all          libgspell architecture-independent files
    ii  libgssapi-krb5-2:amd64                    1.15~beta1-1                      amd64        MIT Kerberos runtime libraries - krb5 GSS-API Mechanism
    ii  libgssapi-krb5-2:i386                     1.15~beta1-1                      i386         MIT Kerberos runtime libraries - krb5 GSS-API Mechanism
    ii  libgssapi3-heimdal:amd64                  1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - GSSAPI support library
    ii  libgssdp-1.0-3:amd64                      1.0.1-1                           amd64        GObject-based library for SSDP
    ii  libgssglue1:amd64                         0.4-2                             amd64        mechanism-switch gssapi library
    ii  libgstreamer-plugins-bad0.10-0:amd64      0.10.23-9                         amd64        GStreamer development files for libraries from the "bad" set
    ii  libgstreamer-plugins-bad1.0-0:amd64       1.10.2-1                          amd64        GStreamer development files for libraries from the "bad" set
    ii  libgstreamer-plugins-base0.10-0:amd64     0.10.36-2                         amd64        GStreamer libraries from the "base" set
    ii  libgstreamer-plugins-base0.10-0:i386      0.10.36-2                         i386         GStreamer libraries from the "base" set
    ii  libgstreamer-plugins-base1.0-0:amd64      1.10.0-1                          amd64        GStreamer libraries from the "base" set
    ii  libgstreamer0.10-0:amd64                  0.10.36-1.5                       amd64        Core GStreamer libraries and elements
    ii  libgstreamer0.10-0:i386                   0.10.36-1.5                       i386         Core GStreamer libraries and elements
    ii  libgstreamer1.0-0:amd64                   1.10.0-1                          amd64        Core GStreamer libraries and elements
    ii  libgtk-3-0:amd64                          3.22.2-1                          amd64        GTK+ graphical user interface library
    ii  libgtk-3-bin                              3.22.2-1                          amd64        programs for the GTK+ graphical user interface library
    ii  libgtk-3-common                           3.22.2-1                          all          common files for the GTK+ graphical user interface library
    ii  libgtk-3-dev:amd64                        3.22.2-1                          amd64        development files for the GTK+ library
    ii  libgtk2-ex-simple-list-perl               0.50-2                            all          simple interface to Gtk2's complex MVC list widget
    ii  libgtk2-gladexml-perl                     1.007-2+b3                        amd64        Perl interface to use user interfaces created with glade-2
    ii  libgtk2-perl                              2:1.2499-1                        amd64        Perl interface to the 2.x series of the Gimp Toolkit library
    ii  libgtk2-unique-perl                       0.05-2+b3                         amd64        module for single instance applications
    ii  libgtk2.0-0:amd64                         2.24.31-1                         amd64        GTK+ graphical user interface library
    rc  libgtk2.0-0:i386                          2.24.30-1.1                       i386         GTK+ graphical user interface library
    ii  libgtk2.0-bin                             2.24.31-1                         amd64        programs for the GTK+ graphical user interface library
    ii  libgtk2.0-common                          2.24.31-1                         all          common files for the GTK+ graphical user interface library
    ii  libgtk2.0-dev                             2.24.31-1                         amd64        development files for the GTK+ library
    ii  libgtkglext1                              1.2.0-4                           amd64        OpenGL Extension to GTK+ (shared libraries)
    rc  libgtkhotkey1:amd64                       0.2.1-6                           amd64        Gtk hotkey shared library
    ii  libgtkmm-2.4-1v5:amd64                    1:2.24.5-1                        amd64        C++ wrappers for GTK+ (shared libraries)
    ii  libgtkmm-3.0-1v5:amd64                    3.22.0-1                          amd64        C++ wrappers for GTK+ (shared libraries)
    ii  libgtksourceview-3.0-1:amd64              3.22.1-1                          amd64        shared libraries for the GTK+ syntax highlighting widget
    ii  libgtksourceview-3.0-common               3.22.1-1                          all          common files for the GTK+ syntax highlighting widget
    ii  libgtop-2.0-10:amd64                      2.34.1-2                          amd64        gtop system monitoring library (shared)
    ii  libgtop2-common                           2.34.1-2                          all          gtop system monitoring library (common)
    ii  libgts-0.7-5:amd64                        0.7.6+darcs121130-1.2             amd64        library to deal with 3D computational surface meshes
    ii  libgts-bin                                0.7.6+darcs121130-1.2             amd64        utility binaries for libgts
    ii  libgudev-1.0-0:amd64                      230-3                             amd64        GObject-based wrapper library for libudev
    ii  libgupnp-1.0-4:amd64                      1.0.1-1                           amd64        GObject-based library for UPnP
    ii  libgupnp-av-1.0-2                         0.12.10-1                         amd64        Audio/Visual utility library for GUPnP
    ii  libgupnp-dlna-2.0-3                       0.10.5-3                          amd64        DLNA utility library for GUPnP
    ii  libgusb2:amd64                            0.2.9-1                           amd64        GLib wrapper around libusb1
    ii  libgvc6                                   2.38.0-16                         amd64        rich set of graph drawing tools - gvc library
    ii  libgvc6-plugins-gtk                       2.38.0-16                         amd64        rich set of graph drawing tools - gtk plugins
    ii  libgvpr2                                  2.38.0-16                         amd64        rich set of graph drawing tools - gvpr library
    ii  libgxps2:amd64                            0.2.4-1                           amd64        handling and rendering XPS documents (library)
    ii  libharfbuzz-dev:amd64                     1.2.7-1+b1                        amd64        Development files for OpenType text shaping engine
    ii  libharfbuzz-gobject0:amd64                1.2.7-1+b1                        amd64        OpenType text shaping engine ICU backend (GObject library)
    ii  libharfbuzz-icu0:amd64                    1.2.7-1+b1                        amd64        OpenType text shaping engine ICU backend
    ii  libharfbuzz0b:amd64                       1.2.7-1+b1                        amd64        OpenType text shaping engine (shared library)
    ii  libharfbuzz0b:i386                        1.2.7-1+b1                        i386         OpenType text shaping engine (shared library)
    ii  libhcrypto4-heimdal:amd64                 1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - crypto library
    ii  libhdf4-0                                 4.2.12-1                          amd64        Hierarchical Data Format library (embedded NetCDF)
    ii  libhdf4-0-alt                             4.2.12-1                          amd64        Hierarchical Data Format library (without NetCDF)
    ii  libhdf5-10:amd64                          1.8.16+docs-8+b1                  amd64        Hierarchical Data Format 5 (HDF5) - runtime files - serial version
    ii  libhdf5-100:amd64                         1.10.0-patch1+docs-3              amd64        Hierarchical Data Format 5 (HDF5) - runtime files - serial version
    ii  libhdf5-openmpi-10:amd64                  1.8.16+docs-8+b1                  amd64        Hierarchical Data Format 5 (HDF5) - runtime files - OpenMPI version
    ii  libheimbase1-heimdal:amd64                1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - Base library
    ii  libheimntlm0-heimdal:amd64                1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - NTLM support library
    ii  libhogweed4:amd64                         3.3-1                             amd64        low level cryptographic library (public-key cryptos)
    ii  libhogweed4:i386                          3.3-1                             i386         low level cryptographic library (public-key cryptos)
    ii  libhsqldb1.8.0-java                       1.8.0.10+dfsg-7                   all          Java SQL database engine
    ii  libhtml-form-perl                         6.03-1                            all          module that represents an HTML form element
    ii  libhtml-format-perl                       2.11-2                            all          module for transforming HTML into various formats
    ii  libhtml-parser-perl                       3.72-2+b1                         amd64        collection of modules that parse HTML text documents
    ii  libhtml-tagset-perl                       3.20-2                            all          Data tables pertaining to HTML
    ii  libhtml-template-perl                     2.95-2                            all          module for using HTML templates with Perl
    ii  libhtml-tree-perl                         5.03-2                            all          Perl module to represent and create HTML syntax trees
    ii  libhttp-cookies-perl                      6.01-1                            all          HTTP cookie jars
    ii  libhttp-daemon-perl                       6.01-1                            all          simple http server class
    ii  libhttp-date-perl                         6.02-1                            all          module of date conversion routines
    ii  libhttp-message-perl                      6.11-1                            all          perl interface to HTTP style messages
    ii  libhttp-negotiate-perl                    6.00-2                            all          implementation of content negotiation
    ii  libhunspell-1.3-0:amd64                   1.3.4-2                           amd64        spell checker and morphological analyzer (shared library)
    ii  libhunspell-1.4-0:amd64                   1.4.1-2+b1                        amd64        spell checker and morphological analyzer (shared library)
    ii  libhwloc-plugins                          1.11.4-1                          amd64        Hierarchical view of the machine - plugins
    ii  libhwloc5:amd64                           1.11.4-1                          amd64        Hierarchical view of the machine - shared libs
    ii  libhx509-5-heimdal:amd64                  1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - X509 support library
    ii  libhyphen0:amd64                          2.8.8-5                           amd64        ALTLinux hyphenation library - shared library
    ii  libibverbs1                               1.2.1-2                           amd64        Library for direct userspace use of RDMA (InfiniBand/iWARP)
    ii  libice-dev:amd64                          2:1.0.9-1+b1                      amd64        X11 Inter-Client Exchange library (development headers)
    ii  libice6:amd64                             2:1.0.9-1+b1                      amd64        X11 Inter-Client Exchange library
    ii  libice6:i386                              2:1.0.9-1+b1                      i386         X11 Inter-Client Exchange library
    ii  libicu-dev                                57.1-5                            amd64        Development files for International Components for Unicode
    ii  libicu55:amd64                            55.1-7                            amd64        International Components for Unicode
    ii  libicu55:i386                             55.1-7                            i386         International Components for Unicode
    ii  libicu57:amd64                            57.1-5                            amd64        International Components for Unicode
    ii  libicu57:i386                             57.1-5                            i386         International Components for Unicode
    ii  libid3tag0:amd64                          0.15.1b-12                        amd64        ID3 tag reading library from the MAD project
    ii  libidn11:amd64                            1.33-1                            amd64        GNU Libidn library, implementation of IETF IDN specifications
    ii  libidn11:i386                             1.33-1                            i386         GNU Libidn library, implementation of IETF IDN specifications
    ii  libidn11-dev                              1.33-1                            amd64        Development files for GNU Libidn, an IDN library
    ii  libiec61883-0:amd64                       1.2.0-2                           amd64        partial implementation of IEC 61883 (shared lib)
    ii  libieee1284-3:amd64                       0.2.11-12                         amd64        cross-platform library for parallel port access
    ii  libieee1284-3:i386                        0.2.11-12                         i386         cross-platform library for parallel port access
    ii  libijs-0.35:amd64                         0.35-12                           amd64        IJS raster image transport protocol: shared library
    ii  libilmbase-dev                            2.2.0-11                          amd64        development files for IlmBase
    ii  libilmbase12:amd64                        2.2.0-11                          amd64        several utility libraries from ILM used by OpenEXR
    ii  libilmbase6v5:amd64                       1.0.1-6.2                         amd64        several utility libraries from ILM used by OpenEXR
    ii  libimlib2:amd64                           1.4.8-1                           amd64        image loading, rendering, saving library
    ii  libimobiledevice4:amd64                   1.1.6+dfsg-3.1+b1                 amd64        Library for communicating with the iPhone and iPod Touch
    ii  libimobiledevice6:amd64                   1.2.0+dfsg-4deepin                amd64        Library for communicating with the iPhone and iPod Touch
    ii  libindicator7:amd64                       0.5.0-3                           amd64        panel indicator applet - shared library
    ii  libinput-bin                              1.5.0-1                           amd64        input device management and event handling library - udev quirks
    ii  libinput10:amd64                          1.5.0-1                           amd64        input device management and event handling library - shared library
    ii  libio-html-perl                           1.001-1                           all          open an HTML file with automatic charset detection
    ii  libio-pty-perl                            1:1.08-1.1+b2                     amd64        Perl module for pseudo tty IO
    ii  libio-socket-inet6-perl                   2.72-2                            all          object interface for AF_INET6 domain sockets
    ii  libio-socket-ssl-perl                     2.038-1                           all          Perl module implementing object oriented interface to SSL sockets
    ii  libio-string-perl                         1.08-3                            all          Emulate IO::File interface for in-core strings
    ii  libio-stty-perl                           0.03-1.1                          all          Interface to secure pseudo ttys
    ii  libip4tc0:amd64                           1.6.0-4                           amd64        netfilter libip4tc library
    ii  libip6tc0:amd64                           1.6.0-4                           amd64        netfilter libip6tc library
    ii  libipc-run-perl                           0.94-1                            all          Perl module for running processes
    ii  libipc-system-simple-perl                 1.25-3                            all          Perl module to run commands simply, with detailed diagnostics
    ii  libiptc0:amd64                            1.6.0-4                           amd64        netfilter libiptc library
    ii  libiptcdata0                              1.0.4-6                           amd64        Library to parse IPTC metadata
    ii  libisc-export160                          1:9.10.3.dfsg.P4-10.1             amd64        Exported ISC Shared Library
    ii  libisc-export95                           1:9.9.5.dfsg-12.1                 amd64        Exported ISC Shared Library
    ii  libisc160:amd64                           1:9.10.3.dfsg.P4-10.1             amd64        ISC Shared Library used by BIND
    ii  libisc95                                  1:9.9.5.dfsg-12.1                 amd64        ISC Shared Library used by BIND
    ii  libisccc140:amd64                         1:9.10.3.dfsg.P4-10.1             amd64        Command Channel Library used by BIND
    ii  libisccc90                                1:9.9.5.dfsg-12.1                 amd64        Command Channel Library used by BIND
    ii  libisccfg140:amd64                        1:9.10.3.dfsg.P4-10.1             amd64        Config File Handling Library used by BIND
    ii  libisccfg90                               1:9.9.5.dfsg-12.1                 amd64        Config File Handling Library used by BIND
    ii  libisl15:amd64                            0.17.1-1                          amd64        manipulating sets and relations of integer points bounded by linear constraints
    ii  libiso9660-8                              0.83-4.2+b1                       amd64        library to work with ISO9660 filesystems
    ii  libitm1:amd64                             6.2.0-11                          amd64        GNU Transactional Memory Library
    ii  libiw30:amd64                             30~pre9-12                        amd64        Wireless tools - library
    ii  libjack-jackd2-0:amd64                    1.9.10+20150825git1ed50c92~dfsg-3 amd64        JACK Audio Connection Kit (libraries)
    ii  libjack-jackd2-0:i386                     1.9.10+20150825git1ed50c92~dfsg-3 i386         JACK Audio Connection Kit (libraries)
    ii  libjansson4:amd64                         2.7-5                             amd64        C library for encoding, decoding and manipulating JSON data
    ii  libjasper1:amd64                          1.900.1-debian1-2.4+deb8u1        amd64        JasPer JPEG-2000 runtime library
    ii  libjavascriptcoregtk-1.0-0:amd64          2.4.11-3                          amd64        JavaScript engine library from WebKitGTK+
    ii  libjavascriptcoregtk-3.0-0:amd64          2.4.11-3                          amd64        JavaScript engine library from WebKitGTK+
    ii  libjavascriptcoregtk-4.0-18:amd64         2.14.2-1                          amd64        JavaScript engine library from WebKitGTK+
    ii  libjbig-dev:amd64                         2.1-3.1                           amd64        JBIGkit development files
    ii  libjbig0:amd64                            2.1-3.1                           amd64        JBIGkit libraries
    ii  libjbig0:i386                             2.1-3.1                           i386         JBIGkit libraries
    ii  libjbig2dec0:amd64                        0.13-3                            amd64        JBIG2 decoder library - shared libraries
    ii  libjgraph-java                            5.12.4.2+dfsg-4                   all          JFC/Swing graph component for Java
    ii  libjhdf4-java                             2.11.0+dfsg-2deepin               amd64        Java HDF4 Object Package
    ii  libjhdf4-jni                              2.11.0+dfsg-2deepin               amd64        Java HDF4 Object Package (Java JNI library)
    ii  libjhdf5-java                             2.11.0+dfsg-2deepin               amd64        Java HDF5 Object Package
    ii  libjhdf5-jni                              2.11.0+dfsg-2deepin               amd64        Java HDF5 Object Package (Java JNI library)
    ii  libjpeg-dev                               1:1.5.1-2                         all          Development files for the JPEG library [dummy package]
    ii  libjpeg62-turbo:amd64                     1:1.5.1-2                         amd64        libjpeg-turbo JPEG runtime library
    ii  libjpeg62-turbo:i386                      1:1.5.1-2                         i386         libjpeg-turbo JPEG runtime library
    ii  libjpeg62-turbo-dev:amd64                 1:1.5.1-2                         amd64        Development files for the libjpeg-turbo JPEG library
    ii  libjpeg8:i386                             8d1-2                             i386         Independent JPEG Group's JPEG runtime library
    ii  libjs-bowser                              0.7.3-2                           all          JavaScript browser detection library
    ii  libjs-events                              1.0.2-2                           all          Node EventEmitter
    ii  libjs-excanvas                            0.r3-4                            all          HTML5 Canvas for Internet Explorer
    ii  libjs-inherits                            2.0.1-3                           all          Exposes inherits function from Node.js environment
    ii  libjs-is-typedarray                       1.0.0-2                           all          JavaScript library checking if object is TypedArray
    ii  libjs-jquery                              3.1.1-1                           all          JavaScript library for dynamic web applications
    ii  libjs-jquery-ui                           1.12.1+dfsg-1                     all          JavaScript UI library for dynamic web applications
    ii  libjs-jssip                               0.6.34-5                          all          JavaScript implementation of a WebRTC SIP video phone
    ii  libjs-mathjax                             2.7.0-1                           all          JavaScript display engine for LaTeX and MathML
    ii  libjs-merge                               1.2.0-2                           all          JavaScript utility for merging multiple objects into one.
    ii  libjs-modernizr                           2.6.2+ds1-1                       all          JavaScript library to detect HTML5 and CSS3 features in the user's browser
    ii  libjs-node-uuid                           1.4.0-1                           all          simple, fast generation of RFC4122 UUIDs - JavaScript library
    ii  libjs-rtcninja                            0.6.2-2                           all          JavaScript abstraction layer for WebRTC API
    ii  libjs-sdp-transform                       1.4.0-2                           all          JavaScript parser/writer for Session Description Protocol
    ii  libjs-sphinxdoc                           1.4.8-1                           all          JavaScript support for Sphinx documentation
    ii  libjs-typedarray-to-buffer                3.0.3-3                           all          JavaScript utility converting TypedArray to buffer without copy
    ii  libjs-underscore                          1.8.3~dfsg-1                      all          JavaScript's functional programming helper library
    ii  libjs-util                                0.10.3-2                          all          NodeJS/JavaScript util module
    ii  libjs-websocket                           1.0.22-2                          all          WebSocket implementation for NodeJS, standalone API for browser
    ii  libjson-c2:amd64                          0.11-4                            amd64        JSON manipulation library - shared library
    ii  libjson-c2:i386                           0.11-4                            i386         JSON manipulation library - shared library
    ii  libjson-c3:amd64                          0.12.1-1                          amd64        JSON manipulation library - shared library
    ii  libjson-glib-1.0-0:amd64                  1.2.2-1                           amd64        GLib JSON manipulation library
    ii  libjson-glib-1.0-common                   1.2.2-1                           all          GLib JSON manipulation library (common files)
    ii  libjson-glib-dev:amd64                    1.2.2-1                           amd64        GLib JSON manipulation library (development files)
    rc  libjsoncpp0v5:amd64                       0.10.5-1                          amd64        library for reading and writing JSON for C++
    ii  libjsoncpp1:amd64                         1.7.4-3                           amd64        library for reading and writing JSON for C++
    ii  libjxr-tools                              1.1-6                             amd64        JPEG-XR lib - command line apps
    ii  libjxr0:amd64                             1.1-6                             amd64        JPEG-XR lib - libraries
    ii  libk5crypto3:amd64                        1.15~beta1-1                      amd64        MIT Kerberos runtime libraries - Crypto Library
    ii  libk5crypto3:i386                         1.15~beta1-1                      i386         MIT Kerberos runtime libraries - Crypto Library
    ii  libkate1:amd64                            0.4.1-7+b1                        amd64        Codec for karaoke and text encapsulation
    ii  libkeybinder0                             0.3.1-1                           amd64        registers global key bindings for applications
    ii  libkeyutils1:amd64                        1.5.9-9                           amd64        Linux Key Management Utilities (library)
    ii  libkeyutils1:i386                         1.5.9-9                           i386         Linux Key Management Utilities (library)
    ii  libklibc                                  2.0.4-9                           amd64        minimal libc subset for use with initramfs
    ii  libkmlbase1:amd64                         1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmlbase
    ii  libkmlconvenience1:amd64                  1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmlconvenience
    ii  libkmldom1:amd64                          1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmldom
    ii  libkmlengine1:amd64                       1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmlengine
    ii  libkmlregionator1:amd64                   1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmlregionator
    ii  libkmlxsd1:amd64                          1.3.0-3                           amd64        Library to manipulate KML 2.2 OGC standard files - libkmlxsd
    ii  libkmod2:amd64                            23-1                              amd64        libkmod shared library
    ii  libkpathsea6:amd64                        2016.20160513.41080-7+b1          amd64        TeX Live: path search library for TeX (runtime part)
    ii  libkrb5-26-heimdal:amd64                  1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - libraries
    ii  libkrb5-3:amd64                           1.15~beta1-1                      amd64        MIT Kerberos runtime libraries
    ii  libkrb5-3:i386                            1.15~beta1-1                      i386         MIT Kerberos runtime libraries
    ii  libkrb5support0:amd64                     1.15~beta1-1                      amd64        MIT Kerberos runtime libraries - Support library
    ii  libkrb5support0:i386                      1.15~beta1-1                      i386         MIT Kerberos runtime libraries - Support library
    ii  libksba8:amd64                            1.3.5-2                           amd64        X.509 and CMS support library
    ii  liblangtag-common                         0.6.2-1                           all          library to access tags for identifying languages -- data
    ii  liblangtag1:amd64                         0.6.2-1                           amd64        library to access tags for identifying languages
    ii  liblapack-dev                             3.6.1-2                           amd64        Library of linear algebra routines 3 - static version
    ii  liblapack3                                3.6.1-2                           amd64        Library of linear algebra routines 3 - shared version
    ii  liblcms2-2:amd64                          2.7-1                             amd64        Little CMS 2 color management library
    ii  liblcms2-2:i386                           2.7-1                             i386         Little CMS 2 color management library
    ii  liblcms2-dev:amd64                        2.7-1                             amd64        Little CMS 2 color management library development headers
    ii  libldap-2.4-2:amd64                       2.4.42+dfsg-2+b3                  amd64        OpenLDAP libraries
    ii  libldap-2.4-2:i386                        2.4.42+dfsg-2+b3                  i386         OpenLDAP libraries
    ii  libldb1:amd64                             2:1.1.27-1                        amd64        LDAP-like embedded database - shared library
    ii  liblept4                                  1.72-3+b1                         amd64        image processing library
    ii  liblept5                                  1.73-5+b1                         amd64        image processing library
    ii  liblightdm-gobject-1-0                    1.21.3-6                          amd64        simple display manager (gobject library)
    ii  liblightdm-qt5-3-0                        1.21.3-6                          amd64        simple display manager (Qt5 library)
    ii  liblilv-0-0                               0.24.0~dfsg0-1                    amd64        library for simple use of LV2 plugins
    ii  liblirc-client0:amd64                     0.9.4c-4                          amd64        infra-red remote control support - client library
    ii  liblircclient0                            0.9.4c-4                          amd64        Transitional placeholder for obsoleted liblircclient0
    ii  liblist-moreutils-perl                    0.416-1+b1                        amd64        Perl module with additional list functions not found in List::Util
    rc  liblivemedia23                            2014.01.13-1                      amd64        multimedia RTSP streaming library
    ii  liblivemedia57:amd64                      2016.11.06-1                      amd64        multimedia RTSP streaming library
    ii  libllvm3.6v5:amd64                        1:3.6.2-3                         amd64        Modular compiler and toolchain technologies, runtime library
    ii  libllvm3.7:amd64                          1:3.7.1-2                         amd64        Modular compiler and toolchain technologies, runtime library
    ii  libllvm3.7:i386                           1:3.7.1-2                         i386         Modular compiler and toolchain technologies, runtime library
    ii  libllvm3.8:amd64                          1:3.8.1-15                        amd64        Modular compiler and toolchain technologies, runtime library
    ii  libllvm3.8:i386                           1:3.8.1-15                        i386         Modular compiler and toolchain technologies, runtime library
    ii  liblocale-gettext-perl                    1.07-3+b1                         amd64        module using libc functions for internationalization in Perl
    ii  liblogging-stdlog0:amd64                  1.0.5-2                           amd64        easy to use and lightweight logging library
    ii  liblognorm2:amd64                         1.1.2-1.1+b2                      amd64        Log normalizing library
    ii  liblognorm5:amd64                         2.0.1-1.1                         amd64        log normalizing library
    ii  liblouis-data                             3.0.0-3                           all          Braille translation library - data
    ii  liblouis12:amd64                          3.0.0-3                           amd64        Braille translation library - shared libs
    ii  liblouisutdml-bin                         2.6.0-3+b1                        amd64        Braille UTDML translation utilities
    ii  liblouisutdml-data                        2.6.0-3                           all          Braille UTDML translation library - data
    ii  liblouisutdml7:amd64                      2.6.0-3+b1                        amd64        Braille UTDML translation library - shared libs
    ii  liblqr-1-0:amd64                          0.4.2-2                           amd64        converts plain array images into multi-size representation
    ii  liblqr-1-0-dev                            0.4.2-2                           amd64        converts plain array images into multi-size representation (developments files)
    ii  liblsan0:amd64                            6.2.0-11                          amd64        LeakSanitizer -- a memory leak detector (runtime)
    ii  libltdl-dev:amd64                         2.4.6-2                           amd64        System independent dlopen wrapper for GNU libtool
    ii  libltdl7:amd64                            2.4.6-2                           amd64        System independent dlopen wrapper for GNU libtool
    ii  libltdl7:i386                             2.4.6-2                           i386         System independent dlopen wrapper for GNU libtool
    ii  liblua5.1-0:amd64                         5.1.5-8.1+b1                      amd64        Shared library for the Lua interpreter version 5.1
    ii  liblua5.2-0:amd64                         5.2.4-1.1+b1                      amd64        Shared library for the Lua interpreter version 5.2
    ii  liblvm2app2.2:amd64                       2.02.164-1                        amd64        LVM2 application library
    ii  liblvm2cmd2.02:amd64                      2.02.164-1                        amd64        LVM2 command library
    rc  liblwgeom-2.1.8                           2.1.8+dfsg-4                      amd64        PostGIS "Lightweight Geometry" library
    ii  liblwp-mediatypes-perl                    6.02-1                            all          module to guess media type for a file or a URL
    ii  liblwp-protocol-https-perl                6.06-2                            all          HTTPS driver for LWP::UserAgent
    ii  liblwres141:amd64                         1:9.10.3.dfsg.P4-10.1             amd64        Lightweight Resolver Library used by BIND
    ii  liblwres90                                1:9.9.5.dfsg-12.1                 amd64        Lightweight Resolver Library used by BIND
    ii  liblz4-1:amd64                            0.0~r131-2                        amd64        Fast LZ compression algorithm library - runtime
    ii  liblzma-dev:amd64                         5.2.2-1.2                         amd64        XZ-format compression library - development files
    ii  liblzma5:amd64                            5.2.2-1.2                         amd64        XZ-format compression library
    ii  liblzma5:i386                             5.2.2-1.2                         i386         XZ-format compression library
    ii  liblzo2-2:amd64                           2.08-1.2                          amd64        data compression library
    ii  libmad0:amd64                             0.15.1b-8                         amd64        MPEG audio decoder library
    ii  libmagic-mgc                              1:5.29-1                          amd64        File type determination library using "magic" numbers (compiled magic file)
    ii  libmagic1:amd64                           1:5.29-1                          amd64        Recognize the type of data in a file using "magic" numbers - library
    ii  libmagick++-6-headers                     8:6.9.7.0+dfsg-2+deepin           all          object-oriented C++ interface to ImageMagick - header files
    ii  libmagick++-6.q16-7:amd64                 8:6.9.7.0+dfsg-2+deepin           amd64        C++ interface to ImageMagick -- quantum depth Q16
    ii  libmagick++-6.q16-dev:amd64               8:6.9.7.0+dfsg-2+deepin           amd64        C++ interface to ImageMagick - development files (Q16)
    ii  libmagick++-dev                           8:6.9.7.0+dfsg-2+deepin           all          object-oriented C++ interface to ImageMagick -- dummy package
    ii  libmagickcore-6-arch-config:amd64         8:6.9.7.0+dfsg-2+deepin           amd64        low-level image manipulation library - architecture header files
    ii  libmagickcore-6-headers                   8:6.9.7.0+dfsg-2+deepin           all          low-level image manipulation library - header files
    ii  libmagickcore-6.q16-3:amd64               8:6.9.7.0+dfsg-2+deepin           amd64        low-level image manipulation library -- quantum depth Q16
    ii  libmagickcore-6.q16-3-extra:amd64         8:6.9.7.0+dfsg-2+deepin           amd64        low-level image manipulation library - extra codecs (Q16)
    ii  libmagickcore-6.q16-dev:amd64             8:6.9.7.0+dfsg-2+deepin           amd64        low-level image manipulation library - development files (Q16)
    ii  libmagickwand-6-headers                   8:6.9.7.0+dfsg-2+deepin           all          image manipulation library - headers files
    ii  libmagickwand-6.q16-3:amd64               8:6.9.7.0+dfsg-2+deepin           amd64        image manipulation library -- quantum depth Q16
    ii  libmagickwand-6.q16-dev:amd64             8:6.9.7.0+dfsg-2+deepin           amd64        image manipulation library - development files (Q16)
    ii  libmail-sendmail-perl                     0.79.16-1                         all          Send email from a perl script
    ii  libmailtools-perl                         2.13-1                            all          Manipulate email in perl programs
    ii  libmariadbclient18:amd64                  10.0.28-1                         amd64        MariaDB database client library
    ii  libmatheval1:amd64                        1.1.11+dfsg-2                     amd64        GNU library for evaluating symbolic mathematical expressions (runtime)
    ii  libmatroska6v5:amd64                      1.4.5-2                           amd64        extensible open standard audio/video container format (shared library)
    ii  libmbim-glib4:amd64                       1.14.0-1                          amd64        Support library to use the MBIM protocol
    ii  libmbim-proxy                             1.14.0-1                          amd64        Proxy to communicate with MBIM ports
    ii  libmcrypt4                                2.5.8-3.3                         amd64        De-/Encryption Library
    ii  libmediaart-2.0-0:amd64                   1.9.0-2                           amd64        media art extraction and cache management library
    ii  libmediainfo0v5:amd64                     0.7.88-1                          amd64        library for reading metadata from media files -- shared library
    ii  libmetis5:amd64                           5.1.0.dfsg-5                      amd64        Serial Graph Partitioning and Fill-reducing Matrix Ordering
    ii  libmhash2:amd64                           0.9.9.9-7                         amd64        Library for cryptographic hashing and message authentication
    ii  libmimic0:amd64                           1.0.4-2.3                         amd64        A video codec for Mimic V2.x content
    ii  libminizip1:amd64                         1.1-8                             amd64        compression library - minizip library
    ii  libmjpegutils-2.1-0                       1:2.1.0+debian-4+b1               amd64        MJPEG capture/editing/replay and MPEG encoding toolset (library)
    ii  libmm-glib0:amd64                         1.6.2-1                           amd64        D-Bus service for managing modems - shared libraries
    ii  libmms0:amd64                             0.6.4-2                           amd64        MMS stream protocol library - shared library
    ii  libmng1:amd64                             1.0.10+dfsg-3.2                   amd64        Multiple-image Network Graphics library
    ii  libmnl0:amd64                             1.0.4-2                           amd64        minimalistic Netlink communication library
    ii  libmodplug1:amd64                         1:0.8.8.5-3                       amd64        shared libraries for mod music based on ModPlug
    ii  libmount1:amd64                           2.28.2-1                          amd64        device mounting library
    ii  libmount1:i386                            2.28.2-1                          i386         device mounting library
    ii  libmozjs-24-0                             24.2.0-3.1                        amd64        Spidermonkey JavaScript engine
    ii  libmp3lame0:amd64                         3.99.5+repack1-9+b1               amd64        MP3 encoding library
    ii  libmp3lame0:i386                          3.99.5+repack1-9+b1               i386         MP3 encoding library
    ii  libmpc3:amd64                             1.0.3-1                           amd64        multiple precision complex floating-point library
    ii  libmpcdec6:amd64                          2:0.1~r495-1                      amd64        MusePack decoder - library
    ii  libmpdec2:amd64                           2.4.2-1                           amd64        library for decimal floating point arithmetic (runtime library)
    ii  libmpeg2-4:amd64                          0.5.1-7                           amd64        MPEG1 and MPEG2 video decoder library
    ii  libmpeg2encpp-2.1-0                       1:2.1.0+debian-4+b1               amd64        MJPEG capture/editing/replay and MPEG encoding toolset (library)
    ii  libmpfr4:amd64                            3.1.5-1                           amd64        multiple precision floating-point computation
    ii  libmpg123-0:amd64                         1.23.8-1                          amd64        MPEG layer 1/2/3 audio decoder (shared library)
    ii  libmpg123-0:i386                          1.23.8-1                          i386         MPEG layer 1/2/3 audio decoder (shared library)
    ii  libmpich-dev                              3.2-7                             amd64        Development files for MPICH
    ii  libmpich12:amd64                          3.2-7                             amd64        Shared libraries for MPICH
    rc  libmpl1:amd64                             3.1-6                             amd64        Shared libraries for mpl part of MPICH
    ii  libmplex2-2.1-0                           1:2.1.0+debian-4+b1               amd64        MJPEG capture/editing/replay and MPEG encoding toolset (library)
    ii  libmpx0:amd64                             5.4.1-3                           amd64        Intel memory protection extensions (runtime)
    ii  libmpx2:amd64                             6.2.0-11                          amd64        Intel memory protection extensions (runtime)
    ii  libmspub-0.1-1:amd64                      0.1.2-4                           amd64        library for parsing the mspub file structure
    ii  libmtdev1:amd64                           1.1.5-1                           amd64        Multitouch Protocol Translation Library - shared library
    ii  libmtp-common                             1.1.12-1                          all          Media Transfer Protocol (MTP) common files
    ii  libmtp9:amd64                             1.1.12-1                          amd64        Media Transfer Protocol (MTP) library
    ii  libmusicbrainz5-2:amd64                   5.1.0+git20150707-6               amd64        Library to access the MusicBrainz.org database (C wrapper functions)
    ii  libmusicbrainz5cc2v5:amd64                5.1.0+git20150707-6               amd64        Library to access the MusicBrainz.org database
    ii  libmwaw-0.3-3:amd64                       0.3.8-2                           amd64        import library for some old Mac text documents
    ii  libmythes-1.2-0:amd64                     2:1.2.4-3                         amd64        simple thesaurus library
    ii  libnatspec0                               0.3.0-1                           amd64        a library for national and language-specific issues
    ii  libnautilus-extension1a:amd64             3.22.1-2                          amd64        libraries for nautilus components - runtime version
    ii  libncurses5:amd64                         6.0+20160917-1                    amd64        shared libraries for terminal handling
    ii  libncurses5:i386                          6.0+20160917-1                    i386         shared libraries for terminal handling
    ii  libncurses5-dev:amd64                     6.0+20160917-1                    amd64        developer's libraries for ncurses
    ii  libncursesw5:amd64                        6.0+20160917-1                    amd64        shared libraries for terminal handling (wide character support)
    ii  libndp0:amd64                             1.6-1                             amd64        Library for Neighbor Discovery Protocol
    ii  libneon27-gnutls:amd64                    0.30.1-5                          amd64        HTTP and WebDAV client library (GnuTLS enabled)
    ii  libnet-arp-perl                           1.0.8-2+b2                        amd64        module to create ARP packets and lookup for ARP information
    ii  libnet-dns-perl                           1.06-1                            all          Perform DNS queries from a Perl script
    ii  libnet-domain-tld-perl                    1.75-1                            all          list of currently available Top-level Domains (TLDs)
    ii  libnet-http-perl                          6.09-1                            all          module providing low-level HTTP connection client
    ii  libnet-ip-perl                            1.26-1                            all          Perl extension for manipulating IPv4/IPv6 addresses
    ii  libnet-libidn-perl                        0.12.ds-2+b3                      amd64        Perl bindings for GNU Libidn
    ii  libnet-pcap-perl                          0.18-1+b1                         amd64        Perl binding to the LBL pcap packet capture library
    ii  libnet-proxy-perl                         0.12-6                            all          Framework for proxying network connections in many ways
    ii  libnet-smtp-ssl-perl                      1.04-1                            all          Perl module providing SSL support to Net::SMTP
    ii  libnet-ssleay-perl                        1.78-1                            amd64        Perl module for Secure Sockets Layer (SSL)
    ii  libnetcdf-c++4                            4.2-6                             amd64        legacy NetCDF C++ interface
    ii  libnetcdf11                               1:4.4.1-2                         amd64        Interface for scientific data access to large binary data
    ii  libnetfilter-conntrack3:amd64             1.0.6-2                           amd64        Netfilter netlink-conntrack library
    ii  libnetpbm10                               2:10.0-15.3+b1                    amd64        Graphics conversion tools shared libraries
    ii  libnettle6:amd64                          3.3-1                             amd64        low level cryptographic library (symmetric and one-way cryptos)
    ii  libnettle6:i386                           3.3-1                             i386         low level cryptographic library (symmetric and one-way cryptos)
    ii  libnewt0.52:amd64                         0.52.19-1                         amd64        Not Erik's Windowing Toolkit - text mode windowing with slang
    ii  libnfnetlink0:amd64                       1.0.1-3                           amd64        Netfilter netlink library
    ii  libnghttp2-14:amd64                       1.16.0-1                          amd64        library implementing HTTP/2 protocol (shared library)
    ii  libnginx-mod-http-auth-pam                1.10.2-1                          amd64        PAM authentication module for Nginx
    ii  libnginx-mod-http-echo                    1.10.2-1                          amd64        Bring echo and more shell style goodies to Nginx
    ii  libnginx-mod-http-geoip                   1.10.2-1                          amd64        GeoIP HTTP module for Nginx
    ii  libnginx-mod-http-image-filter            1.10.2-1                          amd64        HTTP image filter module for Nginx
    ii  libnginx-mod-http-subs-filter             1.10.2-1                          amd64        Substitution filter module for Nginx
    ii  libnginx-mod-http-upstream-fair           1.10.2-1                          amd64        Nginx Upstream Fair Proxy Load Balancer
    ii  libnginx-mod-http-xslt-filter             1.10.2-1                          amd64        XSLT Transformation module for Nginx
    ii  libnginx-mod-mail                         1.10.2-1                          amd64        Mail module for Nginx
    ii  libnginx-mod-stream                       1.10.2-1                          amd64        Stream module for Nginx
    ii  libnl-3-200:amd64                         3.2.27-1                          amd64        library for dealing with netlink sockets
    ii  libnl-genl-3-200:amd64                    3.2.27-1                          amd64        library for dealing with netlink sockets - generic netlink
    ii  libnl-route-3-200:amd64                   3.2.27-1                          amd64        library for dealing with netlink sockets - route interface
    ii  libnm-glib-vpn1:amd64                     1.2.4-3                           amd64        network management framework (GLib VPN shared library)
    ii  libnm-glib4:amd64                         1.2.4-3                           amd64        network management framework (GLib shared library)
    ii  libnm-gtk-common                          1.2.4-1                           all          library for wireless and mobile dialogs - common files
    ii  libnm-gtk0:amd64                          1.2.4-1                           amd64        library for wireless and mobile dialogs (libnm-glib version)
    ii  libnm-util2:amd64                         1.2.4-3                           amd64        network management framework (shared library)
    ii  libnm0:amd64                              1.2.4-3                           amd64        GObject-based client library for NetworkManager
    ii  libnma-common                             1.2.4-1                           all          library for wireless and mobile dialogs - common files
    ii  libnma0:amd64                             1.2.4-1                           amd64        library for wireless and mobile dialogs (libnm version)
    ii  libnotify-bin                             0.7.7-1                           amd64        sends desktop notifications to a notification daemon (Utilities)
    ii  libnotify4:amd64                          0.7.7-1                           amd64        sends desktop notifications to a notification daemon
    ii  libnpth0:amd64                            1.2-3                             amd64        replacement for GNU Pth using system threads
    ii  libnspr4:amd64                            2:4.12-6                          amd64        NetScape Portable Runtime Library
    ii  libnss-mdns:i386                          0.10-7                            i386         NSS module for Multicast DNS name resolution
    ii  libnss3:amd64                             2:3.23-2                          amd64        Network Security Service libraries
    ii  libntdb1:amd64                            1.0-9                             amd64        New Trivial Database - shared library
    ii  libntfs-3g871                             1:2016.2.22AR.1-3                 amd64        read/write NTFS driver for FUSE (runtime library)
    ii  libnuma1:amd64                            2.0.11-2                          amd64        Libraries for controlling NUMA policy
    ii  libnuma1:i386                             2.0.11-2                          i386         Libraries for controlling NUMA policy
    ii  liboauth0:amd64                           1.0.1-1                           amd64        C library for implementing OAuth 1.0
    ii  libobjc-5-dev:amd64                       5.4.1-3                           amd64        Runtime library for GNU Objective-C applications (development files)
    ii  libobjc-6-dev:amd64                       6.2.0-11                          amd64        Runtime library for GNU Objective-C applications (development files)
    ii  libobjc4:amd64                            6.2.0-11                          amd64        Runtime library for GNU Objective-C applications
    ii  liboce-foundation10:amd64                 0.17.2-1                          amd64        OpenCASCADE Community Edition CAE platform shared library
    ii  liboce-modeling10:amd64                   0.17.2-1                          amd64        OpenCASCADE Community Edition CAE platform shared library
    ii  liboce-ocaf-lite10:amd64                  0.17.2-1                          amd64        OpenCASCADE Community Edition CAE platform shared library
    ii  liboce-ocaf10:amd64                       0.17.2-1                          amd64        OpenCASCADE Community Edition CAE platform shared library
    ii  liboce-visualization10:amd64              0.17.2-1                          amd64        OpenCASCADE Community Edition CAE platform shared library
    ii  libodbc1:amd64                            2.3.1-5+b1                        amd64        ODBC library for Unix
    ii  libodfgen-0.1-1:amd64                     0.1.6-2                           amd64        library to generate ODF documents
    ii  libofa0:amd64                             0.9.3-12                          amd64        library for acoustic fingerprinting
    ii  libogdi3.2                                3.2.0+ds-1+b1                     amd64        Open Geographic Datastore Interface Library -- library
    ii  libogg0:amd64                             1.3.2-1                           amd64        Ogg bitstream library
    ii  libogg0:i386                              1.3.2-1                           i386         Ogg bitstream library
    rc  libonig2:amd64                            5.9.6-1                           amd64        regular expressions library
    ii  libonig4:amd64                            6.1.1-2                           amd64        regular expressions library
    rc  libopa1:amd64                             3.1-6                             amd64        Shared libraries for opa part of MPICH
    ii  libopenal-data                            1:1.17.2-4                        all          Software implementation of the OpenAL audio API (data files)
    ii  libopenal1:amd64                          1:1.17.2-4                        amd64        Software implementation of the OpenAL audio API (shared library)
    ii  libopenal1:i386                           1:1.17.2-4                        i386         Software implementation of the OpenAL audio API (shared library)
    ii  libopencc1:amd64                          0.4.3-2                           amd64        simplified-traditional chinese conversion library - runtime
    ii  libopenconnect5:amd64                     7.06-2+b2                         amd64        open client for Cisco AnyConnect VPN - shared library
    ii  libopencore-amrnb0:amd64                  0.1.3-2.1                         amd64        Adaptive Multi Rate speech codec - shared library
    ii  libopencore-amrwb0:amd64                  0.1.3-2.1                         amd64        Adaptive Multi-Rate - Wideband speech codec - shared library
    ii  libopencv-calib3d2.4v5:amd64              2.4.9.1+dfsg-2.1                  amd64        computer vision Camera Calibration library
    ii  libopencv-contrib2.4v5:amd64              2.4.9.1+dfsg-2.1                  amd64        computer vision contrib library
    ii  libopencv-core2.4v5:amd64                 2.4.9.1+dfsg-2.1                  amd64        computer vision core library
    ii  libopencv-features2d2.4v5:amd64           2.4.9.1+dfsg-2.1                  amd64        computer vision Feature Detection and Descriptor Extraction library
    ii  libopencv-flann2.4v5:amd64                2.4.9.1+dfsg-2.1                  amd64        computer vision Clustering and Search in Multi-Dimensional spaces library
    ii  libopencv-highgui2.4-deb0:amd64           2.4.9.1+dfsg-2.1                  amd64        computer vision High-level GUI and Media I/O library
    ii  libopencv-imgproc2.4v5:amd64              2.4.9.1+dfsg-2.1                  amd64        computer vision Image Processing library
    ii  libopencv-legacy2.4v5:amd64               2.4.9.1+dfsg-2.1                  amd64        computer vision legacy library
    ii  libopencv-ml2.4v5:amd64                   2.4.9.1+dfsg-2.1                  amd64        computer vision Machine Learning library
    ii  libopencv-objdetect2.4v5:amd64            2.4.9.1+dfsg-2.1                  amd64        computer vision Object Detection library
    ii  libopencv-video2.4v5:amd64                2.4.9.1+dfsg-2.1                  amd64        computer vision Video analysis library
    ii  libopenexr-dev                            2.2.0-11                          amd64        development files for the OpenEXR image library
    ii  libopenexr22:amd64                        2.2.0-11                          amd64        runtime files for the OpenEXR image library
    ii  libopenexr6v5:amd64                       1.6.1-8.1+b2                      amd64        runtime files for the OpenEXR image library
    ii  libopenjp2-7:amd64                        2.1.2-1                           amd64        JPEG 2000 image compression/decompression library
    ii  libopenjp2-7:i386                         2.1.2-1                           i386         JPEG 2000 image compression/decompression library
    ii  libopenjp2-7-dev                          2.1.2-1                           amd64        development files for OpenJPEG, a JPEG 2000 image library
    ii  libopenjpeg5:amd64                        1:1.5.2-3.1                       amd64        JPEG 2000 image compression/decompression library - runtime
    rc  libopenjpeg5:i386                         1:1.5.2-3.1                       i386         JPEG 2000 image compression/decompression library - runtime
    rc  libopenmpi1.6                             1.6.5-11                          amd64        high performance message passing library -- shared library
    ii  libopenmpi2                               2.0.1-7                           amd64        high performance message passing library -- shared library
    ii  libopus0:amd64                            1.1.3-1                           amd64        Opus codec runtime library
    ii  libopus0:i386                             1.1.3-1                           i386         Opus codec runtime library
    ii  liborbit-2-0:amd64                        1:2.14.19-2                       amd64        high-performance CORBA implementation - common libraries
    ii  liborc-0.4-0:amd64                        1:0.4.26-2                        amd64        Library of Optimized Inner Loops Runtime Compiler
    ii  liborc-0.4-0:i386                         1:0.4.26-2                        i386         Library of Optimized Inner Loops Runtime Compiler
    ii  liborcus-0.11-0:amd64                     0.11.2-3                          amd64        library for processing spreadsheet documents
    ii  libosmesa6:i386                           12.0.3-3                          i386         Mesa Off-screen rendering extension
    ii  libossp-uuid-perl                         1.6.2-1.5+b3                      amd64        perl OSSP::UUID - OSSP uuid Perl Binding
    ii  libossp-uuid16:amd64                      1.6.2-1.5+b3                      amd64        OSSP uuid ISO-C and C++ - shared library
    ii  libostree-1-1:amd64                       2016.12-2                         amd64        content-addressed filesystem for operating system binaries (library)
    ii  liboxideqt-qmlplugin:amd64                1.10.3-0ubuntu0.15.10.1           amd64        Web browser engine library for Qt (QML plugin)
    ii  liboxideqtcore0:amd64                     1.10.3-0ubuntu0.15.10.1           amd64        Web browser engine library for Qt (core library and components)
    ii  liboxideqtquick0:amd64                    1.10.3-0ubuntu0.15.10.1           amd64        Web browser engine library for Qt (QtQuick library)
    ii  libp11-kit-dev:amd64                      0.23.2-5                          amd64        library for loading and coordinating access to PKCS#11 modules - development
    ii  libp11-kit0:amd64                         0.23.2-5                          amd64        library for loading and coordinating access to PKCS#11 modules - runtime
    ii  libp11-kit0:i386                          0.23.2-5                          i386         library for loading and coordinating access to PKCS#11 modules - runtime
    ii  libpackagekit-glib2-18:amd64              1.1.4-3                           amd64        Library for accessing PackageKit using GLib
    ii  libpagemaker-0.0-0:amd64                  0.0.3-2                           amd64        Library for importing and converting PageMaker Documents
    ii  libpam-gnome-keyring:amd64                3.20.0-3                          amd64        PAM module to unlock the GNOME keyring upon login
    ii  libpam-modules:amd64                      1.1.8-3.3                         amd64        Pluggable Authentication Modules for PAM
    ii  libpam-modules-bin                        1.1.8-3.3                         amd64        Pluggable Authentication Modules for PAM - helper binaries
    ii  libpam-runtime                            1.1.8-3.3                         all          Runtime support for the PAM library
    ii  libpam-systemd:amd64                      231-1                             amd64        system and service manager - PAM module
    ii  libpam0g:amd64                            1.1.8-3.3                         amd64        Pluggable Authentication Modules library
    ii  libpango-1.0-0:amd64                      1.40.3-3                          amd64        Layout and rendering of internationalized text
    ii  libpango-perl                             1.227-1+b1                        amd64        Perl module to layout and render international text
    ii  libpango1.0-0:amd64                       1.40.3-3                          amd64        Layout and rendering of internationalized text (transitional package)
    ii  libpango1.0-dev                           1.40.3-3                          amd64        Development files for the Pango
    ii  libpangocairo-1.0-0:amd64                 1.40.3-3                          amd64        Layout and rendering of internationalized text
    ii  libpangoft2-1.0-0:amd64                   1.40.3-3                          amd64        Layout and rendering of internationalized text
    ii  libpangomm-1.4-1v5:amd64                  2.40.1-3                          amd64        C++ Wrapper for pango (shared libraries)
    ii  libpangox-1.0-0:amd64                     0.0.2-5                           amd64        pango library X backend
    ii  libpangoxft-1.0-0:amd64                   1.40.3-3                          amd64        Layout and rendering of internationalized text
    ii  libpaper-utils                            1.1.24+nmu4                       amd64        library for handling paper characteristics (utilities)
    ii  libpaper1:amd64                           1.1.24+nmu4                       amd64        library for handling paper characteristics
    ii  libparse-debianchangelog-perl             1.2.0-11                          all          parse Debian changelogs and output them in other formats
    ii  libparted-fs-resize0:amd64                3.2-16+b1                         amd64        disk partition manipulator - shared FS resizing library
    ii  libparted2:amd64                          3.2-16+b1                         amd64        disk partition manipulator - shared library
    ii  libpathplan4                              2.38.0-16                         amd64        rich set of graph drawing tools - pathplan library
    ii  libpcap0.8:amd64                          1.8.1-3                           amd64        system interface for user-level packet capture
    ii  libpcap0.8:i386                           1.8.1-3                           i386         system interface for user-level packet capture
    ii  libpci3:amd64                             1:3.3.1-1.1                       amd64        Linux PCI Utilities (shared library)
    ii  libpciaccess0:amd64                       0.13.4-1                          amd64        Generic PCI access library for X
    ii  libpciaccess0:i386                        0.13.4-1                          i386         Generic PCI access library for X
    ii  libpcre16-3:amd64                         2:8.39-2                          amd64        Old Perl 5 Compatible Regular Expression Library - 16 bit runtime files
    ii  libpcre2-16-0:amd64                       10.22-2                           amd64        New Perl Compatible Regular Expression Library - 16 bit runtime files
    ii  libpcre2-32-0:amd64                       10.22-2                           amd64        New Perl Compatible Regular Expression Library - 32 bit runtime files
    ii  libpcre2-8-0:amd64                        10.22-2                           amd64        New Perl Compatible Regular Expression Library- 8 bit runtime files
    ii  libpcre2-dev:amd64                        10.22-2                           amd64        New Perl Compatible Regular Expression Library - development files
    ii  libpcre2-posix0:amd64                     10.22-2                           amd64        New Perl Compatible Regular Expression Library - posix-compatible runtime files
    ii  libpcre3:amd64                            2:8.39-2                          amd64        Old Perl 5 Compatible Regular Expression Library - runtime files
    ii  libpcre3:i386                             2:8.39-2                          i386         Old Perl 5 Compatible Regular Expression Library - runtime files
    ii  libpcre3-dev:amd64                        2:8.39-2                          amd64        Old Perl 5 Compatible Regular Expression Library - development files
    ii  libpcre32-3:amd64                         2:8.39-2                          amd64        Old Perl 5 Compatible Regular Expression Library - 32 bit runtime files
    ii  libpcrecpp0v5:amd64                       2:8.39-2                          amd64        Old Perl 5 Compatible Regular Expression Library - C++ runtime files
    ii  libpcsclite1:amd64                        1.8.20-1                          amd64        Middleware to access a smart card using PC/SC (library)
    ii  libpeas-1.0-0:amd64                       1.20.0-1                          amd64        Application plugin library
    ii  libpeas-common                            1.20.0-1                          all          Application plugin library (common files)
    rc  libperl5.22:amd64                         5.22.2-5                          amd64        shared Perl library
    ii  libperl5.24:amd64                         5.24.1~rc4-1                      amd64        shared Perl library
    ii  libperlio-gzip-perl                       0.19-1+b2                         amd64        module providing a PerlIO layer to gzip/gunzip
    ii  libpgm-5.1-0                              5.1.118-1~dfsg-2                  amd64        OpenPGM shared library
    ii  libphonon4:amd64                          4:4.9.0-4                         amd64        multimedia framework from KDE - core library
    ii  libpipeline1:amd64                        1.4.1-2                           amd64        pipeline manipulation library
    ii  libpixman-1-0:amd64                       0.34.0-1                          amd64        pixel-manipulation library for X and cairo
    ii  libpixman-1-0:i386                        0.34.0-1                          i386         pixel-manipulation library for X and cairo
    ii  libpixman-1-dev                           0.34.0-1                          amd64        pixel-manipulation library for X and cairo (development files)
    ii  libpkcs11-helper1:amd64                   1.11-5                            amd64        library that simplifies the interaction with PKCS#11
    ii  libplist3:amd64                           1.12-3.1                          amd64        Library for handling Apple binary and XML property lists
    ii  libplymouth4:amd64                        0.9.2-41                          amd64        graphical boot animation and logger - shared libraries
    ii  libpng-dev:amd64                          1.6.26-1                          amd64        PNG library - development (version 1.6)
    ii  libpng-tools                              1.6.26-1                          amd64        PNG library - tools (version 1.6)
    ii  libpng12-0:amd64                          1.2.54-6                          amd64        PNG library - runtime
    ii  libpng12-0:i386                           1.2.54-6                          i386         PNG library - runtime
    ii  libpng16-16:amd64                         1.6.26-1                          amd64        PNG library - runtime (version 1.6)
    ii  libpng16-16:i386                          1.6.26-1                          i386         PNG library - runtime (version 1.6)
    ii  libpolkit-agent-1-0:amd64                 0.105-17                          amd64        PolicyKit Authentication Agent API
    ii  libpolkit-backend-1-0:amd64               0.105-17                          amd64        PolicyKit backend API
    ii  libpolkit-gobject-1-0:amd64               0.105-17                          amd64        PolicyKit Authorization API
    ii  libpolkit-qt-1-1:amd64                    0.112.0-5                         amd64        PolicyKit-qt-1 library
    ii  libpolkit-qt5-1-1:amd64                   0.112.0-5                         amd64        PolicyKit-qt5-1 library
    ii  libpoppler-cpp0v5:amd64                   0.48.0-2                          amd64        PDF rendering library (CPP shared library)
    ii  libpoppler-glib8:amd64                    0.48.0-2                          amd64        PDF rendering library (GLib-based shared library)
    ii  libpoppler-qt4-4:amd64                    0.48.0-2                          amd64        PDF rendering library (Qt 4 based shared library)
    ii  libpoppler46:amd64                        0.26.5-4                          amd64        PDF rendering library
    ii  libpoppler64:amd64                        0.48.0-2                          amd64        PDF rendering library
    ii  libpopt0:amd64                            1.16-10                           amd64        lib for parsing cmdline parameters
    ii  libpostproc-ffmpeg53:amd64                7:2.8.6-1+b2                      amd64        FFmpeg library for post processing - runtime files
    ii  libpostproc54:amd64                       7:3.2.2-1                         amd64        FFmpeg library for post processing - runtime files
    ii  libpotrace0                               1.13-2                            amd64        library for tracing bitmaps
    ii  libpq5:amd64                              9.6.1-2                           amd64        PostgreSQL C client library
    ii  libpresage-data                           0.9.1-2.1                         all          intelligent predictive text entry platform (data files)
    ii  libpresage1v5:amd64                       0.9.1-2.1                         amd64        intelligent predictive text entry platform (shared library)
    ii  libprocps4:amd64                          2:3.3.10-4+b1                     amd64        library for accessing process information from /proc
    ii  libprocps6:amd64                          2:3.3.12-2                        amd64        library for accessing process information from /proc
    ii  libproj12                                 4.9.3-1                           amd64        Cartographic projection library
    ii  libprotobuf9v5:amd64                      2.6.1-2                           amd64        protocol buffers C++ library
    ii  libproxy-tools                            0.4.11-5                          amd64        automatic proxy configuration management library (tools)
    ii  libproxy1v5:amd64                         0.4.11-5                          amd64        automatic proxy configuration management library (shared)
    ii  libpsl0:amd64                             0.11.0-2+b1                       amd64        Library for Public Suffix List (shared libraries)
    ii  libpsl5:amd64                             0.14.0-1+b1                       amd64        Library for Public Suffix List (shared libraries)
    ii  libpsm-infinipath1                        3.3+19.g67c0807.open-3            amd64        PSM Messaging library for Intel Truescale adapters
    ii  libptexenc1:amd64                         2016.20160513.41080-7+b1          amd64        TeX Live: pTeX encoding library
    ii  libpthread-stubs0-dev:amd64               0.3-4                             amd64        pthread stubs not provided by native libc, development files
    ii  libpugixml1v5:amd64                       1.7-2                             amd64        Light-weight C++ XML processing library
    ii  libpulse-mainloop-glib0:amd64             8.0-2                             amd64        PulseAudio client libraries (glib support)
    ii  libpulse0:amd64                           8.0-2                             amd64        PulseAudio client libraries
    ii  libpulse0:i386                            8.0-2                             i386         PulseAudio client libraries
    ii  libpulsedsp:amd64                         8.0-2                             amd64        PulseAudio OSS pre-load library
    ii  libpyside1.2:amd64                        1.2.2-2+b1                        amd64        Python bindings for Qt 4 (base files)
    ii  libpython-all-dev:amd64                   2.7.11-2                          amd64        package depending on all supported Python development packages
    ii  libpython-dev:amd64                       2.7.11-2                          amd64        header files and a static library for Python (default)
    ii  libpython-stdlib:amd64                    2.7.11-2                          amd64        interactive high-level object-oriented language (default python version)
    ii  libpython2.7:amd64                        2.7.12-2                          amd64        Shared Python runtime library (version 2.7)
    ii  libpython2.7-dev:amd64                    2.7.12-2                          amd64        Header files and a static library for Python (v2.7)
    ii  libpython2.7-minimal:amd64                2.7.12-2                          amd64        Minimal subset of the Python language (version 2.7)
    ii  libpython2.7-stdlib:amd64                 2.7.12-2                          amd64        Interactive high-level object-oriented language (standard library, version 2.7)
    ii  libpython3-stdlib:amd64                   3.5.1-4                           amd64        interactive high-level object-oriented language (default python3 version)
    ii  libpython3.4:amd64                        3.4.4-3                           amd64        Shared Python runtime library (version 3.4)
    ii  libpython3.4-minimal:amd64                3.4.4-3                           amd64        Minimal subset of the Python language (version 3.4)
    ii  libpython3.4-stdlib:amd64                 3.4.4-3                           amd64        Interactive high-level object-oriented language (standard library, version 3.4)
    ii  libpython3.5:amd64                        3.5.2-7                           amd64        Shared Python runtime library (version 3.5)
    ii  libpython3.5-minimal:amd64                3.5.2-7                           amd64        Minimal subset of the Python language (version 3.5)
    ii  libpython3.5-stdlib:amd64                 3.5.2-7                           amd64        Interactive high-level object-oriented language (standard library, version 3.5)
    ii  libqbscore1                               1.6.0+dfsg-2                      amd64        Qbs core library
    ii  libqbsqtprofilesetup1                     1.6.0+dfsg-2                      amd64        Qbs profile setup library
    ii  libqca2:amd64                             2.1.1-2                           amd64        libraries for the Qt Cryptographic Architecture
    ii  libqca2-plugins:amd64                     2.1.1-2                           amd64        QCA plugins for libqca2
    ii  libqdbm14                                 1.8.78-6+b5                       amd64        QDBM Database Libraries without GDBM wrapper[runtime]
    ii  libqgsttools-p1:amd64                     5.6.1-2                           amd64        GStreamer tools for  Qt 5 Multimedia module
    ii  libqhull7:amd64                           2015.2-1                          amd64        calculate convex hulls and related structures (shared library)
    ii  libqmi-glib1:amd64                        1.12.6-1                          amd64        Support library to use the Qualcomm MSM Interface (QMI) protocol
    ii  libqmi-glib5:amd64                        1.16.0-1                          amd64        Support library to use the Qualcomm MSM Interface (QMI) protocol
    ii  libqmi-proxy                              1.16.0-1                          amd64        Proxy to communicate with QMI ports
    ii  libqpdf17:amd64                           6.0.0-2                           amd64        runtime library for PDF transformation/inspection software
    ii  libqrencode-dev                           3.4.4-1+b1                        amd64        QR Code encoding library -- development
    ii  libqrencode3:amd64                        3.4.4-1+b1                        amd64        QR Code encoding library
    ii  libqt4-dbus:amd64                         4:4.8.7+dfsg-10                   amd64        Qt 4 D-Bus module
    ii  libqt4-declarative:amd64                  4:4.8.7+dfsg-10                   amd64        Qt 4 Declarative module
    ii  libqt4-designer:amd64                     4:4.8.7+dfsg-10                   amd64        Qt 4 designer module
    ii  libqt4-help:amd64                         4:4.8.7+dfsg-10                   amd64        Qt 4 help module
    ii  libqt4-network:amd64                      4:4.8.7+dfsg-10                   amd64        Qt 4 network module
    ii  libqt4-opengl:amd64                       4:4.8.7+dfsg-10                   amd64        Qt 4 OpenGL module
    ii  libqt4-script:amd64                       4:4.8.7+dfsg-10                   amd64        Qt 4 script module
    ii  libqt4-scripttools:amd64                  4:4.8.7+dfsg-10                   amd64        Qt 4 script tools module
    ii  libqt4-sql:amd64                          4:4.8.7+dfsg-10                   amd64        Qt 4 SQL module
    ii  libqt4-svg:amd64                          4:4.8.7+dfsg-10                   amd64        Qt 4 SVG module
    ii  libqt4-test:amd64                         4:4.8.7+dfsg-10                   amd64        Qt 4 test module
    ii  libqt4-xml:amd64                          4:4.8.7+dfsg-10                   amd64        Qt 4 XML module
    ii  libqt4-xmlpatterns:amd64                  4:4.8.7+dfsg-10                   amd64        Qt 4 XML patterns module
    ii  libqt5clucene5:amd64                      5.6.1-2                           amd64        Qt 5 CLucene module
    ii  libqt5concurrent5:amd64                   5.6.1+dfsg-3+b1                   amd64        Qt 5 concurrent module
    ii  libqt5core5a:amd64                        5.6.1+dfsg-3+b1                   amd64        Qt 5 core module
    ii  libqt5dbus5:amd64                         5.6.1+dfsg-3+b1                   amd64        Qt 5 D-Bus module
    ii  libqt5designer5:amd64                     5.6.1-2                           amd64        Qt 5 designer module
    ii  libqt5designercomponents5:amd64           5.6.1-2                           amd64        Qt 5 Designer components module
    ii  libqt5glib-2.0-0:amd64                    1.2.0-4                           amd64        C++ bindings library for GLib and GObject with a Qt-style API - Qt 5 build
    ii  libqt5gstreamer-1.0-0:amd64               1.2.0-4                           amd64        C++ bindings library for GStreamer with a Qt-style API - Qt 5 build
    ii  libqt5gstreamerui-1.0-0:amd64             1.2.0-4                           amd64        QtGStreamerUi library - Qt 5 build
    ii  libqt5gstreamerutils-1.0-0:amd64          1.2.0-4                           amd64        QtGStreamerUtils library - Qt 5 build
    ii  libqt5gui5:amd64                          5.6.1+dfsg-3+b1                   amd64        Qt 5 GUI module
    ii  libqt5help5:amd64                         5.6.1-2                           amd64        Qt 5 help module
    rc  libqt5keychain0:amd64                     0.5.0-1                           amd64        Qt API to store passwords (QT5 version)
    ii  libqt5keychain1:amd64                     0.7.0-3                           amd64        Qt API to store passwords (QT5 version)
    ii  libqt5libqgtk2:amd64                      5.6.1+dfsg-3+b1                   amd64        Qt 5 GTK2 platform theme
    ii  libqt5multimedia5:amd64                   5.6.1-2                           amd64        Qt 5 Multimedia module
    ii  libqt5multimedia5-plugins:amd64           5.6.1-2                           amd64        Qt 5 Multimedia module plugins
    ii  libqt5multimediaquick-p5:amd64            5.6.1-2                           amd64        Qt 5 Multimedia Quick module
    ii  libqt5multimediawidgets5:amd64            5.6.1-2                           amd64        Qt 5 Multimedia Widgets module
    ii  libqt5network5:amd64                      5.6.1+dfsg-3+b1                   amd64        Qt 5 network module
    ii  libqt5opengl5:amd64                       5.6.1+dfsg-3+b1                   amd64        Qt 5 OpenGL module
    ii  libqt5opengl5-dev:amd64                   5.6.1+dfsg-3+b1                   amd64        Qt 5 OpenGL library development files
    ii  libqt5positioning5:amd64                  5.6.1-2                           amd64        Qt Positioning module
    ii  libqt5printsupport5:amd64                 5.6.1+dfsg-3+b1                   amd64        Qt 5 print support module
    ii  libqt5qml5:amd64                          5.6.1-5                           amd64        Qt 5 QML module
    ii  libqt5quick5:amd64                        5.6.1-5                           amd64        Qt 5 Quick library
    ii  libqt5quickparticles5:amd64               5.6.1-5                           amd64        Qt 5 Quick particles module
    ii  libqt5quicktest5:amd64                    5.6.1-5                           amd64        Qt 5 Quick Test library
    ii  libqt5quickwidgets5:amd64                 5.6.1-5                           amd64        Qt 5 Quick Widgets library
    ii  libqt5script5:amd64                       5.6.1+dfsg-2                      amd64        Qt 5 script module
    ii  libqt5sql5:amd64                          5.6.1+dfsg-3+b1                   amd64        Qt 5 SQL module
    ii  libqt5sql5-sqlite:amd64                   5.6.1+dfsg-3+b1                   amd64        Qt 5 SQLite 3 database driver
    ii  libqt5svg5:amd64                          5.6.1-2                           amd64        Qt 5 SVG module
    ii  libqt5test5:amd64                         5.6.1+dfsg-3+b1                   amd64        Qt 5 test module
    ii  libqt5webkit5:amd64                       5.6.1+dfsg-4+b2                   amd64        Web content engine library for Qt
    ii  libqt5widgets5:amd64                      5.6.1+dfsg-3+b1                   amd64        Qt 5 widgets module
    ii  libqt5x11extras5:amd64                    5.6.1-2                           amd64        Qt 5 X11 extras
    ii  libqt5x11extras5-dev:amd64                5.6.1-2                           amd64        Qt 5 X11 extras development files
    ii  libqt5xdg1:amd64                          1.3.0-3+b1                        amd64        Implementation of the XDG Specifications for Qt, libs
    ii  libqt5xdg2:amd64                          2.0.0-5                           amd64        Implementation of the XDG Specifications for Qt (shared lib)
    ii  libqt5xdgiconloader2:amd64                2.0.0-5                           amd64        Implementation of the XDG Iconloader for Qt (shared lib)
    ii  libqt5xml5:amd64                          5.6.1+dfsg-3+b1                   amd64        Qt 5 XML module
    ii  libqt5xmlpatterns5:amd64                  5.6.1-2                           amd64        Qt 5 XML patterns module
    ii  libqtassistantclient4:amd64               4.6.3-7                           amd64        Qt Assistant client library (runtime)
    ii  libqtav11:amd64                           1:1.11.0-5                        amd64        QtAV library
    ii  libqtcore4:amd64                          4:4.8.7+dfsg-10                   amd64        Qt 4 core module
    ii  libqtdbus4:amd64                          4:4.8.7+dfsg-10                   amd64        Qt 4 D-Bus module library
    ii  libqtgui4:amd64                           4:4.8.7+dfsg-10                   amd64        Qt 4 GUI module
    ii  libqtshadowsocks                          1.9.0-1                           amd64        A lightweight and ultra-fast shadowsocks library written in C++/Qt
    ii  libqtshadowsocks-dev                      1.9.0-1                           amd64        Development files of libQtShadowsocks
    ii  libqtwebkit4:amd64                        2.3.4.dfsg-9                      amd64        Web content engine library for Qt
    ii  libquadmath0:amd64                        6.2.0-11                          amd64        GCC Quad-Precision Math Library
    ii  libraptor2-0:amd64                        2.0.14-1                          amd64        Raptor 2 RDF syntax library
    ii  librasqal3:amd64                          0.9.32-1                          amd64        Rasqal RDF query library
    ii  libraw1394-11:amd64                       2.1.2-1                           amd64        library for direct access to IEEE 1394 bus (aka FireWire)
    ii  libraw15:amd64                            0.17.2-6                          amd64        raw image decoder library
    ii  librdf0:amd64                             1.0.17-1+b1                       amd64        Redland Resource Description Framework (RDF) library
    ii  librdmacm1                                1.1.0-2                           amd64        Library for managing RDMA connections
    ii  libreadline5:amd64                        5.2+dfsg-3+b1                     amd64        GNU readline and history libraries, run-time libraries
    ii  libreadline6:amd64                        6.3-9                             amd64        GNU readline and history libraries, run-time libraries
    ii  libreadline7:amd64                        7.0-1                             amd64        GNU readline and history libraries, run-time libraries
    ii  libreoffice                               1:5.1.5~rc2-1                     amd64        office productivity suite (metapackage)
    ii  libreoffice-avmedia-backend-gstreamer     1:5.1.5~rc2-1                     amd64        GStreamer backend for LibreOffice
    ii  libreoffice-base                          1:5.1.5~rc2-1                     amd64        office productivity suite -- database
    ii  libreoffice-base-core                     1:5.1.5~rc2-1                     amd64        office productivity suite -- shared library
    ii  libreoffice-base-drivers                  1:5.1.5~rc2-1                     amd64        Database connectivity drivers for LibreOffice
    ii  libreoffice-calc                          1:5.1.5~rc2-1                     amd64        office productivity suite -- spreadsheet
    ii  libreoffice-common                        1:5.1.5~rc2-1                     all          office productivity suite -- arch-independent files
    ii  libreoffice-core                          1:5.1.5~rc2-1                     amd64        office productivity suite -- arch-dependent files
    ii  libreoffice-draw                          1:5.1.5~rc2-1                     amd64        office productivity suite -- drawing
    rc  libreoffice-gtk                           1:5.1.5~rc2-1                     amd64        office productivity suite -- GTK+ integration
    ii  libreoffice-impress                       1:5.1.5~rc2-1                     amd64        office productivity suite -- presentation
    ii  libreoffice-java-common                   1:5.1.5~rc2-1                     all          office productivity suite -- arch-independent Java support files
    ii  libreoffice-math                          1:5.1.5~rc2-1                     amd64        office productivity suite -- equation editor
    ii  libreoffice-report-builder-bin            1:5.1.5~rc2-1                     amd64        LibreOffice component for building database reports -- libraries
    ii  libreoffice-sdbc-firebird                 1:5.1.5~rc2-1                     amd64        Firebird SDBC driver for LibreOffice
    ii  libreoffice-sdbc-hsqldb                   1:5.1.5~rc2-1                     amd64        HSQLDB SDBC driver for LibreOffice
    ii  libreoffice-style-galaxy                  1:5.1.5~rc2-1                     all          office productivity suite -- Galaxy (Default) symbol style
    ii  libreoffice-style-tango                   1:5.1.5~rc2-1                     all          office productivity suite -- Tango symbol style
    ii  libreoffice-writer                        1:5.1.5~rc2-1                     amd64        office productivity suite -- word processor
    ii  libresid-builder0c2a                      2.1.1-15                          amd64        SID chip emulation class based on resid
    ii  librest-0.7-0:amd64                       0.8.0-2                           amd64        REST service access library
    ii  librevenge-0.0-0:amd64                    0.0.4-6                           amd64        Base Library for writing document interface filters
    ii  libroken18-heimdal:amd64                  1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - roken support library
    ii  librsvg2-2:amd64                          2.40.16-1                         amd64        SAX-based renderer library for SVG files (runtime)
    ii  librsvg2-common:amd64                     2.40.16-1                         amd64        SAX-based renderer library for SVG files (extra runtime)
    ii  librsvg2-dev:amd64                        2.40.16-1                         amd64        SAX-based renderer library for SVG files (development)
    ii  librtmp1:amd64                            2.4+20151223.gitfa8646d.1-1       amd64        toolkit for RTMP streams (shared library)
    ii  librubberband2:amd64                      1.8.1-6+b1                        amd64        audio time-stretching and pitch-shifting library
    ii  libruby2.2:amd64                          2.2.4-1                           amd64        Libraries necessary to run Ruby 2.2
    ii  libruby2.3:amd64                          2.3.1-5+b1                        amd64        Libraries necessary to run Ruby 2.3
    ii  libsamplerate0:amd64                      0.1.8-8                           amd64        Audio sample rate conversion library
    ii  libsamplerate0:i386                       0.1.8-8                           i386         Audio sample rate conversion library
    ii  libsane:amd64                             1.0.25-2+b1                       amd64        API library for scanners
    ii  libsane:i386                              1.0.25-2+b1                       i386         API library for scanners
    ii  libsane-common                            1.0.25-2                          all          API library for scanners -- documentation and support files
    ii  libsane-extras:i386                       1.0.22.3                          i386         API library for scanners -- extra backends
    ii  libsane-extras-common                     1.0.22.3                          amd64        API library for scanners -- documentation and support files
    ii  libsasl2-2:amd64                          2.1.27~72-g88d82a3+dfsg-1         amd64        Cyrus SASL - authentication abstraction library
    ii  libsasl2-2:i386                           2.1.27~72-g88d82a3+dfsg-1         i386         Cyrus SASL - authentication abstraction library
    ii  libsasl2-modules:i386                     2.1.27~72-g88d82a3+dfsg-1         i386         Cyrus SASL - pluggable authentication modules
    ii  libsasl2-modules-db:amd64                 2.1.27~72-g88d82a3+dfsg-1         amd64        Cyrus SASL - pluggable authentication modules (DB)
    ii  libsasl2-modules-db:i386                  2.1.27~72-g88d82a3+dfsg-1         i386         Cyrus SASL - pluggable authentication modules (DB)
    ii  libsbc1:amd64                             1.3-1                             amd64        Sub Band CODEC library - runtime
    ii  libschroedinger-1.0-0:amd64               1.0.11-2.1                        amd64        library for encoding/decoding of Dirac video streams
    rc  libschroedinger-1.0-0:i386                1.0.11-2.1                        i386         library for encoding/decoding of Dirac video streams
    ii  libsdl-image1.2:amd64                     1.2.12-5+b7                       amd64        Image loading library for Simple DirectMedia Layer 1.2, libraries
    ii  libsdl1.2debian:amd64                     1.2.15+dfsg1-4                    amd64        Simple DirectMedia Layer
    ii  libsdl2-2.0-0:amd64                       2.0.5+dfsg1-1                     amd64        Simple DirectMedia Layer
    ii  libseccomp2:amd64                         2.3.1-2                           amd64        high level interface to Linux seccomp filter
    ii  libsecret-1-0:amd64                       0.18.5-2                          amd64        Secret store
    ii  libsecret-1-dev:amd64                     0.18.5-2                          amd64        Secret store (development files)
    ii  libsecret-common                          0.18.5-2                          all          Secret store (common files)
    ii  libselinux1:amd64                         2.6-3                             amd64        SELinux runtime shared libraries
    ii  libselinux1:i386                          2.6-3                             i386         SELinux runtime shared libraries
    ii  libsemanage-common                        2.6-1                             all          Common files for SELinux policy management libraries
    ii  libsemanage1:amd64                        2.6-1                             amd64        SELinux policy management library
    ii  libsepol1:amd64                           2.6-1                             amd64        SELinux library for manipulating binary security policies
    ii  libserd-0-0:amd64                         0.24.0~dfsg0-1                    amd64        lightweight RDF syntax library
    ii  libserf-1-1:amd64                         1.3.9-1                           amd64        high-performance asynchronous HTTP client library
    ii  libservlet3.1-java                        8.5.9-2                           all          Servlet 3.1, JSP 2.3, EL 3.0 and WebSocket 1.0 Java API classes
    ii  libshiboken1.2v5:amd64                    1.2.2-3                           amd64        CPython bindings generator for C++ libraries - shared library
    ii  libshine3:amd64                           3.1.0-4                           amd64        Fixed-point MP3 encoding library - runtime files
    ii  libshine3:i386                            3.1.0-4                           i386         Fixed-point MP3 encoding library - runtime files
    ii  libshout3:amd64                           2.3.1-3                           amd64        MP3/Ogg Vorbis broadcast streaming library
    ii  libsidplay1v5                             1.36.59-10                        amd64        SID (MOS 6581) emulation library
    ii  libsidplay2                               2.1.1-15                          amd64        SID (MOS 6581) emulation library
    ii  libsigc++-2.0-0v5:amd64                   2.10.0-1                          amd64        type-safe Signal Framework for C++ - runtime
    ii  libsigsegv2:amd64                         2.10-5                            amd64        Library for handling page faults in a portable way
    ii  libslang2:amd64                           2.3.1-4                           amd64        S-Lang programming library - runtime version
    ii  libslf4j-java                             1.7.21-2                          all          Simple Logging Facade for Java
    ii  libslv2-9:amd64                           0.6.6+dfsg1-3                     amd64        library for simple use of LV2 plugins
    ii  libsm-dev:amd64                           2:1.2.2-1+b1                      amd64        X11 Session Management library (development headers)
    ii  libsm6:amd64                              2:1.2.2-1+b1                      amd64        X11 Session Management library
    ii  libsm6:i386                               2:1.2.2-1+b1                      i386         X11 Session Management library
    ii  libsmartcols1:amd64                       2.28.2-1                          amd64        smart column output alignment library
    ii  libsmbclient:amd64                        2:4.4.7+dfsg-1                    amd64        shared library for communication with SMB/CIFS servers
    ii  libsnappy1v5:amd64                        1.1.3-3                           amd64        fast compression/decompression library
    ii  libsnappy1v5:i386                         1.1.3-3                           i386         fast compression/decompression library
    ii  libsndfile1:amd64                         1.0.27-1                          amd64        Library for reading/writing audio files
    ii  libsndfile1:i386                          1.0.27-1                          i386         Library for reading/writing audio files
    ii  libsndio6.1:amd64                         1.1.0-2                           amd64        Small audio and MIDI framework from OpenBSD, runtime libraries
    ii  libsndio6.1:i386                          1.1.0-2                           i386         Small audio and MIDI framework from OpenBSD, runtime libraries
    ii  libsocket6-perl                           0.27-1+b1                         amd64        Perl extensions for IPv6
    ii  libsodium13:amd64                         1.0.3-1                           amd64        Network communication, cryptography and signaturing library
    ii  libsodium18:amd64                         1.0.11-1                          amd64        Network communication, cryptography and signaturing library
    ii  libsoqt4-20                               1.6.0~e8310f-3                    amd64        Qt4 GUI component toolkit for Inventor - runtime
    ii  libsord-0-0:amd64                         0.16.0~dfsg0-1                    amd64        library for storing RDF data in memory
    ii  libsoundtouch1:amd64                      1.9.2-2                           amd64        Sound stretching library
    ii  libsoup-gnome2.4-1:amd64                  2.56.0-1                          amd64        HTTP library implementation in C -- GNOME support library
    ii  libsoup2.4-1:amd64                        2.56.0-1                          amd64        HTTP library implementation in C -- Shared library
    ii  libsoxr0:amd64                            0.1.2-1                           amd64        High quality 1D sample-rate conversion library
    ii  libsoxr0:i386                             0.1.2-1                           i386         High quality 1D sample-rate conversion library
    ii  libspandsp2:amd64                         0.0.6+dfsg-0.1                    amd64        Telephony signal processing library
    ii  libspatialite7:amd64                      4.3.0a-5+b1                       amd64        Geospatial extension for SQLite - libraries
    ii  libspectre1:amd64                         0.2.8-1                           amd64        Library for rendering PostScript documents
    ii  libspeex1:amd64                           1.2~rc1.2-1                       amd64        The Speex codec runtime library
    ii  libspeex1:i386                            1.2~rc1.2-1                       i386         The Speex codec runtime library
    ii  libspeexdsp1:amd64                        1.2~rc1.2-1                       amd64        The Speex extended runtime library
    ii  libspeexdsp1:i386                         1.2~rc1.2-1                       i386         The Speex extended runtime library
    ii  libspice-server1:amd64                    0.12.8-1                          amd64        Implements the server side of the SPICE protocol
    ii  libspnav0                                 0.2.3-1                           amd64        Library to access 3D-input-devices (development files)
    ii  libsqlite3-0:amd64                        3.15.1-1                          amd64        SQLite 3 shared library
    ii  libsqlite3-dev:amd64                      3.15.1-1                          amd64        SQLite 3 development files
    ii  libsratom-0-0:amd64                       0.6.0~dfsg0-1                     amd64        library for serialising LV2 atoms to/from Turtle
    ii  libsrtp0                                  1.4.5~20130609~dfsg-1.3           amd64        Secure RTP (SRTP) and UST Reference Implementations - shared library
    ii  libss2:amd64                              1.43.3-1                          amd64        command-line interface parsing library
    ii  libssh-4:amd64                            0.7.3-1                           amd64        tiny C SSH library (OpenSSL flavor)
    ii  libssh-dev                                0.7.3-1                           amd64        tiny C SSH library. Development files (OpenSSL flavor)
    ii  libssh-gcrypt-4:amd64                     0.7.3-1                           amd64        tiny C SSH library (gcrypt flavor)
    ii  libssh2-1:amd64                           1.7.0-1                           amd64        SSH2 client-side library
    ii  libssh2-1-dev:amd64                       1.7.0-1                           amd64        SSH2 client-side library (development headers)
    ii  libssl-dev:amd64                          1.1.0b-2                          amd64        Secure Sockets Layer toolkit - development files
    ii  libssl-doc                                1.1.0b-2                          all          Secure Sockets Layer toolkit - development documentation
    ii  libssl1.0.0:amd64                         1.0.2d-1                          amd64        Secure Sockets Layer toolkit - shared libraries
    ii  libssl1.0.0:i386                          1.0.2d-1                          i386         Secure Sockets Layer toolkit - shared libraries
    ii  libssl1.0.2:amd64                         1.0.2j-4                          amd64        Secure Sockets Layer toolkit - shared libraries
    ii  libssl1.0.2:i386                          1.0.2j-4                          i386         Secure Sockets Layer toolkit - shared libraries
    ii  libssl1.1:amd64                           1.1.0b-2                          amd64        Secure Sockets Layer toolkit - shared libraries
    ii  libstartup-notification0:amd64            0.12-4                            amd64        library for program launch feedback (shared library)
    ii  libstartup-notification0-dev:amd64        0.12-4                            amd64        library for program launch feedback (development headers)
    ii  libstdc++-5-dev:amd64                     5.4.1-3                           amd64        GNU Standard C++ Library v3 (development files)
    ii  libstdc++-6-dev:amd64                     6.2.0-11                          amd64        GNU Standard C++ Library v3 (development files)
    ii  libstdc++6:amd64                          6.2.0-11                          amd64        GNU Standard C++ Library v3
    ii  libstdc++6:i386                           6.2.0-11                          i386         GNU Standard C++ Library v3
    ii  libstemmer0d:amd64                        0+svn585-1                        amd64        Snowball stemming algorithms for use in Information Retrieval
    ii  libstoken1:amd64                          0.90-1                            amd64        Software Token for cryptographic authentication - shared library
    ii  libstrongswan                             5.5.1-1                           amd64        strongSwan utility and crypto library
    ii  libstrongswan-standard-plugins            5.5.1-1                           amd64        strongSwan utility and crypto library (standard plugins)
    ii  libsub-name-perl                          0.21-1                            amd64        module for assigning a new name to referenced sub
    ii  libsuitesparseconfig4:amd64               1:4.5.3-2                         amd64        configuration routines for all SuiteSparse modules
    rc  libsuperlu4:amd64                         4.3+dfsg-3                        amd64        Direct solution of large, sparse systems of linear equations
    ii  libsuperlu5:amd64                         5.2.1+dfsg1-2                     amd64        Direct solution of large, sparse systems of linear equations
    ii  libsvn1:amd64                             1.9.4-3+b1                        amd64        Shared libraries used by Apache Subversion
    ii  libswresample-ffmpeg1:amd64               7:2.8.6-1+b2                      amd64        FFmpeg library for audio resampling, rematrixing etc. - runtime files
    ii  libswresample2:amd64                      7:3.2.2-1                         amd64        FFmpeg library for audio resampling, rematrixing etc. - runtime files
    ii  libswresample2:i386                       7:3.2.2-1                         i386         FFmpeg library for audio resampling, rematrixing etc. - runtime files
    ii  libswscale-ffmpeg3:amd64                  7:2.8.6-1+b2                      amd64        FFmpeg library for image scaling and various conversions - runtime files
    ii  libswscale4:amd64                         7:3.2.2-1                         amd64        FFmpeg library for image scaling and various conversions - runtime files
    ii  libsynctex1:amd64                         2016.20160513.41080-7+b1          amd64        TeX Live: SyncTeX parser library
    ii  libsys-hostname-long-perl                 1.5-1                             all          Figure out the long (fully-qualified) hostname
    ii  libsystemd0:amd64                         231-1                             amd64        systemd utility library
    ii  libsystemd0:i386                          231-1                             i386         systemd utility library
    ii  libsz2:amd64                              0.3.2-1                           amd64        Adaptive Entropy Coding library - SZIP
    ii  libtag1v5:amd64                           1.11.1-0.1                        amd64        audio meta-data library
    ii  libtag1v5-vanilla:amd64                   1.11.1-0.1                        amd64        audio meta-data library - vanilla flavour
    ii  libtalloc2:amd64                          2.1.8-1                           amd64        hierarchical pool based memory allocator
    ii  libtasn1-6:amd64                          4.9-4                             amd64        Manage ASN.1 structures (runtime)
    ii  libtasn1-6:i386                           4.9-4                             i386         Manage ASN.1 structures (runtime)
    ii  libtasn1-6-dev:amd64                      4.9-4                             amd64        Manage ASN.1 structures (development)
    ii  libtasn1-doc                              4.9-4                             all          Manage ASN.1 structures (documentation)
    ii  libtbb2:amd64                             4.3~20150611-2                    amd64        parallelism library for C++ - runtime files
    ii  libtcl8.6:amd64                           8.6.6+dfsg-1                      amd64        Tcl (the Tool Command Language) v8.6 - run-time library files
    ii  libtcnative-1:amd64                       1.2.8-1                           amd64        Tomcat native library using the Apache Portable Runtime
    ii  libtdb1:amd64                             1.3.11-2                          amd64        Trivial Database - shared library
    ii  libteamdctl0:amd64                        1.26-1                            amd64        library for communication with `teamd` process
    ii  libterm-readkey-perl                      2.37-1                            amd64        perl module for simple terminal control
    rc  libtesseract3                             3.04.00-5+b1                      amd64        Tesseract OCR library
    ii  libtesseract4                             3.04.01-2                         amd64        Tesseract OCR library
    ii  libtevent0:amd64                          0.9.31-1                          amd64        talloc-based event loop library - shared library
    ii  libtexlua52:amd64                         2016.20160513.41080-7+b1          amd64        TeX Live: Lua 5.2, modified for use with LuaTeX
    ii  libtexluajit2:amd64                       2016.20160513.41080-7+b1          amd64        TeX Live: LuaJIT, modified for use with LuaJITTeX
    ii  libtext-charwidth-perl                    0.04-7+b5                         amd64        get display widths of characters on the terminal
    ii  libtext-iconv-perl                        1.7-5+b4                          amd64        converts between character sets in Perl
    ii  libtext-levenshtein-perl                  0.13-1                            all          implementation of the Levenshtein edit distance
    ii  libtext-wrapi18n-perl                     0.06-7.1                          all          internationalized substitute of Text::Wrap
    ii  libthai-data                              0.1.25-2                          all          Data files for Thai language support library
    ii  libthai0:amd64                            0.1.25-2                          amd64        Thai language support library
    ii  libtheora0:amd64                          1.1.1+dfsg.1-14                   amd64        Theora Video Compression Codec
    ii  libtheora0:i386                           1.1.1+dfsg.1-14                   i386         Theora Video Compression Codec
    ii  libtiff5:amd64                            4.0.6-3                           amd64        Tag Image File Format (TIFF) library
    ii  libtiff5:i386                             4.0.6-3                           i386         Tag Image File Format (TIFF) library
    ii  libtiff5-dev:amd64                        4.0.6-3                           amd64        Tag Image File Format library (TIFF), development files
    ii  libtiffxx5:amd64                          4.0.6-3                           amd64        Tag Image File Format (TIFF) library -- C++ interface
    ii  libtimedate-perl                          2.3000-2                          all          collection of modules to manipulate date/time information
    ii  libtinfo-dev:amd64                        6.0+20160917-1                    amd64        developer's library for the low-level terminfo library
    ii  libtinfo5:amd64                           6.0+20160917-1                    amd64        shared low-level terminfo library for terminal handling
    ii  libtinfo5:i386                            6.0+20160917-1                    i386         shared low-level terminfo library for terminal handling
    ii  libtinyxml2-2:amd64                       2.2.0-1.1                         amd64        C++ XML parsing library
    ii  libtinyxml2-4:amd64                       4.0.1-1                           amd64        C++ XML parsing library
    ii  libtinyxml2.6.2v5:amd64                   2.6.2-4                           amd64        C++ XML parsing library
    ii  libtk8.6:amd64                            8.6.6-1                           amd64        Tk toolkit for Tcl and X11 v8.6 - run-time files
    ii  libtomcat8-java                           8.5.9-2                           all          Apache Tomcat 8 - Servlet and JSP engine -- core libraries
    ii  libtomcrypt0:amd64                        1.17-8                            amd64        public domain open source cryptographic toolkit
    ii  libtommath0                               0.42.0-1.2                        amd64        multiple-precision integer library [runtime]
    ii  libtommath1:amd64                         1.0-3                             amd64        multiple-precision integer library [runtime]
    ii  libtool                                   2.4.6-2                           all          Generic library support script
    ii  libtorrent-rasterbar9                     1.1.1-1                           amd64        C++ bittorrent library by Rasterbar Software
    ii  libtracker-sparql-1.0-0:amd64             1.10.1-1                          amd64        metadata database, indexer and search tool - library
    ii  libtrio2:amd64                            1.16+dfsg1-3                      amd64        portable and extendable printf and string functions
    ii  libtsan0:amd64                            6.2.0-11                          amd64        ThreadSanitizer -- a Valgrind-based detector of data races (runtime)
    ii  libtwolame0:amd64                         0.3.13-1.2                        amd64        MPEG Audio Layer 2 encoding library
    ii  libtwolame0:i386                          0.3.13-1.2                        i386         MPEG Audio Layer 2 encoding library
    ii  libtxc-dxtn-s2tc:amd64                    1.0+git20151227-1                 amd64        Texture compression library for Mesa
    ii  libtxc-dxtn-s2tc:i386                     1.0+git20151227-1                 i386         Texture compression library for Mesa
    rc  libtxc-dxtn-s2tc0:i386                    0~git20131104-1.1                 i386         Texture compression library for Mesa
    ii  libubsan0:amd64                           6.2.0-11                          amd64        UBSan -- undefined behaviour sanitizer (runtime)
    ii  libuchardet0                              0.0.1-1                           amd64        universal charset detection library - shared library
    ii  libudev1:amd64                            231-1                             amd64        libudev shared library
    ii  libudev1:i386                             231-1                             i386         libudev shared library
    ii  libudisks2-0:amd64                        2.1.7-1.1                         amd64        GObject based library to access udisks2
    ii  libumfpack5:amd64                         1:4.5.3-2                         amd64        sparse LU factorization library
    ii  libunbound2:amd64                         1.5.10-2                          amd64        library implementing DNS resolution and validation
    ii  libunique-1.0-0                           1.1.6-5                           amd64        Library for writing single instance applications - shared libraries
    ii  libunistring0:amd64                       0.9.6+really0.9.3-0.1             amd64        Unicode string library for C
    ii  libupnp6                                  1:1.6.19+git20160116-1.2          amd64        Portable SDK for UPnP Devices, version 1.6 (shared libraries)
    ii  libupower-glib3:amd64                     0.99.4-4                          amd64        abstraction for power management - shared library
    ii  liburi-perl                               1.71-1                            all          module to manipulate and access URI strings
    ii  liburiparser1:amd64                       0.8.4-1                           amd64        URI parsing library compliant with RFC 3986
    rc  libusageenvironment1                      2014.01.13-1                      amd64        multimedia RTSP streaming library (UsageEnvironment classes)
    ii  libusageenvironment3:amd64                2016.11.06-1                      amd64        multimedia RTSP streaming library (UsageEnvironment classes)
    ii  libusb-0.1-4:amd64                        2:0.1.12-30                       amd64        userspace USB programming library
    ii  libusb-1.0-0:amd64                        2:1.0.21-1                        amd64        userspace USB programming library
    ii  libusb-1.0-0:i386                         2:1.0.21-1                        i386         userspace USB programming library
    ii  libusbmuxd2:amd64                         1.0.9-1+b1                        amd64        USB multiplexor daemon for iPhone and iPod Touch devices - library
    ii  libusbmuxd4:amd64                         1.0.10-3                          amd64        USB multiplexor daemon for iPhone and iPod Touch devices - library
    ii  libusbredirparser1:amd64                  0.7.1-1                           amd64        Parser for the usbredir protocol (runtime)
    ii  libustr-1.0-1:amd64                       1.0.4-5                           amd64        Micro string library: shared library
    ii  libutempter0:amd64                        1.1.6-3                           amd64        privileged helper for utmp/wtmp updates (runtime)
    ii  libuuid1:amd64                            2.28.2-1                          amd64        Universally Unique ID library
    ii  libuuid1:i386                             2.28.2-1                          i386         Universally Unique ID library
    ii  libuv1:amd64                              1.9.1-3                           amd64        asynchronous event notification library - runtime library
    ii  libv4l-0:amd64                            1.10.1-1                          amd64        Collection of video4linux support libraries
    ii  libv4l-0:i386                             1.10.1-1                          i386         Collection of video4linux support libraries
    ii  libv4lconvert0:amd64                      1.10.1-1                          amd64        Video4linux frame format conversion library
    ii  libv4lconvert0:i386                       1.10.1-1                          i386         Video4linux frame format conversion library
    ii  libva-drm1:amd64                          1.7.3-2                           amd64        Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libva-drm1:i386                           1.7.3-2                           i386         Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libva-x11-1:amd64                         1.7.3-2                           amd64        Video Acceleration (VA) API for Linux -- X11 runtime
    ii  libva-x11-1:i386                          1.7.3-2                           i386         Video Acceleration (VA) API for Linux -- X11 runtime
    ii  libva1:amd64                              1.7.3-2                           amd64        Video Acceleration (VA) API for Linux -- runtime
    ii  libva1:i386                               1.7.3-2                           i386         Video Acceleration (VA) API for Linux -- runtime
    ii  libvala-0.34-0:amd64                      0.34.2-1                          amd64        C# like language for the GObject system - library
    ii  libvcdinfo0                               0.7.24+dfsg-0.2                   amd64        library to extract information from VideoCD
    ii  libvdeplug2                               2.3.2+r586-2+b1                   amd64        Virtual Distributed Ethernet - Plug library
    ii  libvdpau-va-gl1:amd64                     0.4.2-1                           amd64        VDPAU driver with OpenGL/VAAPI backend
    ii  libvdpau-va-gl1:i386                      0.4.2-1                           i386         VDPAU driver with OpenGL/VAAPI backend
    ii  libvdpau1:amd64                           1.1.1-5                           amd64        Video Decode and Presentation API for Unix (libraries)
    ii  libvdpau1:i386                            1.1.1-5                           i386         Video Decode and Presentation API for Unix (libraries)
    ii  libvisio-0.1-1:amd64                      0.1.5-4                           amd64        library for parsing the visio file structure
    ii  libvisual-0.4-0:amd64                     0.4.0-9                           amd64        audio visualization framework
    rc  libvisual-0.4-0:i386                      0.4.0-8                           i386         audio visualization framework
    ii  libvlc-bin:amd64                          2.2.4-7                           amd64        tools for VLC's base library
    ii  libvlc5:amd64                             2.2.4-7                           amd64        multimedia player and streamer library
    ii  libvlccore8:amd64                         2.2.4-7                           amd64        base library for VLC and its modules
    ii  libvncserver1:amd64                       0.9.11+dfsg-1                     amd64        API to write one's own VNC server
    ii  libvo-aacenc0:amd64                       0.1.3-1                           amd64        VisualOn AAC encoder library
    ii  libvo-amrwbenc0:amd64                     0.1.3-1                           amd64        VisualOn AMR-WB encoder library
    ii  libvorbis0a:amd64                         1.3.5-3                           amd64        decoder library for Vorbis General Audio Compression Codec
    ii  libvorbis0a:i386                          1.3.5-3                           i386         decoder library for Vorbis General Audio Compression Codec
    ii  libvorbisenc2:amd64                       1.3.5-3                           amd64        encoder library for Vorbis General Audio Compression Codec
    ii  libvorbisenc2:i386                        1.3.5-3                           i386         encoder library for Vorbis General Audio Compression Codec
    ii  libvorbisfile3:amd64                      1.3.5-3                           amd64        high-level API for Vorbis General Audio Compression Codec
    ii  libvpx2:amd64                             1.4.0-4                           amd64        VP8 and VP9 video codec (shared library)
    rc  libvpx2:i386                              1.4.0-4                           i386         VP8 and VP9 video codec (shared library)
    ii  libvpx3:amd64                             1.5.0-4                           amd64        VP8 and VP9 video codec (shared library)
    ii  libvpx4:amd64                             1.6.0-2                           amd64        VP8 and VP9 video codec (shared library)
    ii  libvpx4:i386                              1.6.0-2                           i386         VP8 and VP9 video codec (shared library)
    ii  libvte-2.91-0:amd64                       0.46.0-1                          amd64        Terminal emulator widget for GTK+ 3.0 - runtime files
    ii  libvte-2.91-common                        0.46.0-1                          all          Terminal emulator widget for GTK+ 3.0 - common files
    ii  libvte-2.91-dev:amd64                     0.46.0-1                          amd64        Terminal emulator widget for GTK+ 3.0 - development files
    ii  libvte-2.91-doc                           0.46.0-1                          all          Terminal emulator widget for GTK+ 3.0 - documentation
    ii  libvte-common                             1:0.28.2-7                        all          Terminal emulator widget for GTK+ 2.x - common files
    ii  libvte9                                   1:0.28.2-7                        amd64        Terminal emulator widget for GTK+ 2.0 - runtime files
    ii  libvtk6.3                                 6.3.0+dfsg1-2                     amd64        VTK libraries
    ii  libvtk6.3-qt                              6.3.0+dfsg1-2                     amd64        VTK libraries, Qt files
    ii  libwacom-bin                              0.22-1                            amd64        Wacom model feature query library -- binaries
    ii  libwacom-common                           0.22-1                            all          Wacom model feature query library (common files)
    ii  libwacom2:amd64                           0.22-1                            amd64        Wacom model feature query library
    ii  libwavpack1:amd64                         4.80.0-1                          amd64        audio codec (lossy and lossless) - library
    ii  libwavpack1:i386                          4.80.0-1                          i386         audio codec (lossy and lossless) - library
    ii  libwayland-bin                            1.11.0-2                          amd64        wayland compositor infrastructure - binary utilities
    ii  libwayland-client0:amd64                  1.11.0-2                          amd64        wayland compositor infrastructure - client library
    ii  libwayland-cursor0:amd64                  1.11.0-2                          amd64        wayland compositor infrastructure - cursor library
    ii  libwayland-dev:amd64                      1.11.0-2                          amd64        wayland compositor infrastructure - development files
    ii  libwayland-egl1-mesa:amd64                12.0.3-3                          amd64        implementation of the Wayland EGL platform -- runtime
    ii  libwayland-server0:amd64                  1.11.0-2                          amd64        wayland compositor infrastructure - server library
    ii  libwbclient0:amd64                        2:4.4.7+dfsg-1                    amd64        Samba winbind client library
    ii  libwebkit2gtk-4.0-37:amd64                2.14.2-1                          amd64        Web content engine library for GTK+
    ii  libwebkit2gtk-4.0-37-gtk2:amd64           2.14.2-1                          amd64        Web content engine library for GTK+ - GTK+2 plugin process
    ii  libwebkitgtk-1.0-0:amd64                  2.4.11-3                          amd64        Web content engine library for GTK+
    ii  libwebkitgtk-3.0-0:amd64                  2.4.11-3                          amd64        Web content engine library for GTK+
    ii  libwebp5:amd64                            0.4.4-1.1                         amd64        Lossy compression of digital photographic images.
    ii  libwebp6:amd64                            0.5.1-2                           amd64        Lossy compression of digital photographic images.
    ii  libwebp6:i386                             0.5.1-2                           i386         Lossy compression of digital photographic images.
    ii  libwebpdemux1:amd64                       0.4.4-1.1                         amd64        Lossy compression of digital photographic images.
    ii  libwebpdemux2:amd64                       0.5.1-2                           amd64        Lossy compression of digital photographic images.
    ii  libwebpmux1:amd64                         0.4.4-1.1                         amd64        Lossy compression of digital photographic images.
    ii  libwebpmux2:amd64                         0.5.1-2                           amd64        Lossy compression of digital photographic images.
    ii  libwebpmux2:i386                          0.5.1-2                           i386         Lossy compression of digital photographic images.
    ii  libwebrtc-audio-processing-0:amd64        0.1-3                             amd64        AudioProcessing module from the WebRTC project.
    ii  libwebrtc-audio-processing1:amd64         0.3-1                             amd64        AudioProcessing module from the WebRTC project.
    ii  libwildmidi-config                        0.4.0-2                           all          software MIDI player configuration
    ii  libwildmidi1:amd64                        0.3.8-2                           amd64        software MIDI player library
    ii  libwildmidi2:amd64                        0.4.0-2                           amd64        software MIDI player library
    ii  libwind0-heimdal:amd64                    1.7~git20160703+dfsg-1+b1         amd64        Heimdal Kerberos - stringprep implementation
    ii  libwmf-dev                                0.2.8.4-10.5+b1                   amd64        Windows metafile conversion development
    ii  libwmf0.2-7:amd64                         0.2.8.4-10.5+b1                   amd64        Windows metafile conversion library
    ii  libwnck-3-0:amd64                         3.20.1-2                          amd64        Window Navigator Construction Kit - runtime files
    ii  libwnck-3-common                          3.20.1-2                          all          Window Navigator Construction Kit - common files
    ii  libwnck-3-dev                             3.20.1-2                          amd64        Window Navigator Construction Kit - development files
    ii  libwnck-common                            2.30.7-5                          all          Window Navigator Construction Kit - common files
    ii  libwnck22:amd64                           2.30.7-5                          amd64        Window Navigator Construction Kit - runtime files
    ii  libwpd-0.10-10:amd64                      0.10.1-5                          amd64        Library for handling WordPerfect documents (shared library)
    ii  libwpg-0.3-3:amd64                        0.3.1-3                           amd64        WordPerfect graphics import/convert library (shared library)
    ii  libwps-0.4-4:amd64                        0.4.4-1                           amd64        Works text file format import filter library (shared library)
    ii  libwrap0:amd64                            7.6.q-25                          amd64        Wietse Venema's TCP wrappers library
    ii  libwrap0:i386                             7.6.q-25                          i386         Wietse Venema's TCP wrappers library
    ii  libwww-perl                               6.15-1                            all          simple and consistent interface to the world-wide web
    ii  libwww-robotrules-perl                    6.01-1                            all          database of robots.txt-derived permissions
    ii  libwxbase3.0-0v5:amd64                    3.0.2+dfsg-2                      amd64        wxBase library (runtime) - non-GUI support classes of wxWidgets toolkit
    ii  libwxgtk3.0-0v5:amd64                     3.0.2+dfsg-2                      amd64        wxWidgets Cross-platform C++ GUI toolkit (GTK+ runtime)
    ii  libx11-6:amd64                            2:1.6.3-1                         amd64        X11 client-side library
    ii  libx11-6:i386                             2:1.6.3-1                         i386         X11 client-side library
    ii  libx11-data                               2:1.6.3-1                         all          X11 client-side library
    ii  libx11-dev:amd64                          2:1.6.3-1                         amd64        X11 client-side library (development headers)
    ii  libx11-doc                                2:1.6.3-1                         all          X11 client-side library (development documentation)
    ii  libx11-xcb-dev:amd64                      2:1.6.3-1                         amd64        Xlib/XCB interface library (development headers)
    ii  libx11-xcb1:amd64                         2:1.6.3-1                         amd64        Xlib/XCB interface library
    ii  libx11-xcb1:i386                          2:1.6.3-1                         i386         Xlib/XCB interface library
    ii  libx264-148:amd64                         2:0.148.2708+git86b7198-1         amd64        x264 video coding library
    ii  libx264-148:i386                          2:0.148.2708+git86b7198-1         i386         x264 video coding library
    ii  libx265-68:amd64                          1.8-6                             amd64        H.265/HEVC video stream encoder (shared library)
    ii  libx265-79:amd64                          1.9-3                             amd64        H.265/HEVC video stream encoder (shared library)
    ii  libx265-95:amd64                          2.1-2                             amd64        H.265/HEVC video stream encoder (shared library)
    ii  libx265-95:i386                           2.1-2                             i386         H.265/HEVC video stream encoder (shared library)
    ii  libxapian22v5:amd64                       1.2.23-1                          amd64        Search engine library
    ii  libxapian30:amd64                         1.4.1-1                           amd64        Search engine library
    ii  libxatracker2:amd64                       12.0.3-3                          amd64        X acceleration library -- runtime
    ii  libxau-dev:amd64                          1:1.0.8-1                         amd64        X11 authorisation library (development headers)
    ii  libxau6:amd64                             1:1.0.8-1                         amd64        X11 authorisation library
    ii  libxau6:i386                              1:1.0.8-1                         i386         X11 authorisation library
    ii  libxaw7:amd64                             2:1.0.13-1                        amd64        X11 Athena Widget library
    ii  libxcb-composite0:amd64                   1.12-1                            amd64        X C Binding, composite extension
    ii  libxcb-damage0:amd64                      1.12-1                            amd64        X C Binding, damage extension
    ii  libxcb-dri2-0:amd64                       1.12-1                            amd64        X C Binding, dri2 extension
    ii  libxcb-dri2-0:i386                        1.12-1                            i386         X C Binding, dri2 extension
    ii  libxcb-dri2-0-dev:amd64                   1.12-1                            amd64        X C Binding, dri2 extension, development files
    ii  libxcb-dri3-0:amd64                       1.12-1                            amd64        X C Binding, dri3 extension
    ii  libxcb-dri3-0:i386                        1.12-1                            i386         X C Binding, dri3 extension
    ii  libxcb-dri3-dev:amd64                     1.12-1                            amd64        X C Binding, dri3 extension, development files
    ii  libxcb-ewmh2:amd64                        0.4.1-1                           amd64        utility libraries for X C Binding -- ewmh
    ii  libxcb-glx0:amd64                         1.12-1                            amd64        X C Binding, glx extension
    ii  libxcb-glx0:i386                          1.12-1                            i386         X C Binding, glx extension
    ii  libxcb-glx0-dev:amd64                     1.12-1                            amd64        X C Binding, glx extension, development files
    ii  libxcb-icccm4:amd64                       0.4.1-1                           amd64        utility libraries for X C Binding -- icccm
    ii  libxcb-image0:amd64                       0.4.0-1                           amd64        utility libraries for X C Binding -- image
    ii  libxcb-keysyms1:amd64                     0.4.0-1                           amd64        utility libraries for X C Binding -- keysyms
    ii  libxcb-present-dev:amd64                  1.12-1                            amd64        X C Binding, present extension, development files
    ii  libxcb-present0:amd64                     1.12-1                            amd64        X C Binding, present extension
    ii  libxcb-present0:i386                      1.12-1                            i386         X C Binding, present extension
    ii  libxcb-randr0:amd64                       1.12-1                            amd64        X C Binding, randr extension
    ii  libxcb-randr0:i386                        1.12-1                            i386         X C Binding, randr extension
    ii  libxcb-randr0-dev:amd64                   1.12-1                            amd64        X C Binding, randr extension, development files
    ii  libxcb-render-util0:amd64                 0.3.9-1                           amd64        utility libraries for X C Binding -- render-util
    ii  libxcb-render0:amd64                      1.12-1                            amd64        X C Binding, render extension
    ii  libxcb-render0:i386                       1.12-1                            i386         X C Binding, render extension
    ii  libxcb-render0-dev:amd64                  1.12-1                            amd64        X C Binding, render extension, development files
    ii  libxcb-shape0:amd64                       1.12-1                            amd64        X C Binding, shape extension
    ii  libxcb-shape0:i386                        1.12-1                            i386         X C Binding, shape extension
    ii  libxcb-shape0-dev:amd64                   1.12-1                            amd64        X C Binding, shape extension, development files
    ii  libxcb-shm0:amd64                         1.12-1                            amd64        X C Binding, shm extension
    ii  libxcb-shm0:i386                          1.12-1                            i386         X C Binding, shm extension
    ii  libxcb-shm0-dev:amd64                     1.12-1                            amd64        X C Binding, shm extension, development files
    ii  libxcb-sync-dev:amd64                     1.12-1                            amd64        X C Binding, sync extension, development files
    ii  libxcb-sync1:amd64                        1.12-1                            amd64        X C Binding, sync extension
    ii  libxcb-sync1:i386                         1.12-1                            i386         X C Binding, sync extension
    ii  libxcb-util0:amd64                        0.3.8-3                           amd64        utility libraries for X C Binding -- atom, aux and event
    ii  libxcb-util0-dev:amd64                    0.3.8-3                           amd64        utility libraries for X C Binding -- atom, aux and event
    ii  libxcb-xfixes0:amd64                      1.12-1                            amd64        X C Binding, xfixes extension
    ii  libxcb-xfixes0:i386                       1.12-1                            i386         X C Binding, xfixes extension
    ii  libxcb-xfixes0-dev:amd64                  1.12-1                            amd64        X C Binding, xfixes extension, development files
    ii  libxcb-xinerama0:amd64                    1.12-1                            amd64        X C Binding, xinerama extension
    ii  libxcb-xkb1:amd64                         1.12-1                            amd64        X C Binding, XKEYBOARD extension
    ii  libxcb-xtest0:amd64                       1.12-1                            amd64        X C Binding, xtest extension
    ii  libxcb-xv0:amd64                          1.12-1                            amd64        X C Binding, xv extension
    ii  libxcb1:amd64                             1.12-1                            amd64        X C Binding
    ii  libxcb1:i386                              1.12-1                            i386         X C Binding
    ii  libxcb1-dev:amd64                         1.12-1                            amd64        X C Binding, development files
    ii  libxcomp3:amd64                           3.5.0.32-1+b1                     amd64        NX X compression library
    ii  libxcomposite-dev                         1:0.4.4-1                         amd64        X11 Composite extension library (development headers)
    ii  libxcomposite1:amd64                      1:0.4.4-1                         amd64        X11 Composite extension library
    ii  libxcomposite1:i386                       1:0.4.4-1                         i386         X11 Composite extension library
    ii  libxcursor-dev:amd64                      1:1.1.14-1+b1                     amd64        X cursor management library (development files)
    ii  libxcursor1:amd64                         1:1.1.14-1+b1                     amd64        X cursor management library
    ii  libxcursor1:i386                          1:1.1.14-1+b1                     i386         X cursor management library
    ii  libxdamage-dev:amd64                      1:1.1.4-2+b1                      amd64        X11 damaged region extension library (development headers)
    ii  libxdamage1:amd64                         1:1.1.4-2+b1                      amd64        X11 damaged region extension library
    ii  libxdamage1:i386                          1:1.1.4-2+b1                      i386         X11 damaged region extension library
    ii  libxdmcp-dev:amd64                        1:1.1.2-1.1                       amd64        X11 authorisation library (development headers)
    ii  libxdmcp6:amd64                           1:1.1.2-1.1                       amd64        X11 Display Manager Control Protocol library
    ii  libxdmcp6:i386                            1:1.1.2-1.1                       i386         X11 Display Manager Control Protocol library
    ii  libxdo3:amd64                             1:3.20160512.1-1                  amd64        library for simulating (generating) X11 keyboard/mouse input events
    ii  libxdot4                                  2.38.0-16                         amd64        rich set of graph drawing tools - xdot library
    ii  libxen-4.6:amd64                          4.6.0-1+nmu2                      amd64        Public libs for Xen
    ii  libxenstore3.0:amd64                      4.6.0-1+nmu2                      amd64        Xenstore communications library for Xen
    ii  libxerces-c3.1:amd64                      3.1.3+debian-2.1+b1               amd64        validating XML parser library for C++
    ii  libxext-dev:amd64                         2:1.3.3-1                         amd64        X11 miscellaneous extensions library (development headers)
    ii  libxext6:amd64                            2:1.3.3-1                         amd64        X11 miscellaneous extension library
    ii  libxext6:i386                             2:1.3.3-1                         i386         X11 miscellaneous extension library
    ii  libxfixes-dev:amd64                       1:5.0.2-1                         amd64        X11 miscellaneous 'fixes' extension library (development headers)
    ii  libxfixes3:amd64                          1:5.0.2-1                         amd64        X11 miscellaneous 'fixes' extension library
    ii  libxfixes3:i386                           1:5.0.2-1                         i386         X11 miscellaneous 'fixes' extension library
    ii  libxfont1:amd64                           1:1.5.2-1                         amd64        X11 font rasterisation library
    ii  libxfont2:amd64                           1:2.0.1-3                         amd64        X11 font rasterisation library
    ii  libxft-dev                                2.3.2-1                           amd64        FreeType-based font drawing library for X (development files)
    ii  libxft2:amd64                             2.3.2-1                           amd64        FreeType-based font drawing library for X
    ii  libxi-dev                                 2:1.7.6-1                         amd64        X11 Input extension library (development headers)
    ii  libxi6:amd64                              2:1.7.6-1                         amd64        X11 Input extension library
    ii  libxi6:i386                               2:1.7.6-1                         i386         X11 Input extension library
    ii  libxinerama-dev:amd64                     2:1.1.3-1+b1                      amd64        X11 Xinerama extension library (development headers)
    ii  libxinerama1:amd64                        2:1.1.3-1+b1                      amd64        X11 Xinerama extension library
    ii  libxinerama1:i386                         2:1.1.3-1+b1                      i386         X11 Xinerama extension library
    ii  libxkbcommon-dev                          0.6.1-1                           amd64        library interface to the XKB compiler - development files
    ii  libxkbcommon-x11-0:amd64                  0.6.1-1                           amd64        library to create keymaps with the XKB X11 protocol
    ii  libxkbcommon0:amd64                       0.6.1-1                           amd64        library interface to the XKB compiler - shared library
    ii  libxkbfile1:amd64                         1:1.0.9-2                         amd64        X11 keyboard file manipulation library
    ii  libxklavier16:amd64                       5.4-2                             amd64        X Keyboard Extension high-level API
    rc  libxml-commons-resolver1.1-java           1.2-7                             all          XML entity and URI resolver library
    ii  libxml-parser-perl                        2.44-2+b1                         amd64        Perl module for parsing XML files
    ii  libxml2:amd64                             2.9.4+dfsg1-2.1                   amd64        GNOME XML library
    ii  libxml2:i386                              2.9.4+dfsg1-2.1                   i386         GNOME XML library
    ii  libxml2-dev:amd64                         2.9.4+dfsg1-2.1                   amd64        Development files for the GNOME XML library
    ii  libxml2-utils                             2.9.4+dfsg1-2.1                   amd64        XML utilities
    ii  libxmu6:amd64                             2:1.1.2-2                         amd64        X11 miscellaneous utility library
    ii  libxmuu1:amd64                            2:1.1.2-2                         amd64        X11 miscellaneous micro-utility library
    ii  libxpm4:amd64                             1:3.5.11-1+b1                     amd64        X11 pixmap library
    ii  libxpm4:i386                              1:3.5.11-1+b1                     i386         X11 pixmap library
    ii  libxrandr-dev:amd64                       2:1.5.0-1                         amd64        X11 RandR extension library (development headers)
    ii  libxrandr2:amd64                          2:1.5.0-1                         amd64        X11 RandR extension library
    ii  libxrandr2:i386                           2:1.5.0-1                         i386         X11 RandR extension library
    ii  libxrender-dev:amd64                      1:0.9.9-2                         amd64        X Rendering Extension client library (development files)
    ii  libxrender1:amd64                         1:0.9.9-2                         amd64        X Rendering Extension client library
    ii  libxrender1:i386                          1:0.9.9-2                         i386         X Rendering Extension client library
    ii  libxres-dev                               2:1.0.7-1+b1                      amd64        X11 Resource extension library (development headers)
    ii  libxres1:amd64                            2:1.0.7-1+b1                      amd64        X11 Resource extension library
    ii  libxshmfence-dev:amd64                    1.2-1                             amd64        X shared memory fences - development files
    ii  libxshmfence1:amd64                       1.2-1                             amd64        X shared memory fences - shared library
    ii  libxshmfence1:i386                        1.2-1                             i386         X shared memory fences - shared library
    ii  libxslt1.1:amd64                          1.1.29-2                          amd64        XSLT 1.0 processing library - runtime library
    ii  libxslt1.1:i386                           1.1.29-2                          i386         XSLT 1.0 processing library - runtime library
    ii  libxss1:amd64                             1:1.2.2-1                         amd64        X11 Screen Saver extension library
    rc  libxss1:i386                              1:1.2.2-1                         i386         X11 Screen Saver extension library
    ii  libxt-dev:amd64                           1:1.1.5-1                         amd64        X11 toolkit intrinsics library (development headers)
    ii  libxt6:amd64                              1:1.1.5-1                         amd64        X11 toolkit intrinsics library
    ii  libxt6:i386                               1:1.1.5-1                         i386         X11 toolkit intrinsics library
    ii  libxtables10                              1.4.21-2+b1                       amd64        netfilter xtables library
    ii  libxtables11:amd64                        1.6.0-4                           amd64        netfilter xtables library
    ii  libxtst-dev:amd64                         2:1.2.2-1+b1                      amd64        X11 Record extension library (development headers)
    ii  libxtst6:amd64                            2:1.2.2-1+b1                      amd64        X11 Testing -- Record extension library
    ii  libxtst6:i386                             2:1.2.2-1+b1                      i386         X11 Testing -- Record extension library
    ii  libxv1:amd64                              2:1.0.10-1+b1                     amd64        X11 Video extension library
    rc  libxv1:i386                               2:1.0.10-1+b1                     i386         X11 Video extension library
    ii  libxvidcore4:amd64                        2:1.3.4-1                         amd64        Open source MPEG-4 video codec (library)
    ii  libxvidcore4:i386                         2:1.3.4-1                         i386         Open source MPEG-4 video codec (library)
    ii  libxvmc1:amd64                            2:1.0.9-1                         amd64        X11 Video extension library
    ii  libxxf86dga1:amd64                        2:1.1.4-1+b1                      amd64        X11 Direct Graphics Access extension library
    ii  libxxf86vm-dev:amd64                      1:1.1.4-1                         amd64        X11 XFree86 video mode extension library (development headers)
    ii  libxxf86vm1:amd64                         1:1.1.4-1                         amd64        X11 XFree86 video mode extension library
    ii  libxxf86vm1:i386                          1:1.1.4-1                         i386         X11 XFree86 video mode extension library
    ii  libyajl2:amd64                            2.1.0-2                           amd64        Yet Another JSON Library
    ii  libyaml-0-2:amd64                         0.1.7-2                           amd64        Fast YAML 1.1 parser and emitter library
    ii  libyaml-libyaml-perl                      0.63-1+b1                         amd64        Perl interface to libyaml, a YAML implementation
    ii  libyaml-perl                              1.18-1                            all          YAML Ain't Markup Language
    ii  libyaml-tiny-perl                         1.69-1                            all          Perl module for reading and writing YAML files
    ii  libyelp0:amd64                            3.22.0-1                          amd64        Library for the GNOME help browser
    ii  libzbar-dev                               0.10+doc-10+b2                    amd64        bar code scanner and decoder (development)
    ii  libzbar0                                  0.10+doc-10+b2                    amd64        bar code scanner and decoder (library)
    ii  libzen0v5:amd64                           0.4.33-3                          amd64        ZenLib C++ utility library -- runtime
    ii  libzipios++0v5                            0.1.5.9+cvs.2007.04.28-6          amd64        small C++ library for reading zip files (library)
    ii  libzmq3:amd64                             4.0.5+dfsg-3+b1                   amd64        lightweight messaging kernel (shared library)
    ii  libzmq5:amd64                             4.2.0-1                           amd64        lightweight messaging kernel (shared library)
    ii  libzvbi-common                            0.2.35-12                         all          Vertical Blanking Interval decoder (VBI) - common files
    ii  libzvbi0:amd64                            0.2.35-12                         amd64        Vertical Blanking Interval decoder (VBI) - runtime files
    ii  libzvbi0:i386                             0.2.35-12                         i386         Vertical Blanking Interval decoder (VBI) - runtime files
    ii  libzzip-0-13:amd64                        0.13.62-3                         amd64        library providing read access on ZIP-archives - library
    ii  lightdm                                   1.21.3-6                          amd64        simple display manager
    ii  lintian                                   2.5.49                            all          Debian package checker
    ii  linux-base                                4.5                               all          Linux image base package
    ii  linux-compiler-gcc-4.9-x86                4.2.6-3                           amd64        Compiler for Linux on x86 (meta-package)
    ii  linux-compiler-gcc-5-x86-deepin           4.4.30-2                          amd64        Compiler for Linux on x86 (meta-package)
    ii  linux-compiler-gcc-6-x86                  4.9.8-1                           amd64        Compiler for Linux on x86 (meta-package)
    ii  linux-headers-4.2.0-1-amd64               4.2.6-3                           amd64        Header files for Linux 4.2.0-1-amd64
    ii  linux-headers-4.2.0-1-common              4.2.6-3                           amd64        Common header files for Linux 4.2.0-1
    ii  linux-headers-4.4.0-3-deepin-amd64        4.4.30-2                          amd64        Header files for Linux 4.4.0-3-deepin-amd64
    ii  linux-headers-4.4.0-3-deepin-common       4.4.30-2                          amd64        Common header files for Linux 4.4.0-3-deepin
    ii  linux-headers-4.9.0-deepin1-amd64         4.9-1                             amd64        Header files for Linux 4.9.0-deepin1-amd64
    ii  linux-headers-4.9.0-deepin1-common        4.9-1                             all          Common header files for Linux 4.9.0-deepin1
    ii  linux-headers-4.9.0-deepin2-amd64         4.9.8-1                           amd64        Header files for Linux 4.9.0-deepin2-amd64
    ii  linux-headers-4.9.0-deepin2-common        4.9.8-1                           all          Common header files for Linux 4.9.0-deepin2
    ii  linux-headers-amd64                       4.3+75                            amd64        Header files for Linux amd64 configuration (meta-package)
    ii  linux-headers-deepin-amd64                4.9.8-1                           amd64        Header files for Linux amd64 configuration (meta-package)
    ii  linux-image-4.2.0-1-amd64                 4.2.6-3                           amd64        Linux 4.2 for 64-bit PCs
    rc  linux-image-4.3.0-1-amd64                 4.3.1-1                           amd64        Linux 4.3 for 64-bit PCs
    rc  linux-image-4.4.0-2-deepin-amd64          4.4.6-4                           amd64        Linux 4.4 for 64-bit PCs
    ii  linux-image-4.4.0-3-deepin-amd64          4.4.30-2                          amd64        Linux 4.4 for 64-bit PCs
    ii  linux-image-4.9.0-deepin1-amd64-unsigned  4.9-1                             amd64        Linux 4.9 for 64-bit PCs
    ii  linux-image-4.9.0-deepin2-amd64-unsigned  4.9.8-1                           amd64        Linux 4.9 for 64-bit PCs
    ii  linux-image-amd64                         4.3+75                            amd64        Linux for 64-bit PCs (meta-package)
    ii  linux-image-deepin-amd64                  4.9.8-1                           amd64        Linux for 64-bit PCs (meta-package)
    ii  linux-kbuild-4.2                          4.2-2                             amd64        Kbuild infrastructure for Linux 4.2
    ii  linux-kbuild-4.4                          4.4.6-1                           amd64        Kbuild infrastructure for Linux 4.4
    ii  linux-kbuild-4.9                          4.9.8-1                           amd64        Kbuild infrastructure for Linux 4.9
    ii  linux-libc-dev:amd64                      4.9.8-1                           amd64        Linux support headers for userspace development
    ii  llvm-3.8                                  1:3.8.1-15                        amd64        Modular compiler and toolchain technologies
    ii  llvm-3.8-dev                              1:3.8.1-15                        amd64        Modular compiler and toolchain technologies, libraries and headers
    ii  llvm-3.8-runtime                          1:3.8.1-15                        amd64        Modular compiler and toolchain technologies, IR interpreter
    ii  lmodern                                   2.004.5-3                         all          scalable PostScript and OpenType fonts based on Computer Modern
    ii  locales                                   2.24-5                            all          GNU C Library: National Language (locale) data [support]
    ii  login                                     1:4.2-3.2                         amd64        system login tools
    ii  logrotate                                 3.8.7-2                           amd64        Log rotation utility
    ii  lovewallpaper                             1.5.4-6~deepin                    all          Lovewallpaper,change wallpapers freely.
    ii  lp-solve                                  5.5.0.15-4+b1                     amd64        Solve (mixed integer) linear programming problems
    ii  lrzsz                                     0.12.21-8                         amd64        Tools for zmodem/xmodem/ymodem file transfer
    ii  lsb-base                                  9.20161101                        all          Linux Standard Base init script functionality
    ii  lsb-release                               9.20161101                        all          Linux Standard Base version reporting utility
    ii  lshw                                      02.18-0.1                         amd64        information about hardware configuration
    ii  lsof                                      4.89+dfsg-0.1                     amd64        Utility to list open files
    ii  lvm2                                      2.02.164-1                        amd64        Linux Logical Volume Manager
    ii  m4                                        1.4.17-5                          amd64        macro processing language
    ii  make                                      4.1-9                             amd64        utility for directing compilation
    ii  man-db                                    2.7.5-1                           amd64        on-line manual pager
    ii  manpages                                  4.08-1                            all          Manual pages about using a GNU/Linux system
    ii  manpages-dev                              4.08-1                            all          Manual pages about using GNU/Linux for development
    ii  mariadb-client-10.0                       10.0.28-1                         amd64        MariaDB database client binaries
    ii  mariadb-client-core-10.0                  10.0.28-1                         amd64        MariaDB database core client binaries
    ii  mariadb-common                            10.0.28-1                         all          MariaDB common metapackage
    ii  mariadb-server                            10.0.28-1                         all          MariaDB database server (metapackage depending on the latest version)
    ii  mariadb-server-10.0                       10.0.28-1                         amd64        MariaDB database server binaries
    ii  mariadb-server-core-10.0                  10.0.28-1                         amd64        MariaDB database core server files
    ii  master-pdf-editor3                        3.7.10                            amd64        Master PDF Editor is complete solution for view, print and edit PDF files.
    ii  mawk                                      1.3.3-17                          amd64        a pattern scanning and text processing language
    rc  maxthon-browser-stable                    1.0.5.3+1                         amd64        Maxthon Browser
    ii  mayavi2                                   4.5.0-1                           amd64        scientific visualization package for 2-D and 3-D data
    ii  mdadm                                     3.4-4                             amd64        tool to administer Linux MD arrays (software RAID)
    ii  mediainfo                                 0.7.88-1                          amd64        command-line utility for reading information from audio/video files
    ii  menu                                      2.1.47                            amd64        generates programs menu for all menu-aware applications
    ii  mercurial                                 4.0-1                             amd64        easy-to-use, scalable distributed version control system
    ii  mercurial-common                          4.0-1                             all          easy-to-use, scalable distributed version control system (common files)
    ii  mesa-common-dev:amd64                     12.0.3-3                          amd64        Developer documentation for Mesa
    ii  mesa-utils                                8.3.0-2+b1                        amd64        Miscellaneous Mesa GL utilities
    ii  mesa-vdpau-drivers:amd64                  12.0.3-3                          amd64        Mesa VDPAU video acceleration drivers
    ii  mesa-vdpau-drivers:i386                   12.0.3-3                          i386         Mesa VDPAU video acceleration drivers
    ii  metacity-common                           1:3.22.1-1                        all          shared files for the Metacity window manager
    ii  mime-support                              3.60                              all          MIME files 'mime.types' & 'mailcap', and support programs
    ii  mint-translations                         2015.11.28+deepin                 all          Translation files for Linux Mint
    ii  mintdrivers                               1.3.0-1                           all          Driver Manager
    ii  mobile-broadband-provider-info            20151214-0.1                      all          database of mobile broadband service providers
    ii  modemmanager                              1.6.2-1                           amd64        D-Bus service for managing modems
    ii  mount                                     2.28.2-1                          amd64        tools for mounting and manipulating filesystems
    ii  mpi-default-bin                           1.7                               amd64        Standard MPI runtime programs (metapackage)
    ii  mpich                                     3.2-7                             amd64        Implementation of the MPI Message Passing Interface standard
    ii  mtools                                    4.0.18-2                          amd64        Tools for manipulating MSDOS files
    ii  multiarch-support                         2.24-5                            amd64        Transitional package to ensure multiarch compatibility
    ii  mysql-common                              5.8+1.0.0                         all          MySQL database common files, e.g. /etc/mysql/my.cnf
    ii  nano                                      2.7.1-1                           amd64        small, friendly text editor inspired by Pico
    rc  nautilus                                  3.20.1-2                          amd64        file manager and graphical shell for GNOME
    ii  nautilus-data                             3.22.1-2                          all          data files for nautilus
    ii  nautilus-nutstore                         3.1.0                             amd64        Nutstore integration for Nautilus
    ii  nautilus-open-terminal                    0.20-51                           amd64        nautilus plugin for opening terminals in arbitrary paths
    ii  navicat                                   11.2.9                            amd64        <insert up to 60 chars description>
    ii  ncurses-base                              6.0+20160917-1                    all          basic terminal type definitions
    ii  ncurses-bin                               6.0+20160917-1                    amd64        terminal-related programs and man pages
    ii  ncurses-term                              6.0+20160917-1                    all          additional terminal type definitions
    ii  net-tools                                 1.60+git20150829.73cef8a-3        amd64        NET-3 networking toolkit
    ii  netbase                                   5.3                               all          Basic TCP/IP networking system
    ii  netease-cloud-music                       1.0.0-1                           amd64        netease cloud music player.
    ii  netpbm                                    2:10.0-15.3+b1                    amd64        Graphics conversion tools between image formats
    ii  netselect                                 0.3.ds1-28+deepin                 amd64        speed tester for choosing a fast network server
    ii  nettle-dev                                3.3-1                             amd64        low level cryptographic library (development files)
    ii  network-manager                           1.2.4-3                           amd64        network management framework (daemon and userspace tools)
    ii  network-manager-integration-plugins       0.0.3~1                           all          network-manager framework with plugin config.
    ii  network-manager-l2tp                      1.2.4-1                           amd64        network management framework (L2TP plugin core)
    ii  network-manager-l2tp-gnome                1.2.4-1                           amd64        network management framework (L2TP plugin GNOME GUI)
    ii  network-manager-openconnect               1.2.2-1                           amd64        network management framework (OpenConnect plugin core)
    ii  network-manager-openconnect-gnome         1.2.2-1                           amd64        network management framework (OpenConnect plugin GNOME GUI)
    ii  network-manager-openvpn                   1.2.4-1                           amd64        network management framework (OpenVPN plugin core)
    ii  network-manager-openvpn-gnome             1.2.4-1                           amd64        network management framework (OpenVPN plugin GNOME GUI)
    ii  network-manager-pptp                      1.2.2-1                           amd64        network management framework (PPTP plugin core)
    ii  network-manager-pptp-gnome                1.2.2-1                           amd64        network management framework (PPTP plugin GNOME GUI)
    ii  network-manager-strongswan                1.4.1-1                           amd64        network management framework (strongSwan plugin)
    ii  network-manager-vpnc                      1.2.2-1                           amd64        network management framework (VPNC plugin core)
    ii  network-manager-vpnc-gnome                1.2.2-1                           amd64        network management framework (VPNC plugin GNOME GUI)
    ii  nginx                                     1.10.2-1                          all          small, powerful, scalable web/proxy server
    ii  nginx-common                              1.10.2-1                          all          small, powerful, scalable web/proxy server - common files
    ii  nginx-full                                1.10.2-1                          amd64        nginx web/proxy server (standard version)
    ii  node-async                                0.8.0-1                           all          higher-order functions and common patterns for asynchronous Javascript
    ii  node-bowser                               0.7.3-2                           all          JavaScript browser detection library
    ii  node-combined-stream                      0.0.5-1                           all          Append streams one after another - module for Node.js
    ii  node-contextify                           0.1.6-1                           amd64        turn an object into a persistent execution context
    ii  node-cookie-jar                           0.3.1-1                           all          Cookie handling for HTTP clients - module for Node.js
    ii  node-cssom                                0.3.0-1                           all          CSS parser written in pure JavaScript - NodeJS module
    ii  node-cssstyle                             0.2.14-1                          all          CSSStyleDeclaration Object Model implementation
    ii  node-debug                                2.1.0+dfsg-2                      all          small debugging utility for Node.js
    ii  node-delayed-stream                       0.0.5-1                           all          Buffer stream events for later handling - module for Node.js
    ii  node-entities                             1.1.1-1                           all          Encode and decode XML/HTML entities with ease
    ii  node-events                               1.0.2-2                           all          Node EventEmitter
    ii  node-forever-agent                        0.5.1-1                           all          HTTP agent supporting keep-alive requests - module for Node.js
    ii  node-form-data                            0.1.0-1                           all          Create multipart/form-data streams module for Node.js
    ii  node-htmlparser2                          3.7.3-1                           all          fast & forgiving HTML/XML/RSS parser
    ii  node-inherits                             2.0.1-3                           all          Exposes inherits function from Node.js environment
    ii  node-is-typedarray                        1.0.0-2                           all          JavaScript library checking if object is TypedArray
    ii  node-jsdom                                0.8.10+dfsg1-2                    all          javascript implementation of the W3C DOM
    ii  node-jsesc                                2.2.0-1                           all          Escape JavaScript strings, with short output (Node.js module)
    ii  node-json-stringify-safe                  5.0.0-1                           all          JSON.stringify with circular references module for Node.js
    ii  node-jsonparse                            1.0.0-1                           all          Pure javascript JSON streaming parser for node.js
    ii  node-jssip                                0.6.34-5                          all          JavaScript implementation of a WebRTC SIP video phone
    ii  node-jsv                                  4.0.0+ds1-1                       all          extendable, fully compliant JSON schema validator for NodeJS
    ii  node-merge                                1.2.0-2                           all          JavaScript utility for merging multiple objects into one.
    ii  node-mime                                 1.3.4-1                           all          library for mime-type mapping for Node.js
    ii  node-nan                                  2.4.0-1                           all          Native Abstractions for Node.js
    ii  node-node-uuid                            1.4.0-1                           all          simple, fast generation of RFC4122 UUIDs - Node module
    ii  node-nwmatcher                            1.3.3+dfsg-2                      all          CSS3-compliant JavaScript selector engine
    ii  node-qs                                   2.2.4-1                           all          Parse, stringify query strings for Node.js
    ii  node-request                              2.26.1-1                          all          simplified HTTP request client module for Node.js
    ii  node-rtcninja                             0.6.2-2                           all          JavaScript parser/writer for Session Description Protocol
    ii  node-sdp-transform                        1.4.0-2                           all          JavaScript parser/writer for Session Description Protocol
    ii  node-tunnel-agent                         0.3.1-1                           all          HTTP proxy tunneling agent module for Node.js
    ii  node-typedarray-to-buffer                 3.0.3-3                           all          JavaScript utility converting TypedArray to buffer without copy
    ii  node-util                                 0.10.3-2                          all          NodeJS/JavaScript util module
    ii  node-websocket                            1.0.22-2                          amd64        WebSocket implementation for NodeJS
    ii  nodejs                                    6.3.1-1                           amd64        evented I/O for V8 javascript
    ii  nodejs-legacy                             6.3.1-1                           all          evented I/O for V8 javascript (legacy symlink)
    ii  notification-daemon                       3.20.0-1                          amd64        daemon for displaying passive pop-up notifications
    ii  npm                                       4.1.1-1                           all          package manager for Node.js
    ii  ntfs-3g                                   1:2016.2.22AR.1-3                 amd64        read/write NTFS driver for FUSE
    ii  nxproxy                                   3.5.0.32-1+b1                     amd64        NX proxy
    ii  ocl-icd-libopencl1:amd64                  2.2.9-2                           amd64        Generic OpenCL ICD Loader
    ii  odbcinst                                  2.3.1-5+b1                        amd64        Helper program for accessing odbc ini files
    ii  odbcinst1debian2:amd64                    2.3.1-5+b1                        amd64        Support library for accessing odbc ini files
    rc  openbsd-inetd                             0.20140418-2                      amd64        OpenBSD Internet Superserver
    ii  openconnect                               7.06-2+b2                         amd64        open client for Cisco AnyConnect VPN
    rc  openjdk-7-jre-headless:amd64              7u95-2.6.4-1                      amd64        OpenJDK Java runtime, using Hotspot JIT (headless)
    ii  openjdk-8-jdk:amd64                       8u111-b14-3                       amd64        OpenJDK Development Kit (JDK)
    ii  openjdk-8-jdk-headless:amd64              8u111-b14-3                       amd64        OpenJDK Development Kit (JDK) (headless)
    ii  openjdk-8-jre:amd64                       8u111-b14-3                       amd64        OpenJDK Java runtime, using Hotspot JIT
    ii  openjdk-8-jre-headless:amd64              8u111-b14-3                       amd64        OpenJDK Java runtime, using Hotspot JIT (headless)
    ii  openmpi-bin                               2.0.1-7                           amd64        high performance message passing library -- binaries
    ii  openmpi-common                            2.0.1-7                           all          high performance message passing library -- common files
    ii  openssh-client                            1:7.3p1-3+b1                      amd64        secure shell (SSH) client, for secure access to remote machines
    ii  openssh-server                            1:7.3p1-3+b1                      amd64        secure shell (SSH) server, for secure access from remote machines
    ii  openssh-sftp-server                       1:7.3p1-3+b1                      amd64        secure shell (SSH) sftp server module, for SFTP access from remote machines
    ii  openssl                                   1.1.0b-2                          amd64        Secure Sockets Layer toolkit - cryptographic utility
    rc  openswan                                  1:2.6.38-1                        amd64        Internet Key Exchange daemon
    ii  openvpn                                   2.3.11-2                          amd64        virtual private network daemon
    rc  opera-stable                              40.0.2308.62                      amd64        Fast and secure web browser
    ii  os-prober                                 1.71                              amd64        utility to detect other OSes on a set of drives
    ii  ostree                                    2016.12-2                         amd64        content-addressed filesystem for operating system binaries
    ii  oxideqt-codecs:amd64                      1.10.3-0ubuntu0.15.10.1           amd64        Web browser engine library for Qt (codecs)
    ii  p11-kit                                   0.23.2-5                          amd64        p11-glue utilities
    ii  p11-kit-modules:amd64                     0.23.2-5                          amd64        p11-glue proxy and trust modules
    ii  p11-kit-modules:i386                      0.23.2-5                          i386         p11-glue proxy and trust modules
    ii  p7zip                                     15.14.1+dfsg-2                    amd64        7zr file archiver with high compression ratio
    ii  p7zip-full                                15.14.1+dfsg-2                    amd64        7z and 7za file archivers with high compression ratio
    ii  pac                                       4.5.5.7                           all          PAC Perl Auto Connector
    ii  parted                                    3.2-16+b1                         amd64        disk partition manipulator
    ii  passwd                                    1:4.2-3.2                         amd64        change and administer password and group data
    ii  patch                                     2.7.5-1                           amd64        Apply a diff file to an original
    ii  patchutils                                0.3.4-2                           amd64        Utilities to work with patches
    ii  pciutils                                  1:3.3.1-1.1                       amd64        Linux PCI Utilities
    ii  pdfshuffler                               0.6.0-8                           all          merge, split and re-arrange pages from PDF documents
    ii  pep8                                      1.7.0-4                           all          Python PEP 8 code style checker - transitional package
    ii  perl                                      5.24.1~rc4-1                      amd64        Larry Wall's Practical Extraction and Report Language
    ii  perl-base                                 5.24.1~rc4-1                      amd64        minimal Perl system
    rc  perl-modules                              5.20.2-6                          all          Core Perl modules
    ii  perl-modules-5.24                         5.24.1~rc4-1                      all          Core Perl modules
    ii  phonon:amd64                              4:4.9.0-4                         amd64        multimedia framework from KDE using Qt 4 - metapackage
    ii  phonon-backend-gstreamer:amd64            4:4.9.0-1                         amd64        Phonon GStreamer 1.0 backend
    ii  phonon-backend-gstreamer-common:amd64     4:4.9.0-1                         amd64        Phonon GStreamer 1.0.x backend icons
    ii  phonon-backend-vlc:amd64                  0.9.0-2                           amd64        Phonon VLC backend
    ii  php5-cgi                                  5.6.26+dfsg-1                     amd64        server-side, HTML-embedded scripting language (CGI binary)
    ii  php5-cli                                  5.6.26+dfsg-1                     amd64        command-line interpreter for the php5 scripting language
    ii  php5-common                               5.6.26+dfsg-1                     amd64        Common files for packages built from the php5 source
    ii  php5-json                                 1.3.9-1                           amd64        JSON module for PHP 5
    ii  php5-mcrypt                               5.6.26+dfsg-1                     amd64        MCrypt module for php5
    ii  php5-readline                             5.6.26+dfsg-1                     amd64        Readline module for php5
    ii  pinentry-gnome3                           0.9.7-8                           amd64        GNOME 3 PIN or pass-phrase entry dialog for GnuPG
    ii  pkg-config                                0.29-4                            amd64        manage compile and link flags for libraries
    ii  plymouth                                  0.9.2-41                          amd64        boot animation, logger and I/O multiplexer
    ii  plymouth-theme-deepin-logo                15.04.2                           all          Plymouth theme for Linux Deepin
    ii  po-debconf                                1.0.20                            all          tool for managing templates file translations with gettext
    ii  pointdownload                             1.1.5-1                           amd64        efficient and easy to use to download for Http, P2P download
    ii  policykit-1                               0.105-17                          amd64        framework for managing administrative policies and privileges
    ii  policykit-1-gnome                         0.105-3                           amd64        GNOME authentication agent for PolicyKit-1
    ii  poppler-data                              0.4.7-7                           all          encoding data for the poppler PDF rendering library
    ii  poppler-utils                             0.48.0-2                          amd64        PDF utilities (based on Poppler)
    ii  ppp                                       2.4.7-1+2                         amd64        Point-to-Point Protocol (PPP) - daemon
    ii  pptp-linux                                1.8.0-1                           amd64        Point-to-Point Tunneling Protocol (PPTP) Client
    ii  prerex                                    6.5.3-1                           amd64        course prerequisite chart editor for LaTeX/TikZ
    ii  preview-latex-style                       11.88-1.2                         all          extraction of elements from LaTeX documents as graphics
    ii  procps                                    2:3.3.12-2                        amd64        /proc file system utilities
    ii  proj-bin                                  4.9.3-1                           amd64        Cartographic projection library (tools)
    ii  proj-data                                 4.9.3-1                           all          Cartographic projection filter and library (datum package)
    ii  prosper                                   1.00.4+cvs.2007.05.01-4.1         all          LaTeX class for writing transparencies
    ii  ps2eps                                    1.68+binaryfree-2                 amd64        convert PostScript to EPS (Encapsulated PostScript) files
    ii  psmisc                                    22.21-2.1+b1                      amd64        utilities that use the proc file system
    ii  publicsuffix                              20161028-1                        all          accurate, machine-readable list of domain name suffixes
    ii  pulseaudio                                8.0-2                             amd64        PulseAudio sound server
    ii  pulseaudio-module-bluetooth               8.0-2                             amd64        Bluetooth module for PulseAudio sound server
    ii  pulseaudio-module-x11                     8.0-2                             amd64        X11 module for PulseAudio sound server
    ii  pulseaudio-utils                          8.0-2                             amd64        Command line tools for the PulseAudio sound server
    ii  pycodestyle                               2.0.0-2                           all          Python style guide checker (formerly called pep8)
    ii  pyflakes                                  1.3.0-1                           all          passive checker of Python 2 and 3 programs
    ii  pyflakes3                                 1.3.0-1                           all          passive checker of Python 2 and 3 programs
    ii  pylint                                    1.5.6-1                           all          Python code static checker and UML diagram generator
    ii  pyside-tools                              0.2.15-1                          amd64        development tools for PySide (uic, rcc, lupdate)
    ii  python                                    2.7.11-2                          amd64        interactive high-level object-oriented language (default version)
    ii  python-alabaster                          0.7.8-1                           all          Configurable sidebar-enabled Sphinx theme (Python 2)
    ii  python-all                                2.7.11-2                          amd64        package depending on all supported Python runtime versions
    ii  python-all-dev                            2.7.11-2                          amd64        package depending on all supported Python development packages
    ii  python-antlr                              2.7.7+dfsg-7                      all          language tool for constructing recognizers, compilers etc
    ii  python-apptools                           4.3.0-1                           all          ETS Application Tools
    ii  python-apt                                1.1.0~beta5                       amd64        Python interface to libapt-pkg
    ii  python-apt-common                         1.1.0~beta5                       all          Python interface to libapt-pkg (locales)
    ii  python-ass                                0.4.2-2                           all          python2.7-ass Wrapper for Python-2.7
    ii  python-astroid                            1.4.8-1                           all          rebuild a new abstract syntax tree from Python's AST
    ii  python-attr                               16.2.0-1                          all          Attributes without boilerplate (Python 2)
    ii  python-autobahn                           0.14.1+dfsg1-2                    all          WebSocket client and server library, WAMP framework - Python 2.x
    ii  python-babel                              2.3.4+dfsg.1-2                    all          tools for internationalizing Python applications - Python 2.x
    ii  python-babel-localedata                   2.3.4+dfsg.1-2                    all          tools for internationalizing Python applications - locale data files
    ii  python-backports-abc                      0.4-2                             all          Backport of the "collections.abc" stdlib module (Python 2)
    ii  python-backports-shutil-get-terminal-size 1.0.0-3                           all          Backport of the "shutil.get_terminal_size" function (Python 2)
    ii  python-blinker                            1.3.dfsg2-1                       all          Fast, simple object-to-object and broadcast signaling library
    ii  python-bs4                                4.5.1-1                           all          error-tolerant HTML parser for Python
    ii  python-cairo                              1.8.8-2.1                         amd64        Python bindings for the Cairo vector graphics library
    ii  python-cbor                               0.1.24-1+b1                       amd64        Python Implementation of RFC 7049. Concise Binary Object Representation (CBOR).
    ii  python-cddb                               1.4-5.3                           amd64        Python interface to CD-IDs and FreeDB
    ii  python-cffi                               1.7.0-1                           all          Foreign Function Interface for Python calling C code
    ii  python-cffi-backend                       1.7.0-1                           amd64        Foreign Function Interface for Python calling C code - backend
    ii  python-chardet                            2.3.0-2                           all          universal character encoding detector for Python2
    ii  python-click                              6.6-1                             all          Simple wrapper around optparse for powerful command line utilities - Python 2.7
    ii  python-collada                            0.4-2                             all          Python module for creating, editing and loading COLLADA
    ii  python-colorama                           0.3.7-1                           all          Cross-platform colored terminal text in Python - Python 2.x
    ii  python-concurrent.futures                 3.0.5-3                           all          backport of concurrent.futures package from Python 3.2
    ii  python-configobj                          5.0.6-2                           all          simple but powerful config file reader and writer for Python 2
    ii  python-crypto                             2.6.1-6+b1                        amd64        cryptographic algorithms and protocols for Python
    ii  python-cryptography                       1.5.2-1                           amd64        Python library exposing cryptographic recipes and primitives (Python 2)
    ii  python-cssselect                          0.9.2-1                           all          cssselect parses CSS3 Selectors and translates them to XPath 1.0
    ii  python-cvxopt                             1.1.4-1.5                         amd64        Python package for convex optimization
    ii  python-cycler                             0.10.0-1                          all          composable kwarg iterator (Python 2)
    ii  python-dateutil                           2.5.3-2                           all          powerful extensions to the standard datetime module
    ii  python-dbus                               1.2.4-1                           amd64        simple interprocess messaging system (Python interface)
    ii  python-dbus-dev                           1.2.4-1                           all          main loop integration development files for python-dbus
    ii  python-decorator                          4.0.6-1                           all          simplify usage of Python decorators by programmers
    ii  python-deepin-gsettings                   0.3                               amd64        deepin gsettings python bindings
    ii  python-deepin-utils                       0.1.99-1                          amd64        Utils of DeepinUI Toolkit modules
    ii  python-dev                                2.7.11-2                          amd64        header files and a static library for Python (default)
    ii  python-dnspython                          1.15.0-1                          all          DNS toolkit for Python
    ii  python-docutils                           0.12+dfsg-2                       all          text processing system for reStructuredText (implemented in Python 2)
    ii  python-enum34                             1.1.6-1                           all          backport of Python 3.4's enum package
    ii  python-envisage                           4.4.0-1                           all          Extensible Application Framework
    ii  python-flask                              0.11.1-1                          all          micro web framework based on Werkzeug and Jinja2 - Python 2.7
    ii  python-funcsigs                           1.0.2-3                           all          function signatures from PEP362 - Python 2.7
    ii  python-functools32                        3.2.3.2-3                         all          Backport of the functools module from Python 3.2.3 to Python 2.7
    ii  python-geoip                              1.3.2-1+b2                        amd64        Python bindings for the GeoIP IP-to-country resolver library
    ii  python-gi                                 3.22.0-1                          amd64        Python 2.x bindings for gobject-introspection libraries
    ii  python-glade2                             2.24.0-6                          amd64        GTK+ bindings: Glade support
    ii  python-gobject                            3.22.0-1                          all          Python 2.x bindings for GObject - transitional package
    ii  python-gobject-2                          2.28.6-13                         amd64        deprecated static Python bindings for the GObject library
    ii  python-gst0.10                            0.10.22-3                         amd64        generic media-playing framework (Python bindings)
    ii  python-gtk2                               2.24.0-6                          amd64        Python bindings for the GTK+ widget set
    ii  python-h5py                               2.6.0-1+b1                        amd64        general-purpose Python interface to hdf5 (Python 2)
    ii  python-html5lib                           0.999-4                           all          HTML parser/tokenizer based on the WHATWG HTML5 specification (Python 2)
    ii  python-idna                               2.1-1                             all          Python IDNA2008 (RFC 5891) handling (Python 2)
    ii  python-imagesize                          0.7.1-1                           all          Python 2 module for getting image size from png/jpeg/jpeg2000/gif file
    ii  python-imaging                            3.4.2-1                           all          Python Imaging Library compatibility layer
    ii  python-ipaddress                          1.0.17-1                          all          Backport of Python 3 ipaddress module (Python 2)
    ii  python-ipykernel                          4.5.0-3                           all          IPython kernel for Jupyter (Python 2)
    ii  python-ipython                            5.1.0-2                           all          Enhanced interactive Python shell (Python 2 version)
    ii  python-ipython-genutils                   0.1.0-2                           all          IPython vestigial utilities for Python 2
    ii  python-itsdangerous                       0.24+dfsg1-2                      all          Various helpers to pass trusted data to untrusted environment - Python 2.x
    ii  python-javascriptcore                     0.0003-deepin2                    amd64        Javascript Core for Python
    ii  python-jdcal                              1.0-1                             all          Julian dates from proleptic Gregorian and Julian calendars
    ii  python-jedi                               0.9.0-1                           all          autocompletion tool for Python
    ii  python-jieba                              0.36-2                            all          Chinese Words Segementation Utilities - python2 version
    ii  python-jinja2                             2.8-1                             all          small but fast and easy to use stand-alone template engine
    ii  python-joblib                             0.10.2-1                          all          tools to provide lightweight pipelining in Python
    ii  python-jsonschema                         2.5.1-6                           all          An(other) implementation of JSON Schema (Draft 3 and 4) - Python 2.7
    ii  python-jupyter-client                     4.4.0-2                           all          Jupyter protocol client APIs (Python 2)
    ii  python-jupyter-core                       4.2.0-2                           all          Core common functionality of Jupyter projects for Python 2
    ii  python-jwt                                1.4.2-1                           all          Python implementation of JSON Web Token
    ii  python-keybinder                          0.3.1-1                           amd64        registers global key bindings for applications - Python bindings
    ii  python-lazy-object-proxy                  1.2.2-1                           amd64        Python fast and thorough lazy object proxy
    ii  python-ldb                                2:1.1.27-1                        amd64        Python bindings for LDB
    ii  python-libxml2                            2.9.4+dfsg1-2.1                   amd64        Python bindings for the GNOME XML library
    ii  python-lxml                               3.6.4-1                           amd64        pythonic binding for the libxml2 and libxslt libraries
    ii  python-lz4                                0.8.2+dfsg-2                      amd64        Python interface to the lz4 compression library
    ii  python-magic                              1:5.29-1                          all          Recognize the type of data in a file using "magic" numbers - Python bindings
    ii  python-markupsafe                         0.23-3                            amd64        HTML/XHTML/XML string library for Python
    ii  python-matplotlib                         1.5.3-1                           amd64        Python based plotting system in a style similar to Matlab
    ii  python-matplotlib-data                    1.5.3-1                           all          Python based plotting system (data package)
    ii  python-minimal                            2.7.11-2                          amd64        minimal subset of the Python language (default version)
    ii  python-mistune                            0.7.3-1                           all          Markdown parser for Python 2
    ii  python-mmkeys                             1.6.2.1-6                         amd64        Multimedia key support as a PyGTK object
    ii  python-mock                               2.0.0-3                           all          Mocking and Testing Library
    ii  python-mpi4py                             2.0.0-2+b1                        amd64        bindings of the Message Passing Interface (MPI) standard
    ii  python-msgpack                            0.4.8-1                           amd64        Python implementation of MessagePack format
    ii  python-mutagen                            1.34.1-1                          all          audio metadata editing library
    ii  python-nacl                               1.0.1-2                           amd64        Python bindings to libsodium (Python 2)
    ii  python-nbconvert                          4.2.0-2                           all          Jupyter notebook conversion (Python 2)
    ii  python-nbformat                           4.1.0-2                           all          Jupyter notebook format (Python 2)
    ii  python-nose                               1.3.7-2                           all          test discovery and running of Python's unittest
    ii  python-notify                             0.1.1-4                           amd64        Python bindings for libnotify
    ii  python-numexpr                            2.6.1-1                           amd64        Fast numerical array expression evaluator for Python and NumPy
    ii  python-numpy                              1:1.11.2-1                        amd64        Numerical Python adds a fast array facility to the Python language
    ii  python-oauthlib                           1.1.2-1                           all          generic, spec-compliant implementation of OAuth for Python
    ii  python-opengl                             3.1.0+dfsg-1                      all          Python bindings to OpenGL (Python 2)
    ii  python-openpyxl                           2.3.0-2                           all          module to read/write OpenXML xlsx/xlsm files
    ii  python-openssl                            16.1.0-1                          all          Python 2 wrapper around the OpenSSL library
    ii  python-pam                                0.4.2-13.2                        amd64        Python interface to the PAM library
    ii  python-pandas                             0.19.0+git14-ga40e185-1           all          data structures for "relational" or "labeled" data
    ii  python-pandas-lib                         0.19.0+git14-ga40e185-1           amd64        low-level implementations and bindings for pandas
    ii  python-pathlib2                           2.1.0-1                           all          Backport of the "pathlib" stdlib module (Python 2)
    ii  python-patsy                              0.4.1+git34-ga5b54c2-1            all          statistical models in Python using symbolic formulas
    ii  python-pbr                                1.10.0-1                          all          inject useful and sensible default behaviors into setuptools - Python 2.x
    ii  python-peewee                             2.8.0-1                           all          A small, expressive orm
    ii  python-pep8                               1.7.0-4                           all          Python PEP 8 code style checker - Python
    ii  python-pexpect                            4.2.0-1                           all          Python module for automating interactive applications
    ii  python-pickleshare                        0.7.4-1                           all          File system based database that uses Python pickles for Python 2
    ii  python-pil:amd64                          3.4.2-1                           amd64        Python Imaging Library (Pillow fork)
    ii  python-pip                                8.1.2-3                           all          Python package installer
    ii  python-pip-whl                            8.1.2-3                           all          Python package installer
    ii  python-pivy                               0.5.0~v609hg-3.1                  amd64        Coin binding for Python
    ii  python-pkg-resources                      28.7.1-1                          all          Package Discovery and Resource Access using pkg_resources
    ii  python-ply                                3.7-1                             all          Lex and Yacc implementation for Python2
    ii  python-poppler                            0.12.1-9                          amd64        Poppler Python bindings
    ii  python-prompt-toolkit                     1.0.8-1                           all          library for building interactive command lines (Python 2)
    ii  python-psutil                             4.3.1-1                           amd64        module providing convenience functions for managing processes
    ii  python-ptyprocess                         0.5.1-1                           all          Run a subprocess in a pseudo terminal from Python 2
    ii  python-py                                 1.4.31-2                          all          Advanced Python development support library (Python 2)
    ii  python-pyasn1                             0.1.9-2                           all          ASN.1 library for Python (Python 2 module)
    ii  python-pyasn1-modules                     0.0.7-0.1                         all          Collection of protocols modules written in ASN.1 language
    ii  python-pycparser                          2.14+dfsg-2                       all          C parser in Python
    ii  python-pycurl                             7.43.0-1                          amd64        Python bindings to libcurl
    ii  python-pyface                             4.5.2-1                           all          traits-capable windowing framework
    ii  python-pyflakes                           1.3.0-1                           all          passive checker of Python 2 programs
    ii  python-pygments                           2.1.3+dfsg-1                      all          syntax highlighting package written in Python
    ii  python-pyinotify                          0.9.6-1                           all          simple Linux inotify Python bindings
    ii  python-pyparsing                          2.1.10+dfsg1-1                    all          Python parsing module
    ii  python-pypdf                              1:1.13-3                          all          PDF toolkit implemented solely in Python
    ii  python-pyqt5                              5.6+dfsg-1+b1                     amd64        Python 2 bindings for Qt5
    ii  python-pyqt5.qtmultimedia                 5.6+dfsg-1+b1                     amd64        Python 2 bindings for Qt5's Multimedia module
    ii  python-pyqt5.qtquick                      5.6+dfsg-1+b1                     amd64        Python 2 bindings for QtQuick module
    ii  python-pyqt5.qtsvg                        5.6+dfsg-1+b1                     amd64        Python 2 bindings for Qt5's SVG module
    ii  python-pyqt5.qtwebkit                     5.6+dfsg-1+b1                     amd64        Python 2 bindings for Qt5's WebKit module
    ii  python-pyquery                            1.2.9-2                           all          jQuery-like library for python 2
    ii  python-pyside                             1.2.2-2                           all          Python bindings for Qt4 (big metapackage)
    ii  python-pyside.phonon                      1.2.2-2+b1                        amd64        Qt 4 Phonon module - Python bindings
    ii  python-pyside.qtcore                      1.2.2-2+b1                        amd64        Qt 4 core module - Python bindings
    ii  python-pyside.qtdeclarative               1.2.2-2+b1                        amd64        Qt 4 Declarative module - Python bindings
    ii  python-pyside.qtgui                       1.2.2-2+b1                        amd64        Qt 4 GUI module - Python bindings
    ii  python-pyside.qthelp                      1.2.2-2+b1                        amd64        Qt 4 help module - Python bindings
    ii  python-pyside.qtnetwork                   1.2.2-2+b1                        amd64        Qt 4 network module - Python bindings
    ii  python-pyside.qtopengl                    1.2.2-2+b1                        amd64        Qt 4 OpenGL module - Python bindings
    ii  python-pyside.qtscript                    1.2.2-2+b1                        amd64        Qt 4 script module - Python bindings
    ii  python-pyside.qtsql                       1.2.2-2+b1                        amd64        Qt 4 SQL module - Python bindings
    ii  python-pyside.qtsvg                       1.2.2-2+b1                        amd64        Qt 4 SVG module - Python bindings
    ii  python-pyside.qttest                      1.2.2-2+b1                        amd64        Qt 4 test module - Python bindings
    ii  python-pyside.qtuitools                   1.2.2-2+b1                        amd64        Qt 4 UI tools module - Python bindings
    ii  python-pyside.qtwebkit                    1.2.2-2+b1                        amd64        Qt 4 WebKit module - Python bindings
    ii  python-pyside.qtxml                       1.2.2-2+b1                        amd64        Qt 4 XML module - Python bindings
    ii  python-pysrt                              1.0.1-1                           all          library to edit or create SubRip files (Python 2)
    ii  python-pytest                             3.0.3-1                           all          Simple, powerful testing in Python
    ii  python-qrcode                             5.3-1                             all          QR Code image generator library - Python 2.7
    ii  python-qt4                                4.11.4+dfsg-2                     amd64        Python bindings for Qt4
    ii  python-qt4-gl                             4.11.4+dfsg-2                     amd64        Python bindings for Qt4's OpenGL module
    ii  python-qtawesome                          0.3.3-3                           all          iconic fonts in PyQt and PySide applications (Python 2)
    ii  python-qtawesome-common                   0.3.3-3                           all          common files for QtAwesome
    ii  python-qtconsole                          4.2.1-2                           all          Jupyter - Qt console (Python 2)
    ii  python-qtpy                               1.1.2-1                           all          abtraction layer for PySide/PyQt4/PyQt5 (Python 2)
    ii  python-requests                           2.11.1-1                          all          elegant and simple HTTP library for Python2, built for human beings
    ii  python-requests-oauthlib                  0.6.2-0.1                         all          module providing OAuthlib auth support for requests (Python 2)
    ii  python-roman                              2.0.0-2                           all          module for generating/analyzing Roman numerals for Python 2
    ii  python-rope                               0.10.2-1                          all          Python refactoring library
    ii  python-samba                              2:4.4.7+dfsg-1                    amd64        Python bindings for Samba
    ii  python-scipy                              0.18.1-2                          amd64        scientific tools for Python
    ii  python-serial                             3.2.1-1                           all          pyserial - module encapsulating access for the serial port
    ii  python-service-identity                   16.0.0-2                          all          Service identity verification for pyOpenSSL (Python 2 module)
    ii  python-setuptools                         28.7.1-1                          all          Python Distutils Enhancements
    ii  python-simplegeneric                      0.8.1-1                           all          simple generic functions for Python
    ii  python-simplejson                         3.10.0-1                          amd64        simple, fast, extensible JSON encoder/decoder for Python 2.x
    ii  python-singledispatch                     3.4.0.3-2                         all          single-dispatch generic functions for Python
    ii  python-sip                                4.18.1+dfsg-1                     amd64        Python/C++ bindings generator runtime library
    ii  python-six                                1.10.0-3                          all          Python 2 and 3 compatibility library (Python 2 interface)
    ii  python-snappy                             0.5-1.1                           amd64        snappy compression library from Google - Python 2.7
    ii  python-sphinx                             1.4.8-1                           all          documentation generator for Python projects (implemented in Python 2)
    ii  python-sphinx-rtd-theme                   0.1.9-1                           all          sphinx theme from readthedocs.org (Python 2)
    ii  python-spyder                             3.0.1+dfsg1-1                     all          Python IDE for scientists (Python 2 modules)
    ii  python-statsmodels                        0.8.0~rc1+git43-g1ac3f11-1        all          Python module for the estimation of statistical models
    ii  python-statsmodels-lib                    0.8.0~rc1+git43-g1ac3f11-1        amd64        low-level implementations and bindings for statsmodels
    ii  python-support                            1.0.15                            all          automated rebuilding support for Python modules
    ii  python-svn                                1.9.4-2                           amd64        A(nother) Python interface to Subversion
    ii  python-tables                             3.3.0-4                           all          hierarchical database for Python based on HDF5
    ii  python-tables-data                        3.3.0-4                           all          hierarchical database for Python based on HDF5 - test data
    ii  python-tables-lib                         3.3.0-4                           amd64        hierarchical database for Python based on HDF5 (extension)
    ii  python-talloc                             2.1.8-1                           amd64        hierarchical pool based memory allocator - Python bindings
    ii  python-tdb                                1.3.11-2                          amd64        Python bindings for TDB
    ii  python-tk                                 2.7.11-2                          amd64        Tkinter - Writing Tk applications with Python
    ii  python-tornado                            4.4.2-1                           amd64        scalable, non-blocking web server and tools
    ii  python-traitlets                          4.3.1-1                           all          Lightweight Traits-like package for Python 2
    ii  python-traits                             4.5.0-1+b2                        amd64        Manifest typing and reactive programming for Python (Python 2)
    ii  python-traitsui                           4.5.1-1                           all          traits-capable user interfaces
    ii  python-trollius                           2.1~b1-4                          all          port of the Tulip project on Python 2.7 - Python 2.x
    ii  python-twisted                            16.4.1-3                          all          Event-based framework for internet applications (dependency package)
    ii  python-twisted-bin:amd64                  16.4.1-3                          amd64        Event-based framework for internet applications
    ii  python-twisted-core                       16.4.1-3                          all          Event-based framework for internet applications
    ii  python-twisted-web                        16.4.1-3                          all          twisted dummy package for HTTP protocol implementation
    ii  python-txaio                              2.5.1+2016.10.03.git.623ef68776-1 all          compatibility API between asyncio/Twisted/Trollius - Python 2.x
    ii  python-tz                                 2015.7+dfsg-0.1                   all          Python version of the Olson timezone database
    ii  python-urllib3                            1.16-1                            all          HTTP library with thread-safe connection pooling for Python
    ii  python-vte                                1:0.28.2-7                        amd64        Python bindings for the VTE widget set
    ii  python-vtk6                               6.3.0+dfsg1-2                     amd64        Python bindings for VTK
    ii  python-wcwidth                            0.1.7+dfsg1-1                     all          determine printable width of a string on a terminal (Python 2)
    ii  python-webkit                             1.1.8-3.1                         amd64        WebKit/Gtk Python bindings
    ii  python-webob                              1.6.2-1                           all          Python module providing WSGI request and response objects (Python 2)
    ii  python-werkzeug                           0.11.11+dfsg1-1                   all          collection of utilities for WSGI applications (Python 2.x)
    ii  python-wheel                              0.29.0-1                          all          built-package format for Python
    ii  python-wnck                               2.32.0+dfsg-3                     amd64        Python bindings for the WNCK library
    ii  python-wrapt                              1.9.0-2                           amd64        decorators, wrappers and monkey patching. - Python 2.x
    ii  python-wxgtk3.0                           3.0.2.0+dfsg-3                    amd64        Python interface to the wxWidgets Cross-platform C++ GUI toolkit
    ii  python-wxversion                          3.0.2.0+dfsg-3                    all          API for selecting the wxPython version to use
    ii  python-xapian                             1.4.0-7                           amd64        Xapian search engine interface for Python
    ii  python-xappy                              0.5-5                             all          easy-to-use interface to the Xapian search engine
    ii  python-xlib                               0.15~rc                           all          Interfce for Python2 to the X11 protocol
    ii  python-xlrd                               1.0.0-1                           all          extract data from Microsoft Excel spreadsheet files
    ii  python-xlwt                               0.7.5+debian1-1                   all          module for writing Microsoft Excel spreadsheet files
    ii  python-xpyb                               1.3.1-1.1                         amd64        Python bindings to XCB
    ii  python-xpybutil                           0.0                               all          xcb-util for xpyb
    ii  python-zmq                                15.4.0-1                          amd64        Python bindings for 0MQ library
    ii  python-zope.interface                     4.3.2-1                           amd64        Interfaces for Python
    ii  python2.7                                 2.7.12-2                          amd64        Interactive high-level object-oriented language (version 2.7)
    ii  python2.7-dev                             2.7.12-2                          amd64        Header files and a static library for Python (v2.7)
    ii  python2.7-minimal                         2.7.12-2                          amd64        Minimal subset of the Python language (version 2.7)
    ii  python3                                   3.5.1-4                           amd64        interactive high-level object-oriented language (default python3 version)
    ii  python3-apt                               1.1.0~beta5                       amd64        Python 3 interface to libapt-pkg
    ii  python3-aptdaemon                         1.1.1+bzr982-1                    all          Python 3 modules for the server and client of aptdaemon
    ii  python3-aptdaemon.gtk3widgets             1.1.1+bzr982-1                    all          Python 3 GTK+ 3 widgets to run an aptdaemon client
    ii  python3-cairo                             1.10.0+dfsg-5+b1                  amd64        Python 3 bindings for the Cairo vector graphics library
    ii  python3-chardet                           2.3.0-2                           all          universal character encoding detector for Python3
    ii  python3-cups                              1.9.73-1                          amd64        Python3 bindings for CUPS
    ii  python3-cupshelpers                       1.5.7-2                           all          Python utility modules around the CUPS printing system
    ii  python3-dae                               1.0.0-1                           all          Deepin App Engine
    ii  python3-dbus                              1.2.4-1                           amd64        simple interprocess messaging system (Python 3 interface)
    ii  python3-debian                            0.1.29                            all          Python 3 modules to work with Debian-related data formats
    ii  python3-defer                             1.0.6-2                           all          Small framework for asynchronous programming (Python 3)
    ii  python3-gi                                3.22.0-1                          amd64        Python 3 bindings for gobject-introspection libraries
    ii  python3-gi-cairo                          3.22.0-1                          amd64        Python 3 Cairo bindings for the GObject library
    ii  python3-jieba                             0.36-2                            all          Chinese Words Segementation Utilities - python3 version
    ii  python3-lxml                              3.6.4-1                           amd64        pythonic binding for the libxml2 and libxslt libraries
    ii  python3-minimal                           3.5.1-4                           amd64        minimal subset of the Python language (default python3 version)
    ii  python3-notify2                           0.3-3                             all          desktop notifications API for Python 3
    ii  python3-pil:amd64                         3.4.2-1                           amd64        Python Imaging Library (Python3)
    ii  python3-pkg-resources                     28.7.1-1                          all          Package Discovery and Resource Access using pkg_resources
    ii  python3-pycodestyle                       2.0.0-2                           all          Python style guide checker (formerly called pep8) - Python 3.x
    ii  python3-pyflakes                          1.3.0-1                           all          passive checker of Python 3 programs
    ii  python3-pyqt5                             5.6+dfsg-1+b1                     amd64        Python 3 bindings for Qt5
    ii  python3-pyqt5.qtmultimedia                5.6+dfsg-1+b1                     amd64        Python 3 bindings for Qt5's Multimedia module
    ii  python3-pyqt5.qtquick                     5.6+dfsg-1+b1                     amd64        Python 3 bindings for QtQuick module
    ii  python3-pyqt5.qtwebkit                    5.6+dfsg-1+b1                     amd64        Python 3 bindings for Qt5's WebKit module
    ii  python3-pyuserinput                       0.0.1                             all          A module for cross-platform control of the mouse and keyboard
    ii  python3-requests                          2.11.1-1                          all          elegant and simple HTTP library for Python3, built for human beings
    ii  python3-sip                               4.18.1+dfsg-1                     amd64        Python 3/C++ bindings generator runtime library
    ii  python3-six                               1.10.0-3                          all          Python 2 and 3 compatibility library (Python 3 interface)
    ii  python3-smbc                              1.0.15.5-1+b1                     amd64        Python 3 bindings for the Samba client library
    ii  python3-tornado                           4.4.2-1                           amd64        scalable, non-blocking web server and tools - Python 3 package
    ii  python3-uno                               1:5.1.5~rc2-1                     amd64        Python-UNO bridge
    ii  python3-urllib3                           1.16-1                            all          HTTP library with thread-safe connection pooling for Python3
    ii  python3-xdg                               0.25-4                            all          Python 3 library to access freedesktop.org standards
    ii  python3-xkit                              0.5.0ubuntu2                      all          library for the manipulation of xorg.conf files (Python 3)
    ii  python3-xlib                              0.15~rc                           all          Interfce for Python3 to the X11 protocol
    ii  python3.4                                 3.4.4-3                           amd64        Interactive high-level object-oriented language (version 3.4)
    ii  python3.4-minimal                         3.4.4-3                           amd64        Minimal subset of the Python language (version 3.4)
    ii  python3.5                                 3.5.2-7                           amd64        Interactive high-level object-oriented language (version 3.5)
    ii  python3.5-minimal                         3.5.2-7                           amd64        Minimal subset of the Python language (version 3.5)
    ii  qbittorrent                               3.3.7-1                           amd64        bittorrent client based on libtorrent-rasterbar with a Qt5 GUI
    ii  qdbus                                     4:4.8.7+dfsg-10                   amd64        Qt 4 D-Bus tool
    ii  qemu-kvm                                  1:2.7+dfsg-3                      amd64        QEMU Full virtualization on x86 hardware
    ii  qemu-system-common                        1:2.7+dfsg-3                      amd64        QEMU full system emulation binaries (common files)
    ii  qemu-system-x86                           1:2.7+dfsg-3                      amd64        QEMU full system emulation binaries (x86)
    ii  qemu-utils                                1:2.7+dfsg-3                      amd64        QEMU utilities
    ii  qml-module-qt-labs-folderlistmodel:amd64  5.6.1-5                           amd64        Qt 5 folderlistmodel QML module
    ii  qml-module-qtav:amd64                     1:1.11.0-5                        amd64        QtAV QML module
    ii  qml-module-qtgraphicaleffects:amd64       5.6.1-3                           amd64        Qt 5 Graphical Effects module
    ii  qml-module-qtquick-controls:amd64         5.6.1-2                           amd64        Qt 5 Quick Controls QML module
    ii  qml-module-qtquick-controls-styles-breeze 4:5.8.2-1                         amd64        QtQuick style for Qt and KDE Software
    ii  qml-module-qtquick-dialogs:amd64          5.6.1-2                           amd64        Qt 5 Dialogs QML module
    ii  qml-module-qtquick-extras:amd64           5.6.1-2                           amd64        Qt 5 Quick Extras QML module
    ii  qml-module-qtquick-layouts:amd64          5.6.1-2                           amd64        Qt 5 Quick Layouts QML module
    ii  qml-module-qtquick-localstorage:amd64     5.6.1-5                           amd64        Qt 5 localstorage QML module
    ii  qml-module-qtquick-particles2:amd64       5.6.1-5                           amd64        Qt 5 particles 2 QML module
    ii  qml-module-qtquick-privatewidgets:amd64   5.6.1-2                           amd64        Qt 5 Private Widgets QML module
    ii  qml-module-qtquick-window2:amd64          5.6.1-5                           amd64        Qt 5 window 2 QML module
    ii  qml-module-qtquick-xmllistmodel:amd64     5.6.1-5                           amd64        Qt 5 xmllistmodel QML module
    ii  qml-module-qtquick2:amd64                 5.6.1-5                           amd64        Qt 5 Qt Quick 2 QML module
    ii  qml-module-qtwebkit:amd64                 5.6.1+dfsg-4+b2                   amd64        Qt WebKit QML module
    ii  qmlscene                                  5.6.1-5                           amd64        Qt 5 QML scene viewer
    ii  qt5-default                               5.6.1+dfsg-3+b1                   amd64        Qt 5 development defaults package
    ii  qt5-doc                                   5.6.1-1                           all          Qt 5 API Documentation
    ii  qt5-doc-html                              5.6.1-1                           all          Qt 5 API documentation (HTML format)
    ii  qt5-image-formats-plugins:amd64           5.6.1-2+b1                        amd64        Qt 5 Image Formats module
    ii  qt5-qmake:amd64                           5.6.1+dfsg-3+b1                   amd64        Qt 5 qmake Makefile generator tool
    ii  qt5-qmltooling-plugins:amd64              5.6.1-5                           amd64        Qt 5 qmltooling plugins
    ii  qt5-style-plugins:amd64                   5.0.0-1+b3                        amd64        Qt 5 extra widget styles
    ii  qt5gstreamer-dbg:amd64                    1.2.0-4                           amd64        Debug symbols for QtGStreamer - Qt 5 build
    ii  qt5keychain-dev:amd64                     0.7.0-3                           amd64        Development files for qtkeychain (QT5 version)
    ii  qtbase5-dev:amd64                         5.6.1+dfsg-3+b1                   amd64        Qt 5 base development files
    ii  qtbase5-dev-tools                         5.6.1+dfsg-3+b1                   amd64        Qt 5 base development programs
    ii  qtbase5-doc                               5.6.1+dfsg-3                      all          Qt 5 base documentation
    ii  qtbase5-doc-html                          5.6.1+dfsg-3                      all          Qt 5 base HTML documentation
    ii  qtchooser                                 58-gfab25f1-1                     amd64        Wrapper to select between Qt development binary versions
    ii  qtconnectivity5-doc                       5.6.1-2                           all          Qt 5 Sensors documentation
    ii  qtconnectivity5-doc-html                  5.6.1-2                           all          Qt 5 Sensors HTML documentation
    ii  qtcore4-l10n                              4:4.8.7+dfsg-10                   all          Qt 4 core module translations
    ii  qtcreator                                 4.0.3-1                           amd64        lightweight integrated development environment (IDE) for Qt
    ii  qtcreator-data                            4.0.3-1                           all          application data for Qt Creator IDE
    ii  qtcreator-doc                             4.0.3-1                           all          documentation for Qt Creator IDE
    ii  qtdeclarative5-dev:amd64                  5.6.1-5                           amd64        Qt 5 declarative development files
    ii  qtdeclarative5-dev-tools                  5.6.1-5                           amd64        Qt 5 declarative development programs
    ii  qtdeclarative5-doc                        5.6.1-5                           all          Qt 5 declarative documentation
    ii  qtdeclarative5-doc-html                   5.6.1-5                           all          Qt 5 declarative HTML documentation
    ii  qtgraphicaleffects5-doc                   5.6.1-3                           all          Qt 5 graphical effects documentation
    ii  qtgraphicaleffects5-doc-html              5.6.1-3                           all          Qt 5 graphicaleffects HTML documentation
    ii  qtgstreamer-plugins-qt5:amd64             1.2.0-4                           amd64        GStreamer plugins from QtGStreamer - Qt 5 build
    ii  qtlocation5-doc                           5.6.1-2                           all          Qt 5 Positioning documentation
    ii  qtlocation5-doc-html                      5.6.1-2                           all          Qt 5 Positioning HTML documentation
    ii  qtmultimedia5-dev:amd64                   5.6.1-2                           amd64        APIs for multimedia functionality - development files
    ii  qtmultimedia5-doc                         5.6.1-2                           all          Qt 5 multimedia documentation
    ii  qtmultimedia5-doc-html                    5.6.1-2                           all          Qt 5 multimedia HTML documentation
    ii  qtquickcontrols5-doc                      5.6.1-2                           all          Qt 5 Quick Controls documentation
    ii  qtquickcontrols5-doc-html                 5.6.1-2                           all          Qt 5 Quick Controls HTML documentation
    ii  qtscript5-doc                             5.6.1+dfsg-2                      all          Qt 5 script documentation
    ii  qtscript5-doc-html                        5.6.1+dfsg-2                      all          Qt 5 script HTML documentation
    ii  qtsensors5-doc                            5.6.1-2                           all          Qt 5 Sensors documentation
    ii  qtsensors5-doc-html                       5.6.1-2                           all          Qt 5 Sensors HTML documentation
    ii  qtserialport5-doc                         5.6.1-2                           all          Qt 5 serial port documentation
    ii  qtserialport5-doc-html                    5.6.1-2                           all          Qt 5 serial port HTML documentation
    ii  qtsvg5-doc                                5.6.1-2                           all          Qt 5 SVG documentation
    ii  qtsvg5-doc-html                           5.6.1-2                           all          Qt 5 SVG HTML documentation
    ii  qttools5-dev-tools                        5.6.1-2                           amd64        Qt 5 development tools
    ii  qttools5-doc                              5.6.1-2                           all          Qt 5 tools documentation
    ii  qttools5-doc-html                         5.6.1-2                           all          Qt 5 tools HTML documentation
    ii  qttranslations5-l10n                      5.6.1-2                           all          translations for Qt 5
    ii  qtwebkit5-doc                             5.6.1+dfsg-4                      all          Qt 5 webkit documentation
    ii  qtwebkit5-doc-html                        5.6.1+dfsg-4                      all          Qt 5 webkit HTML documentation
    ii  qtwebkit5-examples-doc                    5.6.1+dfsg-1                      all          Qt 5 webkit examples documentation
    ii  qtwebkit5-examples-doc-html               5.6.1+dfsg-1                      all          Qt 5 webkit examples HTML documentation
    ii  qtwebsockets5-doc                         5.6.1-2                           all          Qt 5 Web Sockets documentation
    ii  qtwebsockets5-doc-html                    5.6.1-2                           all          Qt 5 Web Sockets HTML documentation
    ii  qtx11extras5-doc                          5.6.1-2                           all          Qt 5 X11 extras documentation
    ii  qtx11extras5-doc-html                     5.6.1-2                           all          Qt 5 X11 extras HTML documentation
    ii  qtxmlpatterns5-dev-tools                  5.6.1-2                           amd64        Qt 5 XML patterns development programs
    ii  qtxmlpatterns5-doc                        5.6.1-2                           all          Qt 5 XML patterns documentation
    ii  qtxmlpatterns5-doc-html                   5.6.1-2                           all          Qt 5 XML patterns HTML documentation
    ii  rake                                      10.5.0-2                          all          ruby make-like utility
    ii  rdesktop                                  1.8.3-2                           amd64        RDP client for Windows NT/2000 Terminal Server and Windows Servers
    ii  readline-common                           7.0-1                             all          GNU readline and history libraries, common files
    ii  reiserfsprogs                             1:3.6.25-4                        amd64        User-level tools for ReiserFS filesystems
    ii  rfkill                                    0.5-1                             amd64        tool for enabling and disabling wireless devices
    ii  rsync                                     3.1.2-1                           amd64        fast, versatile, remote (and local) file-copying tool
    ii  rsyslog                                   8.22.0-2                          amd64        reliable system and kernel logging daemon
    ii  ruby                                      1:2.3.0+4                         amd64        Interpreter of object-oriented scripting language Ruby (default version)
    ii  ruby-did-you-mean                         1.0.0-2                           all          smart error messages for Ruby > 2.3
    ii  ruby-minitest                             5.9.0-1                           all          Ruby test tools supporting TDD, BDD, mocking, and benchmarking
    ii  ruby-net-telnet                           0.1.1-2                           all          telnet client library
    ii  ruby-power-assert                         0.3.0-1                           all          library showing values of variables and method calls in an expression
    ii  ruby-test-unit                            3.1.7-2                           all          unit testing framework for Ruby
    ii  ruby2.2                                   2.2.4-1                           amd64        Interpreter of object-oriented scripting language Ruby
    ii  ruby2.3                                   2.3.1-5+b1                        amd64        Interpreter of object-oriented scripting language Ruby
    ii  rubygems-integration                      1.10                              all          integration of Debian Ruby packages with Rubygems
    ii  runc                                      0.1.1+dfsg1-1                     amd64        Open Container Project - runtime
    ii  samba                                     2:4.4.7+dfsg-1                    amd64        SMB/CIFS file, print, and login server for Unix
    ii  samba-common                              2:4.4.7+dfsg-1                    all          common files used by both the Samba server and client
    ii  samba-common-bin                          2:4.4.7+dfsg-1                    amd64        Samba common files used by both the server and the client
    ii  samba-dsdb-modules                        2:4.4.7+dfsg-1                    amd64        Samba Directory Services Database
    ii  samba-libs:amd64                          2:4.4.7+dfsg-1                    amd64        Samba core libraries
    ii  samba-vfs-modules                         2:4.4.7+dfsg-1                    amd64        Samba Virtual FileSystem plugins
    ii  sane-utils                                1.0.25-2+b1                       amd64        API library for scanners -- utilities
    ii  screenfetch                               3.7.0-1                           all          Bash Screenshot Information Tool
    ii  scrot                                     0.8-17                            amd64        command line screen capture utility
    ii  seabios                                   1.9.3-2                           all          Legacy BIOS implementation
    ii  seafile                                   5.1.2                             amd64        Client of seafile, an online file storage and collaboration tool
    ii  seahorse                                  3.20.0-2                          amd64        GNOME front end for GnuPG
    ii  sed                                       4.2.2-8                           amd64        The GNU sed stream editor
    ii  sensible-utils                            0.0.9                             all          Utilities for sensible alternative selection
    ii  sgml-base                                 1.29                              all          SGML infrastructure and SGML catalog file support
    ii  shadowsocks-libqtshadowsocks              1.9.0-1                           amd64        A CLI shadowsocks client using libQtShadowsocks
    ii  shadowsocks-qt5                           2.7.0-1                           amd64        A cross-platform shadowsocks GUI client
    ii  shared-mime-info                          1.7-1                             amd64        FreeDesktop.org shared MIME database and spec
    ii  sharutils                                 1:4.15.2-1                        amd64        shar, unshar, uuencode, uudecode
    rc  skype-bin:i386                            4.3.0.37.2                        i386         client for Skype VOIP and instant messaging service - binary files
    ii  skypeforlinux                             1.17.0.1                          amd64        Skype keeps the world talking, for free.
    rc  sni-qt:i386                               0.2.7+15.10.20150729-2            i386         indicator support for Qt
    ii  socat                                     1.7.3.1-1                         amd64        multipurpose relay for bidirectional data transfer
    ii  sogoupinyin                               2.1.0.0084                        amd64        Sogou Pinyin Input Method
    ii  sphinx-common                             1.4.8-1                           all          documentation generator for Python projects - common data
    ii  sphinx-doc                                1.4.8-1                           all          documentation generator for Python projects - documentation
    ii  sphinx-rtd-theme-common                   0.1.9-1                           all          sphinx theme from readthedocs.org (common files)
    ii  spyder                                    3.0.1+dfsg1-1                     all          Python IDE for scientists (Python 2)
    ii  spyder-common                             3.0.1+dfsg1-1                     all          Python IDE for scientists (common files)
    ii  spyder-doc                                3.0.1+dfsg1-1                     all          Python IDE for scientists (Documentation)
    ii  squashfs-tools                            1:4.3-3                           amd64        Tool to create and append to squashfs filesystems
    ii  ssl-cert                                  1.0.38                            all          simple debconf wrapper for OpenSSL
    ii  startdde                                  3.0.13-4                          amd64        starter of deepin desktop environment
    ii  startpar                                  0.59-3.1                          amd64        run processes in parallel and multiplex their output
    rc  steam-launcher                            1.0.0.51                          all          Launcher for the Steam software distribution service
    ii  strongswan                                5.5.1-1                           all          IPsec VPN solution metapackage
    ii  strongswan-charon                         5.5.1-1                           amd64        strongSwan Internet Key Exchange daemon
    ii  strongswan-libcharon                      5.5.1-1                           amd64        strongSwan charon library
    ii  strongswan-nm                             5.5.1-1                           amd64        strongSwan plugin to interact with NetworkManager
    ii  strongswan-starter                        5.5.1-1                           amd64        strongSwan daemon starter and configuration file parser
    ii  sublime-text                              2.0.2-7                           amd64        sophisticated text editor for code, html and prose
    ii  sudo                                      1.8.17p1-2                        amd64        Provide limited super user privileges to specific users
    rc  sweethome3d                               4.5+dfsg-3                        all          Interior 2D design application with 3D preview
    ii  syslinux                                  3:6.03+dfsg-14                    amd64        collection of bootloaders (DOS FAT and NTFS bootloader)
    ii  syslinux-common                           3:6.03+dfsg-14                    all          collection of bootloaders (common)
    ii  system-config-printer                     1.5.7-2                           all          graphical interface to configure the printing system
    ii  system-config-printer-common              1.5.7-2                           all          backend and the translation files for system-config-printer
    ii  system-config-printer-udev                1.5.7-2                           amd64        Utilities to detect and configure printers automatically
    ii  systemd                                   231-1                             amd64        system and service manager
    ii  systemd-sysv                              231-1                             amd64        system and service manager - SysV links
    ii  sysv-rc                                   2.88dsf-59.8                      all          System-V-like runlevel change mechanism
    ii  sysvinit-utils                            2.88dsf-59.8                      amd64        System-V-like utilities
    ii  t1utils                                   1.39-2                            amd64        Collection of simple Type 1 font manipulation programs
    ii  tar                                       1.29b-1.1                         amd64        GNU version of the tar archiving utility
    ii  tasksel                                   3.37                              all          tool for selecting tasks for installation on Debian systems
    ii  tasksel-data                              3.37                              all          official tasks used for installation of Debian systems
    ii  tcl                                       8.6.0+9                           amd64        Tool Command Language (default version) - shell
    ii  tcl-expect:amd64                          5.45-7                            amd64        Automates interactive applications (Tcl package)
    ii  tcl8.6                                    8.6.6+dfsg-1                      amd64        Tcl (the Tool Command Language) v8.6 - shell
    ii  tcpd                                      7.6.q-25                          amd64        Wietse Venema's TCP wrapper utilities
    ii  tdb-tools                                 1.3.11-2                          amd64        Trivial Database - bundled binaries
    ii  teamviewer:i386                           11.0.53191                        i386         TeamViewer (Remote Control Application)
    ii  telnet                                    0.17-40+b1                        amd64        basic telnet client
    ii  tesseract-ocr                             3.04.01-2                         amd64        Tesseract command line OCR tool
    ii  tesseract-ocr-chi-sim                     3.04.00-1                         all          tesseract-ocr language files for Simplified Chinese
    ii  tesseract-ocr-chi-tra                     3.04.00-1                         all          tesseract-ocr language files for Traditional Chinese
    ii  tesseract-ocr-eng                         3.04.00-1                         all          tesseract-ocr language files for English
    ii  tesseract-ocr-equ                         3.04.00-1                         all          tesseract-ocr language files for equations
    ii  tesseract-ocr-osd                         3.04.00-1                         all          tesseract-ocr language files for script and orientation
    ii  tex-common                                6.05                              all          common infrastructure for building and installing TeX
    ii  tex-gyre                                  20160520-1                        all          scalable PostScript and OpenType fonts based on URW Fonts
    ii  texlive                                   2016.20161103-1                   all          TeX Live: A decent selection of the TeX Live packages
    ii  texlive-base                              2016.20161103-1                   all          TeX Live: Essential programs and files
    ii  texlive-binaries                          2016.20160513.41080-7+b1          amd64        Binaries for TeX Live
    ii  texlive-extra-utils                       2016.20161103-1                   all          TeX Live: TeX auxiliary programs
    ii  texlive-font-utils                        2016.20161103-1                   all          TeX Live: Graphics and font utilities
    ii  texlive-fonts-recommended                 2016.20161103-1                   all          TeX Live: Recommended fonts
    ii  texlive-fonts-recommended-doc             2016.20161103-1                   all          TeX Live: Documentation files for texlive-fonts-recommended
    ii  texlive-generic-extra                     2016.20161103-1                   all          TeX Live: Generic additional packages
    ii  texlive-generic-recommended               2016.20161103-1                   all          TeX Live: Generic recommended packages
    ii  texlive-latex-base                        2016.20161103-1                   all          TeX Live: LaTeX fundamental packages
    ii  texlive-latex-base-doc                    2016.20161103-1                   all          TeX Live: Documentation files for texlive-latex-base
    ii  texlive-latex-extra                       2016.20161103-1                   all          TeX Live: LaTeX additional packages
    ii  texlive-latex-extra-doc                   2016.20161103-1                   all          TeX Live: Documentation files for texlive-latex-extra
    ii  texlive-latex-recommended                 2016.20161103-1                   all          TeX Live: LaTeX recommended packages
    ii  texlive-latex-recommended-doc             2016.20161103-1                   all          TeX Live: Documentation files for texlive-latex-recommended
    ii  texlive-pictures                          2016.20161103-1                   all          TeX Live: Graphics, pictures, diagrams
    ii  texlive-pictures-doc                      2016.20161103-1                   all          TeX Live: Documentation files for texlive-pictures
    ii  texlive-pstricks                          2016.20161103-1                   all          TeX Live: PSTricks
    ii  texlive-pstricks-doc                      2016.20161103-1                   all          TeX Live: Documentation files for texlive-pstricks
    ii  thunderbird                               1:45.3.0+build1-0ubuntu6          amd64        Email, RSS and newsgroup client with integrated spam filter
    ii  tightvncserver                            1.3.9-8                           amd64        virtual network computing server software
    ii  tipa                                      2:1.3-20                          all          system for processing phonetic symbols in LaTeX
    ii  tk                                        8.6.0+9                           amd64        Toolkit for Tcl and X11 (default version) - windowing shell
    ii  tk8.6                                     8.6.6-1                           amd64        Tk toolkit for Tcl and X11 v8.6 - windowing shell
    ii  tk8.6-blt2.5                              2.5.3+dfsg-3                      amd64        graphics extension library for Tcl/Tk - library
    ii  tomcat8                                   8.5.9-2                           all          Apache Tomcat 8 - Servlet and JSP engine
    ii  tomcat8-common                            8.5.9-2                           all          Apache Tomcat 8 - Servlet and JSP engine -- common files
    ii  tree                                      1.7.0-4                           amd64        displays an indented directory tree, in color
    ii  ttf-bitstream-vera                        1.10-8                            all          The Bitstream Vera family of free TrueType fonts
    ii  ttf-wqy-microhei                          0.2.0-beta-2                      all          transitional dummy package
    ii  tzdata                                    2016i-1                           all          time zone and daylight-saving time data
    ii  tzdata-l10n                               2013i-5                           all          Internationalized files for tzdata
    ii  ubuntu-drivers-common                     3:0.4.22+deepin                   amd64        Detect and install additional Ubuntu driver packages
    ii  ucf                                       3.0036                            all          Update Configuration File(s): preserve user changes to config files
    ii  udev                                      231-1                             amd64        /dev/ and hotplug management daemon
    ii  udisks2                                   2.1.7-1.1                         amd64        D-Bus service to access and manipulate storage devices
    ii  uncrustify                                0.59+dfsg1-1.1+b1                 amd64        C, C++, C#, D, Java and Pawn source code beautifier
    ii  unionfs-fuse                              1.0-1                             amd64        Fuse implementation of unionfs
    ii  unixodbc                                  2.3.1-5+b1                        amd64        Basic ODBC tools
    ii  uno-libs3                                 5.1.5~rc2-1                       amd64        LibreOffice UNO runtime environment -- public shared libraries
    ii  unzip                                     6.0-30+i18n4                      amd64        De-archiver for .zip files
    ii  update-inetd                              4.43                              all          inetd configuration file updater
    ii  upower                                    0.99.4-4                          amd64        abstraction for power management
    ii  ure                                       5.1.5~rc2-1                       amd64        LibreOffice UNO runtime environment
    ii  usbmuxd                                   1.1.0-2+b1                        amd64        USB multiplexor daemon for iPhone and iPod Touch devices
    ii  usbutils                                  1:007-4                           amd64        Linux USB utilities
    ii  user-setup                                1.66                              all          Set up initial user and password
    ii  util-linux                                2.28.2-1                          amd64        miscellaneous system utilities
    ii  va-driver-all:i386                        1.7.3-2                           i386         Video Acceleration (VA) API -- driver metapackage
    ii  valac                                     0.34.2-1                          amd64        C# like language for the GObject system
    ii  valac-0.34-vapi                           0.34.2-1                          all          C# like language for the GObject system - vapi files
    ii  valgrind                                  1:3.12.0-1                        amd64        instrumentation framework for building dynamic analysis tools
    ii  valgrind-dbg                              1:3.12.0-1                        amd64        instrumentation framework for building dynamic analysis tools (debug)
    ii  vdpau-driver-all:amd64                    1.1.1-5                           amd64        Video Decode and Presentation API for Unix (driver metapackage)
    ii  vdpau-driver-all:i386                     1.1.1-5                           i386         Video Decode and Presentation API for Unix (driver metapackage)
    ii  vdpau-va-driver:i386                      0.7.4-6                           i386         VDPAU-based backend for VA API
    ii  vga-switcheroo                            2.2.1                             all          deepin vga_switcheroo
    ii  vim                                       2:8.0.0134-2deepin                amd64        Vi IMproved - enhanced vi editor
    ii  vim-common                                2:8.0.0134-2deepin                all          Vi IMproved - Common files
    ii  vim-runtime                               2:8.0.0134-2deepin                all          Vi IMproved - Runtime files
    ii  vim-tiny                                  2:8.0.0134-2deepin                amd64        Vi IMproved - enhanced vi editor - compact version
    ii  virtualbox                                5.1.10-dfsg-2                     amd64        x86 virtualization solution - base binaries
    ii  virtualbox-dkms                           5.1.10-dfsg-2                     all          x86 virtualization solution - kernel module sources for dkms
    ii  virtualbox-qt                             5.1.10-dfsg-2                     amd64        x86 virtualization solution - Qt based user interface
    ii  vlc                                       2.2.4-7                           amd64        multimedia player and streamer
    ii  vlc-bin                                   2.2.4-7                           amd64        binaries from VLC
    ii  vlc-data                                  2.2.4-7                           all          Common data for VLC
    ii  vlc-l10n                                  2.2.4-7                           all          Translations for VLC
    rc  vlc-nox                                   2.2.4-7                           amd64        transitional dummy package
    ii  vlc-plugin-base:amd64                     2.2.4-7                           amd64        multimedia player and streamer (base plugins)
    ii  vlc-plugin-notify:amd64                   2.2.4-7                           amd64        LibNotify plugin for VLC
    ii  vlc-plugin-qt:amd64                       2.2.4-7                           amd64        multimedia player and streamer (Qt plugin)
    ii  vlc-plugin-samba:amd64                    2.2.4-7                           amd64        Samba plugin for VLC
    ii  vlc-plugin-skins2:amd64                   2.2.4-7                           amd64        multimedia player and streamer (Skins2 plugin)
    ii  vlc-plugin-video-output:amd64             2.2.4-7                           amd64        multimedia player and streamer (video output plugins)
    ii  vlc-plugin-video-splitter:amd64           2.2.4-7                           amd64        multimedia player and streamer (video splitter plugins)
    ii  vlc-plugin-visualization:amd64            2.2.4-7                           amd64        multimedia player and streamer (visualization plugins)
    ii  vpnc                                      0.5.3r550-2+b1                    amd64        Cisco-compatible VPN client
    ii  vpnc-scripts                              0.1~git20150318-1                 all          Network configuration scripts for VPNC and OpenConnect
    ii  vprerex                                   6.5.3-1                           amd64        Qt interface to prerex, a course prerequisite chart editor
    ii  wayland-protocols                         1.7-1                             all          wayland compositor protocols
    ii  wget                                      1.18-4                            amd64        retrieves files from the web
    ii  whiptail                                  0.52.19-1                         amd64        Displays user-friendly dialog boxes from shell scripts
    ii  wireless-tools                            30~pre9-12                        amd64        Tools for manipulating Linux Wireless Extensions
    ii  wpasupplicant                             2.5-2+v2.4-3+b1                   amd64        client support for WPA and WPA2 (IEEE 802.11i)
    ii  wps-office                                10.1.0.5672~a21                   amd64        WPS Office, is an office productivity suite.
    ii  x11-apps                                  7.7+6                             amd64        X applications
    ii  x11-common                                1:7.7+18                          all          X Window System (X.Org) infrastructure
    ii  x11-session-utils                         7.7+2                             amd64        X session utilities
    ii  x11-utils                                 7.7+3                             amd64        X11 utilities
    ii  x11-xkb-utils                             7.7+3                             amd64        X11 XKB utilities
    ii  x11-xserver-utils                         7.7+7                             amd64        X server utilities
    ii  x11proto-composite-dev                    1:0.4.2-2                         all          X11 Composite extension wire protocol
    ii  x11proto-core-dev                         7.0.31-1                          all          X11 core wire protocol and auxiliary headers
    ii  x11proto-damage-dev                       1:1.2.1-2                         all          X11 Damage extension wire protocol
    ii  x11proto-dri2-dev                         2.8-2                             all          X11 DRI2 extension wire protocol
    ii  x11proto-fixes-dev                        1:5.0-2                           all          X11 Fixes extension wire protocol
    ii  x11proto-gl-dev                           1.4.17-1                          all          X11 OpenGL extension wire protocol
    ii  x11proto-input-dev                        2.3.2-1                           all          X11 Input extension wire protocol
    ii  x11proto-kb-dev                           1.0.7-1                           all          X11 XKB extension wire protocol
    ii  x11proto-randr-dev                        1.5.0-1                           all          X11 RandR extension wire protocol
    ii  x11proto-record-dev                       1.14.2-1                          all          X11 Record extension wire protocol
    ii  x11proto-render-dev                       2:0.11.1-2                        all          X11 Render extension wire protocol
    ii  x11proto-resource-dev                     1.2.0-3                           all          X11 Resource extension wire protocol
    ii  x11proto-xext-dev                         7.3.0-1                           all          X11 various extension wire protocol
    ii  x11proto-xf86vidmode-dev                  2.3.1-2                           all          X11 Video Mode extension wire protocol
    ii  x11proto-xinerama-dev                     1.2.1-2                           all          X11 Xinerama extension wire protocol
    ii  x2goclient                                4.0.5.2-1                         amd64        X2Go Client application (Qt4)
    ii  xauth                                     1:1.0.9-1                         amd64        X authentication utility
    ii  xbitmaps                                  1.1.1-2                           all          Base X bitmaps
    ii  xclip                                     0.12+svn84-4                      amd64        command line interface to X selections
    ii  xcur2png                                  0.7.1-2                           amd64        Take PNG images from Xcursor and generate xcursorgen config-file
    ii  xdelta3                                   3.0.11-dfsg-1                     amd64        Diff utility which works with binary files
    ii  xdg-user-dirs                             0.15-9~deepin                     amd64        tool to manage well known user directories
    ii  xdg-utils                                 1.1.1-9                           all          desktop integration utilities from freedesktop.org
    ii  xdotool                                   1:3.20160512.1-1                  amd64        simulate (generate) X11 keyboard/mouse input events
    ii  xfonts-100dpi                             1:1.0.4+nmu1                      all          100 dpi fonts for X
    ii  xfonts-75dpi                              1:1.0.4+nmu1                      all          75 dpi fonts for X
    ii  xfonts-base                               1:1.0.4+nmu1                      all          standard fonts for X
    ii  xfonts-encodings                          1:1.0.4-2                         all          Encodings for X.Org fonts
    ii  xfonts-scalable                           1:1.0.3-1.1                       all          scalable fonts for X
    ii  xfonts-utils                              1:7.7+3                           amd64        X Window System font utility programs
    ii  xfsprogs                                  4.3.0+nmu1                        amd64        Utilities for managing the XFS filesystem
    ii  xinit                                     1.3.4-3                           amd64        X server initialisation tool
    ii  xkb-data                                  2.18-1                            all          X Keyboard Extension (XKB) configuration data
    ii  xl2tpd                                    1.3.6+dfsg-4                      amd64        layer 2 tunneling protocol implementation
    ii  xml-core                                  0.16                              all          XML infrastructure and XML catalog file support
    ii  xorg                                      1:7.7+18                          amd64        X.Org X Window System
    ii  xorg-docs-core                            1:1.7.1-1                         all          Core documentation for the X.org X Window System
    ii  xorg-sgml-doctools                        1:1.11-1                          all          Common tools for building X.Org SGML documentation
    ii  xserver-common                            2:1.19.0-3                        all          common files used by various X servers
    ii  xserver-xorg                              1:7.7+18                          amd64        X.Org X server
    ii  xserver-xorg-core                         2:1.19.0-3                        amd64        Xorg X server - core server
    ii  xserver-xorg-input-all                    1:7.7+18                          amd64        X.Org X server -- input driver metapackage
    ii  xserver-xorg-input-evdev                  1:2.10.4-1+b1                     amd64        X.Org X server -- evdev input driver
    ii  xserver-xorg-input-libinput               0.23.0-2                          amd64        X.Org X server -- libinput input driver
    ii  xserver-xorg-input-mouse                  1:1.9.2-1+b1                      amd64        X.Org X server -- mouse input driver
    ii  xserver-xorg-input-synaptics              1.9.0-1+b1                        amd64        Synaptics TouchPad driver for X.Org server
    ii  xserver-xorg-input-wacom                  0.33.0-1+b1                       amd64        X.Org X server -- Wacom input driver
    ii  xserver-xorg-legacy                       2:1.19.0-3                        amd64        setuid root Xorg server wrapper
    ii  xserver-xorg-video-all                    1:7.7+18                          amd64        X.Org X server -- output driver metapackage
    ii  xserver-xorg-video-amdgpu                 1.2.0-1+b1                        amd64        X.Org X server -- AMDGPU display driver
    ii  xserver-xorg-video-ati                    1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI display driver wrapper
    ii  xserver-xorg-video-fbdev                  1:0.4.4-1+b5                      amd64        X.Org X server -- fbdev display driver
    ii  xserver-xorg-video-intel                  2:2.99.917+git20161206-1          amd64        X.Org X server -- Intel i8xx, i9xx display driver
    ii  xserver-xorg-video-nouveau                1:1.0.13-1+b1                     amd64        X.Org X server -- Nouveau display driver
    ii  xserver-xorg-video-radeon                 1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI Radeon display driver
    ii  xserver-xorg-video-vesa                   1:2.3.4-1+b2                      amd64        X.Org X server -- VESA display driver
    ii  xserver-xorg-video-vmware                 1:13.2.1-1+b1                     amd64        X.Org X server -- VMware display driver
    ii  xterm                                     327-1                             amd64        X terminal emulator
    ii  xtrans-dev                                1.3.5-1                           all          X transport library (development files)
    ii  xxd                                       2:8.0.0134-2deepin                amd64        tool to make (or reverse) a hex dump
    ii  xz-utils                                  5.2.2-1.2                         amd64        XZ-format compression utilities
    ii  yelp                                      3.22.0-1                          amd64        Help browser for GNOME
    ii  yelp-xsl                                  3.20.1-2                          all          XSL stylesheets for the yelp help browser
    ii  youdao-dict                               1.0.6                             amd64        Youdao Dict for Linux
    ii  zenity                                    3.22.0-1                          amd64        Display graphical dialog boxes from shell scripts
    ii  zenity-common                             3.22.0-1                          all          Display graphical dialog boxes from shell scripts (common files)
    ii  zip                                       3.0-11                            amd64        Archiver for .zip files
    ii  zlib1g:amd64                              1:1.2.8.dfsg-2+b3                 amd64        compression library - runtime
    ii  zlib1g:i386                               1:1.2.8.dfsg-2+b3                 i386         compression library - runtime
    ii  zlib1g-dev:amd64                          1:1.2.8.dfsg-2+b3                 amd64        compression library - development
    ii  zssh                                      1.5c.debian.1-3.2+b2              amd64        interactive file transfers over ssh
