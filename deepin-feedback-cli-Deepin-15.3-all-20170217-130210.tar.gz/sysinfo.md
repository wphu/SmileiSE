
# Linux Release

    No LSB modules are available.
    Distributor ID:	Deepin
    Description:	Deepin 15.3
    Release:	15.3
    Codename:	unstable

# Deepin Release

    [Release]
    Version=15.3
    Type=Desktop
    Type[zh_CN]=桌面版
    
    [Addition]
    Milestone=

# Linux Kernel

    Linux wp-pc 4.9.0-deepin2-amd64 #1 SMP Deepin 4.9.8-1 (2017-01-27) x86_64 GNU/Linux

# Installed Deepin Packages

    ii  dde-account-faces                         1.0.10-1                          all          Deepin Account face Images
    ii  dde-api                                   3.0.15-2                          amd64        Go-lang bingdings for dde-daemon
    ii  dde-calendar                              1.0.2-2                           amd64        <insert up to 60 chars description>
    ii  dde-control-center                        3.0.23-1                          amd64        New control center for linux deepin
    ii  dde-daemon                                3.0.24-5                          amd64        daemon handling the DDE session settings
    ii  dde-desktop                               3.0.15-3                          amd64        deepin desktop-environment - desktop module
    ii  dde-dock                                  4.0.5-1                           amd64        deepin desktop-environment - dock module
    ii  dde-file-manager                          1.3.8-1                           amd64        File manager front end of Deepin OS
    ii  dde-help                                  15.3.1-1                          all          Help files for dde
    ii  dde-help-common                           15.3.1-1                          all          common files .
    ii  dde-help-enus                             15.3.1-1                          all          English (en_US) Help files for dde
    ii  dde-help-zhcn                             15.3.1-1                          all          Chinese Simplified (zh_CN) Help files for dde
    ii  dde-launcher                              4.0.3-1                           amd64        deepin desktop-environment - launcher module
    ii  dde-qml-dbus-factory                      3.0.6-1                           amd64        Go-lang dbus gen QML for dlib
    ii  dde-qt5integration                        0.0.6-1                           amd64        Qt platform theme integration plugins for DDE
    ii  dde-session-ui                            3.0.22-1                          amd64        deepin desktop-environment - dde-session-ui module
    ii  deepin-appstore                           4.0.9-2                           amd64        Deepin App Store
    ii  deepin-appstore-data                      4.0.9-2                           all          deepin appstore data file.
    ii  deepin-archon                             1.0.1                             amd64        ARChon,run apk on linux.
    ii  deepin-artwork                            2015.3                            all          Deepin Artwork
    ii  deepin-artwork-themes                     15.12.3-1                         all          Deepin artwork themes
    ii  deepin-boot-maker                         1.1.3-1                           amd64        Deepin Boot Maker is help for user to create a boot usb stick quick and easy
    ii  deepin-crossover-helper:i386              1.0deepin0                        i386         Deepin CrossOver
    ii  deepin-crosswalk                          18.46.461.0-1                     amd64        Runtime for hosted and packaged apps
    rc  deepin-cursor-theme                       2014~4-2                          all          Deepin Cursor Icons
    ii  deepin-default-settings                   2016.8.25-1                       all          Deepin default settings
    ii  deepin-default-settings-tuning            2016.8.25-1                       all          Deepin default settings tuning
    ii  deepin-desktop-base                       2016.11.28-1                      all          Base files for Deepin Desktop
    ii  deepin-desktop-schemas                    3.0.12-1                          amd64        GSettings deepin desktop-wide schemas
    ii  deepin-download-service                   1.0.1-1                           amd64        deepin download service
    ii  deepin-feedback                           1.0.8-3                           amd64        report crash information to deepin for debugging
    ii  deepin-file-manager-backend               0.1.16-1                          amd64        deepin file manager backend
    ii  deepin-gettext-tools                      1.0.1-2                           amd64        Deepin Internationalization utilities
    ii  deepin-gtk-theme                          15.12.8-1                         all          Deepin Gtk Themes
    ii  deepin-icon-theme                         15.12.32-1                        all          Deepin Icons
    ii  deepin-image-viewer                       1.2.1-1                           amd64        Deepin Image Viewer is the Image Viewer for Deepin Desktop Environment(DDE)
    ii  deepin-kernel-update                      1.4                               all          help deepin user to update kernel
    ii  deepin-keyring                            2015.10.09                        all          GnuPG keys of the Deepin archive
    ii  deepin-manual                             1.0.5-1                           all          Deepin Manual
    ii  deepin-menu                               3.0.6-1                           amd64        Deepin menu service for building beautiful menus.
    ii  deepin-metacity                           3.20.6-1                          amd64        lightweight GTK+ window manager
    ii  deepin-metacity-common                    3.20.6-1                          all          shared files for the Metacity window manager
    ii  deepin-movie                              2.2.10-1                          all          deepin movie for linuxdeepin desktop environment
    ii  deepin-music                              3.0.1                             amd64        Awesome music player with brilliant and tweakful UI
    ii  deepin-mutter-common                      3.20.6-2                          all          shared files for the Mutter window manager
    ii  deepin-nautilus-properties                3.14.3-1                          amd64        Nautilus properties plugin for deepin desktop environment
    ii  deepin-notifications                      2.3.8-1                           amd64        system notifications for linuxdeepin desktop environment
    ii  deepin-qml-widgets                        2.3.4-1                           amd64        Deepin QML widgets
    ii  deepin-remote-assistance                  1.0.10-1                          amd64        Deepin Remote Assistance
    ii  deepin-screenshot                         3.1.10-1                          amd64        Advanced screen shoting tool
    ii  deepin-sleep                              2.2-1                             all          deepin sleep optimize setting.
    ii  deepin-social-sharing                     1.1.4-1                           all          System-wide social sharing service for Deepin!
    rc  deepin-software-center                    3.0.60-2                          all          Software center for linux deepin
    ii  deepin-software-center-data               3.0.50                            all          Software center data for linux deepin
    ii  deepin-sound-theme                        15.10.01                          all          deepin sound theme
    ii  deepin-terminal                           2.1.7-1                           amd64        Deepin terminal, it sharpens your focus in the world of command line!
    ii  deepin-ui                                 1.0.5-1                           all          LinuxDeepin UI libs
    ii  deepin-wallpapers                         1.3-2                             all          Default wallpapers for dde
    ii  deepin-wm                                 1.2-2                             amd64        Deepin Window Manager
    ii  deepin-wm-switcher                        1.1.0-1                           amd64        deepin window manager monitoring and auto-switching service
    ii  grub-themes-deepin                        1.0.0-1                           all          Deepin theme for grub2
    ii  lastore-daemon                            0.9.39-2                          amd64        daemon of lastore
    ii  libdde-file-manager:amd64                 1.3.8-1                           amd64        DDE File Manager library
    ii  libdeepin-metacity-private3               3.20.6-1                          amd64        library for the Metacity window manager
    ii  libdeepin-mutter0g                        3.20.6-2                          amd64        window manager library from the Mutter window manager
    ii  libdeepin-webkit-3.0-0                    1.2.2-2                           amd64        Web content engine library for GTK+
    ii  libdeepin-wm0:amd64                       1.2-2                             amd64        Library to build plugins for Deepin Window Manager
    ii  linux-compiler-gcc-5-x86-deepin           4.4.30-2                          amd64        Compiler for Linux on x86 (meta-package)
    ii  linux-headers-4.4.0-3-deepin-amd64        4.4.30-2                          amd64        Header files for Linux 4.4.0-3-deepin-amd64
    ii  linux-headers-4.4.0-3-deepin-common       4.4.30-2                          amd64        Common header files for Linux 4.4.0-3-deepin
    ii  linux-headers-4.9.0-deepin1-amd64         4.9-1                             amd64        Header files for Linux 4.9.0-deepin1-amd64
    ii  linux-headers-4.9.0-deepin1-common        4.9-1                             all          Common header files for Linux 4.9.0-deepin1
    ii  linux-headers-4.9.0-deepin2-amd64         4.9.8-1                           amd64        Header files for Linux 4.9.0-deepin2-amd64
    ii  linux-headers-4.9.0-deepin2-common        4.9.8-1                           all          Common header files for Linux 4.9.0-deepin2
    ii  linux-headers-deepin-amd64                4.9.8-1                           amd64        Header files for Linux amd64 configuration (meta-package)
    rc  linux-image-4.4.0-2-deepin-amd64          4.4.6-4                           amd64        Linux 4.4 for 64-bit PCs
    ii  linux-image-4.4.0-3-deepin-amd64          4.4.30-2                          amd64        Linux 4.4 for 64-bit PCs
    ii  linux-image-4.9.0-deepin1-amd64-unsigned  4.9-1                             amd64        Linux 4.9 for 64-bit PCs
    ii  linux-image-4.9.0-deepin2-amd64-unsigned  4.9.8-1                           amd64        Linux 4.9 for 64-bit PCs
    ii  linux-image-deepin-amd64                  4.9.8-1                           amd64        Linux for 64-bit PCs (meta-package)
    ii  plymouth-theme-deepin-logo                15.04.2                           all          Plymouth theme for Linux Deepin
    ii  python-deepin-gsettings                   0.3                               amd64        deepin gsettings python bindings
    ii  python-deepin-utils                       0.1.99-1                          amd64        Utils of DeepinUI Toolkit modules
    ii  python-javascriptcore                     0.0003-deepin2                    amd64        Javascript Core for Python

# Computer Model

    /sys/class/dmi/id/bios_date:	03/11/2010
    /sys/class/dmi/id/bios_vendor:	Dell Inc.
    /sys/class/dmi/id/bios_version:	A01
    /sys/class/dmi/id/board_asset_tag:	
    /sys/class/dmi/id/board_name:	0HN7XN
    /sys/class/dmi/id/board_serial:	..CN1374006S05VK.
    /sys/class/dmi/id/board_vendor:	Dell Inc.
    /sys/class/dmi/id/board_version:	A01
    /sys/class/dmi/id/chassis_asset_tag:	        
    /sys/class/dmi/id/chassis_serial:	FPRKX2X
    /sys/class/dmi/id/chassis_type:	6
    /sys/class/dmi/id/chassis_vendor:	Dell Inc.
    /sys/class/dmi/id/chassis_version:	
    /sys/class/dmi/id/modalias:	dmi:bvnDellInc.:bvrA01:bd03/11/2010:svnDellInc.:pnOptiPlex380:pvr:rvnDellInc.:rn0HN7XN:rvrA01:cvnDellInc.:ct6:cvr:
    /sys/class/dmi/id/product_name:	OptiPlex 380                 
    /sys/class/dmi/id/product_serial:	FPRKX2X
    /sys/class/dmi/id/product_uuid:	44454C4C-5000-1052-804B-C6C04F583258
    /sys/class/dmi/id/product_version:	
    /sys/class/dmi/id/sys_vendor:	Dell Inc.
    /sys/class/dmi/id/uevent:	MODALIAS=dmi:bvnDellInc.:bvrA01:bd03/11/2010:svnDellInc.:pnOptiPlex380:pvr:rvnDellInc.:rn0HN7XN:rvrA01:cvnDellInc.:ct6:cvr:

# Locale Specific Information

    LANG=zh_CN.UTF-8
    LANGUAGE=zh_CN
    LC_CTYPE="zh_CN.UTF-8"
    LC_NUMERIC="zh_CN.UTF-8"
    LC_TIME="zh_CN.UTF-8"
    LC_COLLATE="zh_CN.UTF-8"
    LC_MONETARY="zh_CN.UTF-8"
    LC_MESSAGES="zh_CN.UTF-8"
    LC_PAPER="zh_CN.UTF-8"
    LC_NAME="zh_CN.UTF-8"
    LC_ADDRESS="zh_CN.UTF-8"
    LC_TELEPHONE="zh_CN.UTF-8"
    LC_MEASUREMENT="zh_CN.UTF-8"
    LC_IDENTIFICATION="zh_CN.UTF-8"
    LC_ALL=

# Disk Partition Table

    NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
    sr0     11:0    1  1024M  0 rom  
    sda      8:0    0 465.8G  0 disk 
    ├─sda2   8:2    0    50G  0 part /
    ├─sda3   8:3    0    50G  0 part 
    └─sda1   8:1    0    50G  0 part /home

# Video Devices

    
    00:02.0 VGA compatible controller [0300]: Intel Corporation 4 Series Chipset Integrated Graphics Controller [8086:2e32] (rev 03) (prog-if 00 [VGA controller])
    	Subsystem: Dell 4 Series Chipset Integrated Graphics Controller [1028:0400]
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B+ ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin A routed to IRQ 26
    	Region 0: Memory at fe800000 (64-bit, non-prefetchable) [size=4M]
    	Region 2: Memory at d0000000 (64-bit, prefetchable) [size=256M]
    	Region 4: I/O ports at ecd8 [size=8]
    	[virtual] Expansion ROM at 000c0000 [disabled] [size=128K]
    	Capabilities: [90] MSI: Enable+ Count=1/1 Maskable- 64bit-
    		Address: fee0200c  Data: 4142
    	Capabilities: [d0] Power Management version 2
    		Flags: PMEClk- DSI+ D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot-,D3cold-)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Kernel driver in use: i915
    	Kernel modules: i915
    1 of 17 matched VGA 
    0 of 17 matched 3D controller

# Video Driver Packages

    ii  libdrm-amdgpu1:amd64                      2.4.71-1                          amd64        Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-amdgpu1:i386                       2.4.71-1                          i386         Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-dev:amd64                          2.4.71-1                          amd64        Userspace interface to kernel DRM services -- development files
    ii  libdrm-intel1:amd64                       2.4.71-1                          amd64        Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-intel1:i386                        2.4.71-1                          i386         Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:amd64                     2.4.71-1                          amd64        Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:i386                      2.4.71-1                          i386         Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:amd64                      2.4.71-1                          amd64        Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:i386                       2.4.71-1                          i386         Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm2:amd64                             2.4.71-1                          amd64        Userspace interface to kernel DRM services -- runtime
    ii  libdrm2:i386                              2.4.71-1                          i386         Userspace interface to kernel DRM services -- runtime
    ii  libegl1-mesa:amd64                        12.0.3-3                          amd64        free implementation of the EGL API -- runtime
    ii  libegl1-mesa-dev:amd64                    12.0.3-3                          amd64        free implementation of the EGL API -- development files
    ii  libgl1-mesa-dev:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX development files
    ii  libgl1-mesa-dri:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-dri:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-glx:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX runtime
    ii  libgl1-mesa-glx:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- GLX runtime
    ii  libglapi-mesa:amd64                       12.0.3-3                          amd64        free implementation of the GL API -- shared library
    ii  libglapi-mesa:i386                        12.0.3-3                          i386         free implementation of the GL API -- shared library
    ii  libgles1-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 1.x API -- runtime
    ii  libgles2-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 2.x API -- runtime
    ii  libglu1-mesa:amd64                        9.0.0-2.1                         amd64        Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa:i386                         9.0.0-2.1                         i386         Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa-dev:amd64                    9.0.0-2.1                         amd64        Mesa OpenGL utility library -- development files
    ii  libosmesa6:i386                           12.0.3-3                          i386         Mesa Off-screen rendering extension
    ii  libva-drm1:amd64                          1.7.3-2                           amd64        Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libva-drm1:i386                           1.7.3-2                           i386         Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libwayland-egl1-mesa:amd64                12.0.3-3                          amd64        implementation of the Wayland EGL platform -- runtime
    ii  mesa-common-dev:amd64                     12.0.3-3                          amd64        Developer documentation for Mesa
    ii  mesa-utils                                8.3.0-2+b1                        amd64        Miscellaneous Mesa GL utilities
    ii  mesa-vdpau-drivers:amd64                  12.0.3-3                          amd64        Mesa VDPAU video acceleration drivers
    ii  mesa-vdpau-drivers:i386                   12.0.3-3                          i386         Mesa VDPAU video acceleration drivers
    ii  xserver-xorg-video-all                    1:7.7+18                          amd64        X.Org X server -- output driver metapackage
    ii  xserver-xorg-video-amdgpu                 1.2.0-1+b1                        amd64        X.Org X server -- AMDGPU display driver
    ii  xserver-xorg-video-ati                    1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI display driver wrapper
    ii  xserver-xorg-video-fbdev                  1:0.4.4-1+b5                      amd64        X.Org X server -- fbdev display driver
    ii  xserver-xorg-video-intel                  2:2.99.917+git20161206-1          amd64        X.Org X server -- Intel i8xx, i9xx display driver
    ii  xserver-xorg-video-nouveau                1:1.0.13-1+b1                     amd64        X.Org X server -- Nouveau display driver
    ii  xserver-xorg-video-radeon                 1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI Radeon display driver
    ii  xserver-xorg-video-vesa                   1:2.3.4-1+b2                      amd64        X.Org X server -- VESA display driver
    ii  xserver-xorg-video-vmware                 1:13.2.1-1+b1                     amd64        X.Org X server -- VMware display driver

# Xrandr Infromation

    Screen 0: minimum 320 x 200, current 1440 x 900, maximum 8192 x 8192
    VGA-1 connected primary 1440x900+0+0 (0x43) normal (normal left inverted right x axis y axis) 408mm x 255mm
    	Identifier: 0x41
    	Timestamp:  58938
    	Subpixel:   unknown
    	Gamma:      1.0:1.0:1.0
    	Brightness: 1.0
    	Clones:    
    	CRTC:       0
    	CRTCs:      0 1
    	Transform:  1.000000 0.000000 0.000000
    	            0.000000 1.000000 0.000000
    	            0.000000 0.000000 1.000000
    	           filter: 
    	EDID: 
    		00ffffffffffff0010ac05f0554d5730
    		2312010368291a78eec125a3564b9927
    		115054bfef809500714f8180950f0101
    		0101010101019a29a0d0518422305098
    		360098ff1000001c000000fd00384b1e
    		530e000a202020202020000000ff0047
    		3432354838385430574d550a000000fc
    		0044454c4c20453139385746500a00d4
      1440x900 (0x43) 106.500MHz -HSync +VSync *current +preferred
            h: width  1440 start 1520 end 1672 total 1904 skew    0 clock  55.93KHz
            v: height  900 start  903 end  909 total  934           clock  59.89Hz
      1280x1024 (0x44) 135.000MHz +HSync +VSync
            h: width  1280 start 1296 end 1440 total 1688 skew    0 clock  79.98KHz
            v: height 1024 start 1025 end 1028 total 1066           clock  75.02Hz
      1280x1024 (0x45) 108.000MHz +HSync +VSync
            h: width  1280 start 1328 end 1440 total 1688 skew    0 clock  63.98KHz
            v: height 1024 start 1025 end 1028 total 1066           clock  60.02Hz
      1440x900 (0x46) 136.750MHz -HSync +VSync
            h: width  1440 start 1536 end 1688 total 1936 skew    0 clock  70.64KHz
            v: height  900 start  903 end  909 total  942           clock  74.98Hz
      1152x864 (0x47) 108.000MHz +HSync +VSync
            h: width  1152 start 1216 end 1344 total 1600 skew    0 clock  67.50KHz
            v: height  864 start  865 end  868 total  900           clock  75.00Hz
      1024x768 (0x48) 78.750MHz +HSync +VSync
            h: width  1024 start 1040 end 1136 total 1312 skew    0 clock  60.02KHz
            v: height  768 start  769 end  772 total  800           clock  75.03Hz
      1024x768 (0x49) 75.000MHz -HSync -VSync
            h: width  1024 start 1048 end 1184 total 1328 skew    0 clock  56.48KHz
            v: height  768 start  771 end  777 total  806           clock  70.07Hz
      1024x768 (0x4a) 65.000MHz -HSync -VSync
            h: width  1024 start 1048 end 1184 total 1344 skew    0 clock  48.36KHz
            v: height  768 start  771 end  777 total  806           clock  60.00Hz
      832x624 (0x4b) 57.284MHz -HSync -VSync
            h: width   832 start  864 end  928 total 1152 skew    0 clock  49.73KHz
            v: height  624 start  625 end  628 total  667           clock  74.55Hz
      800x600 (0x4c) 50.000MHz +HSync +VSync
            h: width   800 start  856 end  976 total 1040 skew    0 clock  48.08KHz
            v: height  600 start  637 end  643 total  666           clock  72.19Hz
      800x600 (0x4d) 49.500MHz +HSync +VSync
            h: width   800 start  816 end  896 total 1056 skew    0 clock  46.88KHz
            v: height  600 start  601 end  604 total  625           clock  75.00Hz
      800x600 (0x4e) 40.000MHz +HSync +VSync
            h: width   800 start  840 end  968 total 1056 skew    0 clock  37.88KHz
            v: height  600 start  601 end  605 total  628           clock  60.32Hz
      800x600 (0x4f) 36.000MHz +HSync +VSync
            h: width   800 start  824 end  896 total 1024 skew    0 clock  35.16KHz
            v: height  600 start  601 end  603 total  625           clock  56.25Hz
      640x480 (0x50) 31.500MHz -HSync -VSync
            h: width   640 start  656 end  720 total  840 skew    0 clock  37.50KHz
            v: height  480 start  481 end  484 total  500           clock  75.00Hz
      640x480 (0x51) 31.500MHz -HSync -VSync
            h: width   640 start  664 end  704 total  832 skew    0 clock  37.86KHz
            v: height  480 start  489 end  492 total  520           clock  72.81Hz
      640x480 (0x52) 30.240MHz -HSync -VSync
            h: width   640 start  704 end  768 total  864 skew    0 clock  35.00KHz
            v: height  480 start  483 end  486 total  525           clock  66.67Hz
      640x480 (0x53) 25.175MHz -HSync -VSync
            h: width   640 start  656 end  752 total  800 skew    0 clock  31.47KHz
            v: height  480 start  490 end  492 total  525           clock  59.94Hz
      720x400 (0x54) 28.320MHz -HSync +VSync
            h: width   720 start  738 end  846 total  900 skew    0 clock  31.47KHz
            v: height  400 start  412 end  414 total  449           clock  70.08Hz

# Bluetooth Devices


    0 of 17 matched [bB]luetooth


# Loaded Bluetooth Drivers

    bluetooth             557056  0
    rfkill                 24576  2 bluetooth
    crc16                  16384  2 bluetooth,ext4

# Network Devices

    
    02:00.0 Ethernet controller [0200]: Broadcom Corporation NetLink BCM57780 Gigabit Ethernet PCIe [14e4:1692] (rev 01)
    	Subsystem: Dell NetLink BCM57780 Gigabit Ethernet PCIe [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 28
    	Region 0: Memory at fe4f0000 (64-bit, non-prefetchable) [size=64K]
    	Capabilities: [48] Power Management version 3
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst+ PME-Enable- DSel=0 DScale=1 PME-
    	Capabilities: [60] Vendor Specific Information: Len=6c <?>
    	Capabilities: [50] MSI: Enable+ Count=1/1 Maskable- 64bit+
    		Address: 00000000fee0200c  Data: 4182
    	Capabilities: [cc] Express (v2) Endpoint, MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0, Latency L0s <4us, L1 unlimited
    			ExtTag+ AttnBtn- AttnInd- PwrInd- RBE+ FLReset-
    		DevCtl:	Report errors: Correctable- Non-Fatal+ Fatal+ Unsupported-
    			RlxdOrd- ExtTag+ PhantFunc- AuxPwr- NoSnoop-
    			MaxPayload 128 bytes, MaxReadReq 512 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr+ TransPend-
    		LnkCap:	Port #0, Speed 2.5GT/s, Width x1, ASPM L0s L1, Exit Latency L0s <1us, L1 <32us
    			ClockPM+ Surprise- LLActRep- BwNot- ASPMOptComp-
    		LnkCtl:	ASPM Disabled; RCB 64 bytes Disabled- CommClk+
    			ExtSynch- ClockPM- AutWidDis- BWInt- AutBWInt-
    		LnkSta:	Speed 2.5GT/s, Width x1, TrErr- Train- SlotClk+ DLActive- BWMgmt- ABWMgmt-
    		DevCap2: Completion Timeout: Range ABCD, TimeoutDis+, LTR-, OBFF Not Supported
    		DevCtl2: Completion Timeout: 50us to 50ms, TimeoutDis-, LTR-, OBFF Disabled
    		LnkCtl2: Target Link Speed: 2.5GT/s, EnterCompliance- SpeedDis-
    			 Transmit Margin: Normal Operating Range, EnterModifiedCompliance- ComplianceSOS-
    			 Compliance De-emphasis: -6dB
    		LnkSta2: Current De-emphasis Level: -6dB, EqualizationComplete-, EqualizationPhase1-
    			 EqualizationPhase2-, EqualizationPhase3-, LinkEqualizationRequest-
    	Capabilities: [100 v1] Advanced Error Reporting
    		UESta:	DLP- SDES- TLP- FCP- CmpltTO- CmpltAbrt- UnxCmplt- RxOF- MalfTLP- ECRC- UnsupReq- ACSViol-
    		UEMsk:	DLP- SDES- TLP- FCP- CmpltTO- CmpltAbrt- UnxCmplt- RxOF- MalfTLP- ECRC- UnsupReq- ACSViol-
    		UESvrt:	DLP+ SDES+ TLP- FCP+ CmpltTO- CmpltAbrt- UnxCmplt- RxOF+ MalfTLP+ ECRC- UnsupReq- ACSViol-
    		CESta:	RxErr- BadTLP- BadDLLP- Rollover- Timeout- NonFatalErr-
    		CEMsk:	RxErr- BadTLP- BadDLLP- Rollover- Timeout- NonFatalErr+
    		AERCap:	First Error Pointer: 00, GenCap+ CGenEn- ChkCap+ ChkEn-
    	Capabilities: [13c v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed- WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending- InProgress-
    	Capabilities: [160 v1] Device Serial Number b8-ac-6f-ff-fe-44-bc-74
    	Capabilities: [16c v1] Power Budgeting <?>
    	Kernel driver in use: tg3
    	Kernel modules: tg3
    1 of 17 matched [nN]etwork|[eE]thernet
    0 of 7 matched [nN]et|[eE]thernet

# Network Status

    docker0: flags=4099<UP,BROADCAST,MULTICAST>  mtu 1500
            inet 172.17.0.1  netmask 255.255.0.0  broadcast 0.0.0.0
            ether 02:42:d7:fe:db:12  txqueuelen 0  (Ethernet)
            RX packets 0  bytes 0 (0.0 B)
            RX errors 0  dropped 0  overruns 0  frame 0
            TX packets 0  bytes 0 (0.0 B)
            TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
    
    enp2s0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
            inet 192.168.1.117  netmask 255.255.255.0  broadcast 192.168.1.255
            inet6 fe80::baac:6fff:fe44:bc74  prefixlen 64  scopeid 0x20<link>
            ether b8:ac:6f:44:bc:74  txqueuelen 1000  (Ethernet)
            RX packets 2023577  bytes 1654113117 (1.5 GiB)
            RX errors 0  dropped 0  overruns 0  frame 0
            TX packets 1095451  bytes 227216665 (216.6 MiB)
            TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
            device interrupt 16  
    
    lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
            inet 127.0.0.1  netmask 255.0.0.0
            inet6 ::1  prefixlen 128  scopeid 0x10<host>
            loop  txqueuelen 1  (Local Loopback)
            RX packets 182451  bytes 17135072 (16.3 MiB)
            RX errors 0  dropped 0  overruns 0  frame 0
            TX packets 182451  bytes 17135072 (16.3 MiB)
            TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
    lo        no wireless extensions.
    
    enp2s0    no wireless extensions.
    
    docker0   no wireless extensions.

# NetworkManager Configuration

    [main]
    plugins=ifupdown,keyfile
    
    [ifupdown]
    managed=true

# NetworkManager State

    nmcli 工具，版本 1.2.4
    状态    连接  WIFI-HW  WIFI    WWAN-HW  WWAN   
    连接的  完全  已启用   已启用  已启用   已启用 

# NetworkManager Hotname

    wp-pc

# NetworkManager Permissions

    权限                                                       值   
    org.freedesktop.NetworkManager.enable-disable-network      是   
    org.freedesktop.NetworkManager.enable-disable-wifi         是   
    org.freedesktop.NetworkManager.enable-disable-wwan         是   
    org.freedesktop.NetworkManager.enable-disable-wimax        是   
    org.freedesktop.NetworkManager.sleep-wake                  是   
    org.freedesktop.NetworkManager.network-control             是   
    org.freedesktop.NetworkManager.wifi.share.protected        是   
    org.freedesktop.NetworkManager.wifi.share.open             是   
    org.freedesktop.NetworkManager.settings.modify.system      是   
    org.freedesktop.NetworkManager.settings.modify.own         是   
    org.freedesktop.NetworkManager.settings.modify.hostname    是   
    org.freedesktop.NetworkManager.settings.modify.global-dns  未知 
    org.freedesktop.NetworkManager.reload                      是   

# NetworkManager Logging

    级别  域                                                                                                                                                                                                                      
    INFO  PLATFORM,RFKILL,ETHER,WIFI,BT,MB,DHCP4,DHCP6,PPP,IP4,IP6,AUTOIP4,DNS,VPN,SHARING,SUPPLICANT,AGENTS,SETTINGS,SUSPEND,CORE,DEVICE,OLPC,INFINIBAND,FIREWALL,ADSL,BOND,VLAN,BRIDGE,TEAM,CONCHECK,DCB,DISPATCH,AUDIT,SYSTEMD 

# NetworkManager Connections

    名称       UUID                                  类型            设备    
    docker0    68adf141-5d15-4d3f-b4c5-047d8b65d433  bridge          docker0 
    有线连接   2c8bcdcf-ca6e-23cd-4226-61c985f763e6  802-3-ethernet  enp2s0  
    VPN连接 1  0bdc24b6-11f9-4195-ad92-a006c72ef7d6  vpn             --      
    有线连接   716414e8-9fc5-fbec-d8d9-d95376eb73f5  802-3-ethernet  --      
    有线连接   4a70a6ec-baf4-f966-e9f3-1b84bb1cfcc0  802-3-ethernet  --      
    有线连接   2288c149-695d-230c-d421-27461388b2b9  802-3-ethernet  --      
    有线连接   b4cd939a-8f0e-cc79-87c7-b0b8f1172b1c  802-3-ethernet  --      
    有线连接   d53a12b9-3d6b-d363-2dfb-8aafd5ce10dd  802-3-ethernet  --      
    有线连接   16afb18a-74b2-cb5e-9bab-43fe08956f5b  802-3-ethernet  --      
    有线连接   1d830e4f-eef9-be40-41db-585ee03b3fca  802-3-ethernet  --      
    有线连接   96a9fc6d-fcc5-5c2d-7b96-0a33ef463804  802-3-ethernet  --      

# NetworkManager Devices

    设备     类型      状态    连接     
    docker0  bridge    连接的  docker0  
    enp2s0   ethernet  连接的  有线连接 
    lo       loopback  未托管  --       

# NetworkManager Wireless Access Points



# ModemManager State

    
    No modems were found

# Wireless Device Switches(rfkill)



# Network Interface File

    # interfaces(5) file used by ifup(8) and ifdown(8)
    # Include files from /etc/network/interfaces.d:
    source-directory /etc/network/interfaces.d

# DNS Configuration(resolv.conf)

    # Generated by NetworkManager
    nameserver 192.168.1.1
    nameserver 202.118.66.6

# Route Table

    Kernel IP routing table
    Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
    default         192.168.1.1     0.0.0.0         UG    100    0        0 enp2s0
    172.17.0.0      0.0.0.0         255.255.0.0     U     0      0        0 docker0
    192.168.1.0     0.0.0.0         255.255.255.0   U     100    0        0 enp2s0

# Audio Devices

    
    00:1b.0 Audio device [0403]: Intel Corporation NM10/ICH7 Family High Definition Audio Controller [8086:27d8] (rev 01)
    	Subsystem: Dell NM10/ICH7 Family High Definition Audio Controller [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 27
    	Region 0: Memory at fe6fc000 (64-bit, non-prefetchable) [size=16K]
    	Capabilities: [50] Power Management version 2
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=55mA PME(D0+,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Capabilities: [60] MSI: Enable+ Count=1/1 Maskable- 64bit+
    		Address: 00000000fee0200c  Data: 4172
    	Capabilities: [70] Express (v1) Root Complex Integrated Endpoint, MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0
    			ExtTag- RBE-
    		DevCtl:	Report errors: Correctable- Non-Fatal- Fatal- Unsupported-
    			RlxdOrd- ExtTag- PhantFunc- AuxPwr- NoSnoop+
    			MaxPayload 128 bytes, MaxReadReq 128 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr+ TransPend-
    	Capabilities: [100 v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed- WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending- InProgress-
    		VC1:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=1 ArbSelect=Fixed TC/VC=80
    			Status:	NegoPending- InProgress-
    	Capabilities: [130 v1] Root Complex Link
    		Desc:	PortNumber=0f ComponentID=02 EltType=Config
    		Link0:	Desc:	TargetPort=00 TargetComponent=02 AssocRCRB- LinkType=MemMapped LinkValid+
    			Addr:	00000000feda8000
    	Kernel driver in use: snd_hda_intel
    	Kernel modules: snd_hda_intel
    1 of 17 matched Audio

# PulseAudio Version

    pulseaudio 8.0

# PulseAudio Configurations

    ### 从配置文件读取：/etc/pulse/daemon.conf ###
    daemonize = no
    fail = yes
    high-priority = yes
    nice-level = -11
    realtime-scheduling = yes
    realtime-priority = 5
    allow-module-loading = yes
    allow-exit = yes
    use-pid-file = yes
    system-instance = no
    local-server-type = user
    cpu-limit = no
    enable-shm = yes
    flat-volumes = no
    lock-memory = no
    exit-idle-time = 20
    scache-idle-time = 20
    dl-search-path = /usr/lib/pulse-8.0/modules
    default-script-file = /etc/pulse/default.pa
    load-default-script-file = yes
    log-target = 
    log-level = notice
    resample-method = auto
    enable-remixing = yes
    enable-lfe-remixing = yes
    lfe-crossover-freq = 120
    default-sample-format = s16le
    default-sample-rate = 44100
    alternate-sample-rate = 48000
    default-sample-channels = 2
    default-channel-map = front-left,front-right
    default-fragments = 4
    default-fragment-size-msec = 25
    enable-deferred-volume = yes
    deferred-volume-safety-margin-usec = 1
    deferred-volume-extra-delay-usec = 0
    shm-size-bytes = 0
    log-meta = no
    log-time = no
    log-backtrace = 0
    rlimit-fsize = -1
    rlimit-data = -1
    rlimit-stack = -1
    rlimit-core = -1
    rlimit-rss = -1
    rlimit-as = -1
    rlimit-nproc = -1
    rlimit-nofile = 256
    rlimit-memlock = -1
    rlimit-locks = -1
    rlimit-sigpending = -1
    rlimit-msgqueue = -1
    rlimit-nice = 31
    rlimit-rtprio = 9
    rlimit-rttime = 200000

# PulseAudio Modules

    module-alsa-card                        ALSA Card
    module-alsa-sink                        ALSA Sink
    module-alsa-source                      ALSA Source
    module-always-sink                      总是保持至少载入一个采集器，即使它是空的
    module-augment-properties               Augment the property sets of streams with additional static information
    module-bluetooth-discover               Detect available Bluetooth daemon and load the corresponding discovery module
    module-bluetooth-policy                 When a bluetooth sink or source is added, load module-loopback
    module-bluez5-device                    BlueZ 5 Bluetooth audio sink and source
    module-bluez5-discover                  Detect available BlueZ 5 Bluetooth audio devices and load BlueZ 5 Bluetooth audio drivers
    module-card-restore                     Automatically restore profile of cards
    module-cli                              Command line interface
    module-cli-protocol-tcp                 Command line interface protocol (TCP sockets)
    module-cli-protocol-unix                Command line interface protocol (UNIX sockets)
    module-combine                          Compatibility module (module-combine rename)
    module-combine-sink                     Combine multiple sinks to one
    module-console-kit                      Create a client for each ConsoleKit session of this user
    module-dbus-protocol                    D-Bus interface
    module-deepin-workaround                workaound: no audio when headphone is plugged in after login.
    module-default-device-restore           Automatically restore the default sink and source
    module-detect                           Detect available audio hardware and load matching drivers
    module-device-manager                   Keep track of devices (and their descriptions) both past and present and prioritise by role
    module-device-restore                   Automatically restore the volume/mute state of devices
    module-echo-cancel                      Echo Cancellation
    module-equalizer-sink                   通用均衡器
    module-esound-sink                      ESOUND Sink
    module-filter-apply                     Load filter sinks automatically when needed
    module-filter-heuristics                Detect when various filters are desirable
    module-http-protocol-tcp                HTTP (TCP sockets)
    module-http-protocol-unix               HTTP (UNIX sockets)
    module-intended-roles                   Automatically set device of streams based on intended roles of devices
    module-ladspa-sink                      虚拟 LDASPA 采集器
    module-loopback                         Loopback from source to sink
    module-match                            Playback stream expression matching module
    module-mmkbd-evdev                      Multimedia keyboard support via Linux evdev
    module-native-protocol-fd               Native protocol autospawn helper
    module-native-protocol-tcp              Native protocol (TCP sockets)
    module-native-protocol-unix             Native protocol (UNIX sockets)
    module-null-sink                        定时的空采集器
    module-null-source                      Clocked NULL source
    module-oss                              OSS Sink/Source
    module-pipe-sink                        UNIX pipe sink
    module-pipe-source                      UNIX pipe source
    module-position-event-sounds            Position event sounds between L and R depending on the position on screen of the widget triggering them.
    module-remap-sink                       Virtual channel remapping sink
    module-remap-source                     Virtual channel remapping source
    module-rescue-streams                   When a sink/source is removed, try to move its streams to the default sink/source
    module-role-cork                        Mute & cork streams with certain roles while others exist
    module-role-ducking                     Apply a ducking effect based on streams roles
    module-rtp-recv                         Receive data from a network via RTP/SAP/SDP
    module-rtp-send                         Read data from source and send it to the network via RTP/SAP/SDP
    module-rygel-media-server               UPnP MediaServer Plugin for Rygel
    module-simple-protocol-tcp              Simple protocol (TCP sockets)
    module-simple-protocol-unix             Simple protocol (UNIX sockets)
    module-sine                             Sine wave generator
    module-sine-source                      Sine wave generator source
    module-stream-restore                   Automatically restore the volume/mute/device state of streams
    module-suspend-on-idle                  When a sink/source is idle for too long, suspend it
    module-switch-on-connect                When a sink/source is added, switch to it or conditionally switch to it
    module-switch-on-port-available         n/a
    module-systemd-login                    Create a client for each login session of this user
    module-tunnel-sink                      Tunnel module for sinks
    module-tunnel-sink-new                  Create a network sink which connects via a stream to a remote PulseAudio server
    module-tunnel-source                    Tunnel module for sources
    module-tunnel-source-new                Create a network source which connects via a stream to a remote PulseAudio server
    module-udev-detect                      Detect available audio hardware and load matching drivers
    module-virtual-sink                     Virtual sink
    module-virtual-source                   Virtual source
    module-virtual-surround-sink            虚拟环绕声采集器
    module-volume-restore                   Compatibility module
    module-x11-bell                         X11 bell interceptor
    module-x11-cork-request                 Synthesize X11 media key events when cork/uncork is requested
    module-x11-publish                      X11 credential publisher
    module-x11-xsmp                         X11 session management

# PulseAudio Resample Methods

    trivial
    speex-float-0
    speex-float-1
    speex-float-2
    speex-float-3
    speex-float-4
    speex-float-5
    speex-float-6
    speex-float-7
    speex-float-8
    speex-float-9
    speex-float-10
    speex-fixed-0
    speex-fixed-1
    speex-fixed-2
    speex-fixed-3
    speex-fixed-4
    speex-fixed-5
    speex-fixed-6
    speex-fixed-7
    speex-fixed-8
    speex-fixed-9
    speex-fixed-10
    ffmpeg
    auto
    copy
    peaks
    soxr-mq
    soxr-hq
    soxr-vhq
