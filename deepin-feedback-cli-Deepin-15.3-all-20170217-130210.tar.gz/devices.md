
# CPU

    processor	: 0
    vendor_id	: GenuineIntel
    cpu family	: 6
    model		: 23
    model name	: Intel(R) Core(TM)2 Duo CPU     E7500  @ 2.93GHz
    stepping	: 10
    microcode	: 0xa0b
    cpu MHz		: 1600.000
    cache size	: 3072 KB
    physical id	: 0
    siblings	: 2
    core id		: 0
    cpu cores	: 2
    apicid		: 0
    initial apicid	: 0
    fpu		: yes
    fpu_exception	: yes
    cpuid level	: 13
    wp		: yes
    flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx lm constant_tsc arch_perfmon pebs bts rep_good nopl aperfmperf eagerfpu pni dtes64 monitor ds_cpl vmx est tm2 ssse3 cx16 xtpr pdcm sse4_1 xsave lahf_lm tpr_shadow vnmi flexpriority dtherm
    bugs		:
    bogomips	: 5851.93
    clflush size	: 64
    cache_alignment	: 64
    address sizes	: 36 bits physical, 48 bits virtual
    power management:
    
    processor	: 1
    vendor_id	: GenuineIntel
    cpu family	: 6
    model		: 23
    model name	: Intel(R) Core(TM)2 Duo CPU     E7500  @ 2.93GHz
    stepping	: 10
    microcode	: 0xa0b
    cpu MHz		: 2933.000
    cache size	: 3072 KB
    physical id	: 0
    siblings	: 2
    core id		: 1
    cpu cores	: 2
    apicid		: 1
    initial apicid	: 1
    fpu		: yes
    fpu_exception	: yes
    cpuid level	: 13
    wp		: yes
    flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx lm constant_tsc arch_perfmon pebs bts rep_good nopl aperfmperf eagerfpu pni dtes64 monitor ds_cpl vmx est tm2 ssse3 cx16 xtpr pdcm sse4_1 xsave lahf_lm tpr_shadow vnmi flexpriority dtherm
    bugs		:
    bogomips	: 5851.93
    clflush size	: 64
    cache_alignment	: 64
    address sizes	: 36 bits physical, 48 bits virtual
    power management:

# Memory

                  total        used        free      shared  buff/cache   available
    Mem:           3.8G        2.2G        118M        336M        1.5G        1.0G
    Swap:            0B          0B          0B
    Total:         3.8G        2.2G        118M
    MemTotal:        3947732 kB
    MemFree:          121524 kB
    MemAvailable:    1074704 kB
    Buffers:          117860 kB
    Cached:          1338744 kB
    SwapCached:            0 kB
    Active:          2700640 kB
    Inactive:         883976 kB
    Active(anon):    2129928 kB
    Inactive(anon):   343132 kB
    Active(file):     570712 kB
    Inactive(file):   540844 kB
    Unevictable:         112 kB
    Mlocked:             112 kB
    SwapTotal:             0 kB
    SwapFree:              0 kB
    Dirty:             18388 kB
    Writeback:             0 kB
    AnonPages:       2124220 kB
    Mapped:           528560 kB
    Shmem:            345052 kB
    Slab:             136456 kB
    SReclaimable:      90408 kB
    SUnreclaim:        46048 kB
    KernelStack:       10780 kB
    PageTables:        52848 kB
    NFS_Unstable:          0 kB
    Bounce:                0 kB
    WritebackTmp:          0 kB
    CommitLimit:     1973864 kB
    Committed_AS:    8565832 kB
    VmallocTotal:   34359738367 kB
    VmallocUsed:           0 kB
    VmallocChunk:          0 kB
    HardwareCorrupted:     0 kB
    AnonHugePages:         0 kB
    ShmemHugePages:        0 kB
    ShmemPmdMapped:        0 kB
    HugePages_Total:       0
    HugePages_Free:        0
    HugePages_Rsvd:        0
    HugePages_Surp:        0
    Hugepagesize:       2048 kB
    DirectMap4k:      155680 kB
    DirectMap2M:     3936256 kB

# USB Devices

    Bus 005 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
    Bus 004 Device 001: ID 1d6b:0001 Linux Foundation 1.1 root hub
    Bus 003 Device 001: ID 1d6b:0001 Linux Foundation 1.1 root hub
    Bus 002 Device 001: ID 1d6b:0001 Linux Foundation 1.1 root hub
    Bus 001 Device 003: ID 0461:4d22 Primax Electronics, Ltd 
    Bus 001 Device 002: ID 413c:2003 Dell Computer Corp. Keyboard
    Bus 001 Device 001: ID 1d6b:0001 Linux Foundation 1.1 root hub
    
    T:  Bus=01 Lev=00 Prnt=00 Port=00 Cnt=00 Dev#=  1 Spd=12  MxCh= 2
    D:  Ver= 1.10 Cls=09(hub  ) Sub=00 Prot=00 MxPS=64 #Cfgs=  1
    P:  Vendor=1d6b ProdID=0001 Rev=04.09
    S:  Manufacturer=Linux 4.9.0-deepin2-amd64 uhci_hcd
    S:  Product=UHCI Host Controller
    S:  SerialNumber=0000:00:1d.0
    C:  #Ifs= 1 Cfg#= 1 Atr=e0 MxPwr=0mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=09(hub  ) Sub=00 Prot=00 Driver=hub
    
    T:  Bus=01 Lev=01 Prnt=01 Port=00 Cnt=01 Dev#=  2 Spd=1.5 MxCh= 0
    D:  Ver= 1.10 Cls=00(>ifc ) Sub=00 Prot=00 MxPS= 8 #Cfgs=  1
    P:  Vendor=413c ProdID=2003 Rev=03.07
    S:  Manufacturer=Dell
    S:  Product=Dell USB Keyboard
    C:  #Ifs= 1 Cfg#= 1 Atr=a0 MxPwr=70mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=03(HID  ) Sub=01 Prot=01 Driver=usbhid
    
    T:  Bus=01 Lev=01 Prnt=01 Port=01 Cnt=02 Dev#=  3 Spd=1.5 MxCh= 0
    D:  Ver= 2.00 Cls=00(>ifc ) Sub=00 Prot=00 MxPS= 8 #Cfgs=  1
    P:  Vendor=0461 ProdID=4d22 Rev=02.00
    S:  Product=USB Optical Mouse
    C:  #Ifs= 1 Cfg#= 1 Atr=a0 MxPwr=100mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=03(HID  ) Sub=01 Prot=02 Driver=usbhid
    
    T:  Bus=02 Lev=00 Prnt=00 Port=00 Cnt=00 Dev#=  1 Spd=12  MxCh= 2
    D:  Ver= 1.10 Cls=09(hub  ) Sub=00 Prot=00 MxPS=64 #Cfgs=  1
    P:  Vendor=1d6b ProdID=0001 Rev=04.09
    S:  Manufacturer=Linux 4.9.0-deepin2-amd64 uhci_hcd
    S:  Product=UHCI Host Controller
    S:  SerialNumber=0000:00:1d.1
    C:  #Ifs= 1 Cfg#= 1 Atr=e0 MxPwr=0mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=09(hub  ) Sub=00 Prot=00 Driver=hub
    
    T:  Bus=03 Lev=00 Prnt=00 Port=00 Cnt=00 Dev#=  1 Spd=12  MxCh= 2
    D:  Ver= 1.10 Cls=09(hub  ) Sub=00 Prot=00 MxPS=64 #Cfgs=  1
    P:  Vendor=1d6b ProdID=0001 Rev=04.09
    S:  Manufacturer=Linux 4.9.0-deepin2-amd64 uhci_hcd
    S:  Product=UHCI Host Controller
    S:  SerialNumber=0000:00:1d.2
    C:  #Ifs= 1 Cfg#= 1 Atr=e0 MxPwr=0mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=09(hub  ) Sub=00 Prot=00 Driver=hub
    
    T:  Bus=04 Lev=00 Prnt=00 Port=00 Cnt=00 Dev#=  1 Spd=12  MxCh= 2
    D:  Ver= 1.10 Cls=09(hub  ) Sub=00 Prot=00 MxPS=64 #Cfgs=  1
    P:  Vendor=1d6b ProdID=0001 Rev=04.09
    S:  Manufacturer=Linux 4.9.0-deepin2-amd64 uhci_hcd
    S:  Product=UHCI Host Controller
    S:  SerialNumber=0000:00:1d.3
    C:  #Ifs= 1 Cfg#= 1 Atr=e0 MxPwr=0mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=09(hub  ) Sub=00 Prot=00 Driver=hub
    
    T:  Bus=05 Lev=00 Prnt=00 Port=00 Cnt=00 Dev#=  1 Spd=480 MxCh= 8
    D:  Ver= 2.00 Cls=09(hub  ) Sub=00 Prot=00 MxPS=64 #Cfgs=  1
    P:  Vendor=1d6b ProdID=0002 Rev=04.09
    S:  Manufacturer=Linux 4.9.0-deepin2-amd64 ehci_hcd
    S:  Product=EHCI Host Controller
    S:  SerialNumber=0000:00:1d.7
    C:  #Ifs= 1 Cfg#= 1 Atr=e0 MxPwr=0mA
    I:  If#= 0 Alt= 0 #EPs= 1 Cls=09(hub  ) Sub=00 Prot=00 Driver=hub

# PCI Devices

    00:00.0 Host bridge [0600]: Intel Corporation 4 Series Chipset DRAM Controller [8086:2e30] (rev 03)
    	Subsystem: Dell 4 Series Chipset DRAM Controller [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx-
    	Status: Cap+ 66MHz- UDF- FastB2B+ ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort+ >SERR- <PERR- INTx-
    	Latency: 0
    	Capabilities: [e0] Vendor Specific Information: Len=0c <?>
    
    00:01.0 PCI bridge [0604]: Intel Corporation 4 Series Chipset PCI Express Root Port [8086:2e31] (rev 03) (prog-if 00 [Normal decode])
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 24
    	Bus: primary=00, secondary=01, subordinate=01, sec-latency=0
    	Memory behind bridge: fe500000-fe5fffff
    	Secondary status: 66MHz- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- <SERR- <PERR-
    	BridgeCtl: Parity- SERR+ NoISA- VGA- MAbort- >Reset- FastB2B-
    		PriDiscTmr- SecDiscTmr- DiscTmrStat- DiscTmrSERREn-
    	Capabilities: [88] Subsystem: Dell 4 Series Chipset PCI Express Root Port [1028:0400]
    	Capabilities: [80] Power Management version 3
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=0mA PME(D0+,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst+ PME-Enable- DSel=0 DScale=0 PME-
    	Capabilities: [90] MSI: Enable+ Count=1/1 Maskable- 64bit-
    		Address: fee0300c  Data: 41a1
    	Capabilities: [a0] Express (v2) Root Port (Slot+), MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0
    			ExtTag- RBE+
    		DevCtl:	Report errors: Correctable- Non-Fatal- Fatal- Unsupported-
    			RlxdOrd- ExtTag- PhantFunc- AuxPwr- NoSnoop-
    			MaxPayload 128 bytes, MaxReadReq 128 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr- TransPend-
    		LnkCap:	Port #2, Speed 2.5GT/s, Width x16, ASPM L0s, Exit Latency L0s <256ns, L1 <4us
    			ClockPM- Surprise- LLActRep- BwNot+ ASPMOptComp-
    		LnkCtl:	ASPM Disabled; RCB 64 bytes Disabled- CommClk+
    			ExtSynch- ClockPM- AutWidDis- BWInt- AutBWInt-
    		LnkSta:	Speed 2.5GT/s, Width x0, TrErr- Train- SlotClk+ DLActive- BWMgmt- ABWMgmt-
    		SltCap:	AttnBtn- PwrCtrl- MRL- AttnInd- PwrInd- HotPlug- Surprise-
    			Slot #1, PowerLimit 75.000W; Interlock- NoCompl+
    		SltCtl:	Enable: AttnBtn- PwrFlt- MRL- PresDet- CmdCplt- HPIrq- LinkChg-
    			Control: AttnInd Unknown, PwrInd Unknown, Power- Interlock-
    		SltSta:	Status: AttnBtn- PowerFlt- MRL- CmdCplt- PresDet- Interlock-
    			Changed: MRL- PresDet- LinkState-
    		RootCtl: ErrCorrectable- ErrNon-Fatal- ErrFatal- PMEIntEna- CRSVisible-
    		RootCap: CRSVisible-
    		RootSta: PME ReqID 0000, PMEStatus- PMEPending-
    		DevCap2: Completion Timeout: Not Supported, TimeoutDis-, LTR-, OBFF Not Supported ARIFwd-
    		DevCtl2: Completion Timeout: 50us to 50ms, TimeoutDis-, LTR-, OBFF Disabled ARIFwd-
    		LnkCtl2: Target Link Speed: 5GT/s, EnterCompliance- SpeedDis-
    			 Transmit Margin: Normal Operating Range, EnterModifiedCompliance- ComplianceSOS-
    			 Compliance De-emphasis: -6dB
    		LnkSta2: Current De-emphasis Level: -6dB, EqualizationComplete-, EqualizationPhase1-
    			 EqualizationPhase2-, EqualizationPhase3-, LinkEqualizationRequest-
    	Capabilities: [100 v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed- WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed+ WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending+ InProgress-
    	Capabilities: [140 v1] Root Complex Link
    		Desc:	PortNumber=02 ComponentID=01 EltType=Config
    		Link0:	Desc:	TargetPort=00 TargetComponent=01 AssocRCRB- LinkType=MemMapped LinkValid+
    			Addr:	00000000feda5000
    	Kernel driver in use: pcieport
    	Kernel modules: shpchp
    
    00:02.0 VGA compatible controller [0300]: Intel Corporation 4 Series Chipset Integrated Graphics Controller [8086:2e32] (rev 03) (prog-if 00 [VGA controller])
    	Subsystem: Dell 4 Series Chipset Integrated Graphics Controller [1028:0400]
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B+ ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin A routed to IRQ 26
    	Region 0: Memory at fe800000 (64-bit, non-prefetchable) [size=4M]
    	Region 2: Memory at d0000000 (64-bit, prefetchable) [size=256M]
    	Region 4: I/O ports at ecd8 [size=8]
    	[virtual] Expansion ROM at 000c0000 [disabled] [size=128K]
    	Capabilities: [90] MSI: Enable+ Count=1/1 Maskable- 64bit-
    		Address: fee0200c  Data: 4142
    	Capabilities: [d0] Power Management version 2
    		Flags: PMEClk- DSI+ D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot-,D3cold-)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Kernel driver in use: i915
    	Kernel modules: i915
    
    00:02.1 Display controller [0380]: Intel Corporation 4 Series Chipset Integrated Graphics Controller [8086:2e33] (rev 03)
    	Subsystem: Dell 4 Series Chipset Integrated Graphics Controller [1028:0400]
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap+ 66MHz- UDF- FastB2B+ ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Region 0: Memory at fe700000 (64-bit, non-prefetchable) [size=1M]
    	Capabilities: [d0] Power Management version 2
    		Flags: PMEClk- DSI+ D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot-,D3cold-)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    
    00:1b.0 Audio device [0403]: Intel Corporation NM10/ICH7 Family High Definition Audio Controller [8086:27d8] (rev 01)
    	Subsystem: Dell NM10/ICH7 Family High Definition Audio Controller [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 27
    	Region 0: Memory at fe6fc000 (64-bit, non-prefetchable) [size=16K]
    	Capabilities: [50] Power Management version 2
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=55mA PME(D0+,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Capabilities: [60] MSI: Enable+ Count=1/1 Maskable- 64bit+
    		Address: 00000000fee0200c  Data: 4172
    	Capabilities: [70] Express (v1) Root Complex Integrated Endpoint, MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0
    			ExtTag- RBE-
    		DevCtl:	Report errors: Correctable- Non-Fatal- Fatal- Unsupported-
    			RlxdOrd- ExtTag- PhantFunc- AuxPwr- NoSnoop+
    			MaxPayload 128 bytes, MaxReadReq 128 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr+ TransPend-
    	Capabilities: [100 v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed- WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending- InProgress-
    		VC1:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=1 ArbSelect=Fixed TC/VC=80
    			Status:	NegoPending- InProgress-
    	Capabilities: [130 v1] Root Complex Link
    		Desc:	PortNumber=0f ComponentID=02 EltType=Config
    		Link0:	Desc:	TargetPort=00 TargetComponent=02 AssocRCRB- LinkType=MemMapped LinkValid+
    			Addr:	00000000feda8000
    	Kernel driver in use: snd_hda_intel
    	Kernel modules: snd_hda_intel
    
    00:1c.0 PCI bridge [0604]: Intel Corporation NM10/ICH7 Family PCI Express Port 1 [8086:27d0] (rev 01) (prog-if 00 [Normal decode])
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 25
    	Bus: primary=00, secondary=02, subordinate=02, sec-latency=0
    	I/O behind bridge: 00001000-00001fff
    	Memory behind bridge: fe400000-fe4fffff
    	Prefetchable memory behind bridge: 00000000f0000000-00000000f01fffff
    	Secondary status: 66MHz- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- <SERR- <PERR-
    	BridgeCtl: Parity- SERR+ NoISA- VGA- MAbort- >Reset- FastB2B-
    		PriDiscTmr- SecDiscTmr- DiscTmrStat- DiscTmrSERREn-
    	Capabilities: [40] Express (v1) Root Port (Slot+), MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0
    			ExtTag- RBE-
    		DevCtl:	Report errors: Correctable- Non-Fatal- Fatal- Unsupported-
    			RlxdOrd- ExtTag- PhantFunc- AuxPwr- NoSnoop-
    			MaxPayload 128 bytes, MaxReadReq 128 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr+ TransPend-
    		LnkCap:	Port #1, Speed 2.5GT/s, Width x1, ASPM L0s, Exit Latency L0s <256ns, L1 <4us
    			ClockPM- Surprise- LLActRep+ BwNot- ASPMOptComp-
    		LnkCtl:	ASPM Disabled; RCB 64 bytes Disabled- CommClk+
    			ExtSynch- ClockPM- AutWidDis- BWInt- AutBWInt-
    		LnkSta:	Speed 2.5GT/s, Width x1, TrErr- Train- SlotClk+ DLActive+ BWMgmt- ABWMgmt-
    		SltCap:	AttnBtn- PwrCtrl- MRL- AttnInd- PwrInd- HotPlug+ Surprise+
    			Slot #4, PowerLimit 10.000W; Interlock- NoCompl-
    		SltCtl:	Enable: AttnBtn- PwrFlt- MRL- PresDet- CmdCplt- HPIrq- LinkChg-
    			Control: AttnInd Unknown, PwrInd Unknown, Power- Interlock-
    		SltSta:	Status: AttnBtn- PowerFlt- MRL- CmdCplt- PresDet+ Interlock-
    			Changed: MRL- PresDet+ LinkState+
    		RootCtl: ErrCorrectable- ErrNon-Fatal- ErrFatal- PMEIntEna- CRSVisible-
    		RootCap: CRSVisible-
    		RootSta: PME ReqID 0000, PMEStatus- PMEPending-
    	Capabilities: [80] MSI: Enable+ Count=1/1 Maskable- 64bit-
    		Address: fee0300c  Data: 41b1
    	Capabilities: [90] Subsystem: Dell NM10/ICH7 Family PCI Express Port 1 [1028:0400]
    	Capabilities: [a0] Power Management version 2
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=0mA PME(D0+,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Capabilities: [100 v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed+ WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed+ WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending- InProgress-
    		VC1:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed+ WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable- ID=0 ArbSelect=Fixed TC/VC=00
    			Status:	NegoPending- InProgress-
    	Capabilities: [180 v1] Root Complex Link
    		Desc:	PortNumber=01 ComponentID=02 EltType=Config
    		Link0:	Desc:	TargetPort=00 TargetComponent=02 AssocRCRB- LinkType=MemMapped LinkValid+
    			Addr:	00000000feda8001
    	Kernel driver in use: pcieport
    	Kernel modules: shpchp
    
    00:1d.0 USB controller [0c03]: Intel Corporation NM10/ICH7 Family USB UHCI Controller #1 [8086:27c8] (rev 01) (prog-if 00 [UHCI])
    	Subsystem: Dell NM10/ICH7 Family USB UHCI Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin A routed to IRQ 21
    	Region 4: I/O ports at ff80 [size=32]
    	Kernel driver in use: uhci_hcd
    	Kernel modules: uhci_hcd
    
    00:1d.1 USB controller [0c03]: Intel Corporation NM10/ICH7 Family USB UHCI Controller #2 [8086:27c9] (rev 01) (prog-if 00 [UHCI])
    	Subsystem: Dell NM10/ICH7 Family USB UHCI Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin B routed to IRQ 22
    	Region 4: I/O ports at ff60 [size=32]
    	Kernel driver in use: uhci_hcd
    	Kernel modules: uhci_hcd
    
    00:1d.2 USB controller [0c03]: Intel Corporation NM10/ICH7 Family USB UHCI Controller #3 [8086:27ca] (rev 01) (prog-if 00 [UHCI])
    	Subsystem: Dell NM10/ICH7 Family USB UHCI Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin C routed to IRQ 18
    	Region 4: I/O ports at ff40 [size=32]
    	Kernel driver in use: uhci_hcd
    	Kernel modules: uhci_hcd
    
    00:1d.3 USB controller [0c03]: Intel Corporation NM10/ICH7 Family USB UHCI Controller #4 [8086:27cb] (rev 01) (prog-if 00 [UHCI])
    	Subsystem: Dell NM10/ICH7 Family USB UHCI Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin D routed to IRQ 23
    	Region 4: I/O ports at ff20 [size=32]
    	Kernel driver in use: uhci_hcd
    	Kernel modules: uhci_hcd
    
    00:1d.7 USB controller [0c03]: Intel Corporation NM10/ICH7 Family USB2 EHCI Controller [8086:27cc] (rev 01) (prog-if 20 [EHCI])
    	Subsystem: Dell NM10/ICH7 Family USB2 EHCI Controller [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx-
    	Status: Cap+ 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin A routed to IRQ 21
    	Region 0: Memory at ff980000 (32-bit, non-prefetchable) [size=1K]
    	Capabilities: [50] Power Management version 2
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=375mA PME(D0+,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Capabilities: [58] Debug port: BAR=1 offset=00a0
    	Kernel driver in use: ehci-pci
    	Kernel modules: ehci_pci
    
    00:1e.0 PCI bridge [0604]: Intel Corporation 82801 PCI Bridge [8086:244e] (rev e1) (prog-if 01 [Subtractive decode])
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx-
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Bus: primary=00, secondary=03, subordinate=03, sec-latency=32
    	Secondary status: 66MHz- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort+ <SERR- <PERR-
    	BridgeCtl: Parity- SERR+ NoISA- VGA- MAbort- >Reset- FastB2B-
    		PriDiscTmr- SecDiscTmr- DiscTmrStat- DiscTmrSERREn-
    	Capabilities: [50] Subsystem: Dell 82801 PCI Bridge [1028:0000]
    
    00:1f.0 ISA bridge [0601]: Intel Corporation 82801GB/GR (ICH7 Family) LPC Interface Bridge [8086:27b8] (rev 01)
    	Control: I/O+ Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx-
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Capabilities: [e0] Vendor Specific Information: Len=0c <?>
    	Kernel driver in use: lpc_ich
    	Kernel modules: intel_rng, lpc_ich, leds_ss4200
    
    00:1f.1 IDE interface [0101]: Intel Corporation 82801G (ICH7 Family) IDE Controller [8086:27df] (rev 01) (prog-if 8a [Master SecP PriP])
    	Subsystem: Dell 82801G (ICH7 Family) IDE Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx+
    	Latency: 0
    	Interrupt: pin A routed to IRQ 16
    	Region 0: I/O ports at 01f0 [size=8]
    	Region 1: I/O ports at 03f4
    	Region 2: I/O ports at 0170 [size=8]
    	Region 3: I/O ports at 0374
    	Region 4: I/O ports at ffa0 [size=16]
    	Kernel driver in use: ata_piix
    	Kernel modules: ata_piix, ata_generic
    
    00:1f.2 IDE interface [0101]: Intel Corporation NM10/ICH7 Family SATA Controller [IDE mode] [8086:27c0] (rev 01) (prog-if 8f [Master SecP SecO PriP PriO])
    	Subsystem: Dell NM10/ICH7 Family SATA Controller [IDE mode] [1028:0400]
    	Control: I/O+ Mem- BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx-
    	Status: Cap+ 66MHz+ UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0
    	Interrupt: pin C routed to IRQ 20
    	Region 0: I/O ports at fe00 [size=8]
    	Region 1: I/O ports at fe10 [size=4]
    	Region 2: I/O ports at fe20 [size=8]
    	Region 3: I/O ports at fe30 [size=4]
    	Region 4: I/O ports at fec0 [size=16]
    	Capabilities: [70] Power Management version 2
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot+,D3cold-)
    		Status: D0 NoSoftRst- PME-Enable- DSel=0 DScale=0 PME-
    	Kernel driver in use: ata_piix
    	Kernel modules: ata_piix, ata_generic
    
    00:1f.3 SMBus [0c05]: Intel Corporation NM10/ICH7 Family SMBus Controller [8086:27da] (rev 01)
    	Subsystem: Dell NM10/ICH7 Family SMBus Controller [1028:0400]
    	Control: I/O+ Mem- BusMaster- SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR+ FastB2B- DisINTx-
    	Status: Cap- 66MHz- UDF- FastB2B+ ParErr- DEVSEL=medium >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Interrupt: pin B routed to IRQ 17
    	Region 4: I/O ports at ece0 [size=32]
    	Kernel driver in use: i801_smbus
    	Kernel modules: i2c_i801
    
    02:00.0 Ethernet controller [0200]: Broadcom Corporation NetLink BCM57780 Gigabit Ethernet PCIe [14e4:1692] (rev 01)
    	Subsystem: Dell NetLink BCM57780 Gigabit Ethernet PCIe [1028:0400]
    	Control: I/O- Mem+ BusMaster+ SpecCycle- MemWINV- VGASnoop- ParErr- Stepping- SERR- FastB2B- DisINTx+
    	Status: Cap+ 66MHz- UDF- FastB2B- ParErr- DEVSEL=fast >TAbort- <TAbort- <MAbort- >SERR- <PERR- INTx-
    	Latency: 0, Cache Line Size: 64 bytes
    	Interrupt: pin A routed to IRQ 28
    	Region 0: Memory at fe4f0000 (64-bit, non-prefetchable) [size=64K]
    	Capabilities: [48] Power Management version 3
    		Flags: PMEClk- DSI- D1- D2- AuxCurrent=0mA PME(D0-,D1-,D2-,D3hot+,D3cold+)
    		Status: D0 NoSoftRst+ PME-Enable- DSel=0 DScale=1 PME-
    	Capabilities: [60] Vendor Specific Information: Len=6c <?>
    	Capabilities: [50] MSI: Enable+ Count=1/1 Maskable- 64bit+
    		Address: 00000000fee0200c  Data: 4182
    	Capabilities: [cc] Express (v2) Endpoint, MSI 00
    		DevCap:	MaxPayload 128 bytes, PhantFunc 0, Latency L0s <4us, L1 unlimited
    			ExtTag+ AttnBtn- AttnInd- PwrInd- RBE+ FLReset-
    		DevCtl:	Report errors: Correctable- Non-Fatal+ Fatal+ Unsupported-
    			RlxdOrd- ExtTag+ PhantFunc- AuxPwr- NoSnoop-
    			MaxPayload 128 bytes, MaxReadReq 512 bytes
    		DevSta:	CorrErr- UncorrErr- FatalErr- UnsuppReq- AuxPwr+ TransPend-
    		LnkCap:	Port #0, Speed 2.5GT/s, Width x1, ASPM L0s L1, Exit Latency L0s <1us, L1 <32us
    			ClockPM+ Surprise- LLActRep- BwNot- ASPMOptComp-
    		LnkCtl:	ASPM Disabled; RCB 64 bytes Disabled- CommClk+
    			ExtSynch- ClockPM- AutWidDis- BWInt- AutBWInt-
    		LnkSta:	Speed 2.5GT/s, Width x1, TrErr- Train- SlotClk+ DLActive- BWMgmt- ABWMgmt-
    		DevCap2: Completion Timeout: Range ABCD, TimeoutDis+, LTR-, OBFF Not Supported
    		DevCtl2: Completion Timeout: 50us to 50ms, TimeoutDis-, LTR-, OBFF Disabled
    		LnkCtl2: Target Link Speed: 2.5GT/s, EnterCompliance- SpeedDis-
    			 Transmit Margin: Normal Operating Range, EnterModifiedCompliance- ComplianceSOS-
    			 Compliance De-emphasis: -6dB
    		LnkSta2: Current De-emphasis Level: -6dB, EqualizationComplete-, EqualizationPhase1-
    			 EqualizationPhase2-, EqualizationPhase3-, LinkEqualizationRequest-
    	Capabilities: [100 v1] Advanced Error Reporting
    		UESta:	DLP- SDES- TLP- FCP- CmpltTO- CmpltAbrt- UnxCmplt- RxOF- MalfTLP- ECRC- UnsupReq- ACSViol-
    		UEMsk:	DLP- SDES- TLP- FCP- CmpltTO- CmpltAbrt- UnxCmplt- RxOF- MalfTLP- ECRC- UnsupReq- ACSViol-
    		UESvrt:	DLP+ SDES+ TLP- FCP+ CmpltTO- CmpltAbrt- UnxCmplt- RxOF+ MalfTLP+ ECRC- UnsupReq- ACSViol-
    		CESta:	RxErr- BadTLP- BadDLLP- Rollover- Timeout- NonFatalErr-
    		CEMsk:	RxErr- BadTLP- BadDLLP- Rollover- Timeout- NonFatalErr+
    		AERCap:	First Error Pointer: 00, GenCap+ CGenEn- ChkCap+ ChkEn-
    	Capabilities: [13c v1] Virtual Channel
    		Caps:	LPEVC=0 RefClk=100ns PATEntryBits=1
    		Arb:	Fixed- WRR32- WRR64- WRR128-
    		Ctrl:	ArbSelect=Fixed
    		Status:	InProgress-
    		VC0:	Caps:	PATOffset=00 MaxTimeSlots=1 RejSnoopTrans-
    			Arb:	Fixed- WRR32- WRR64- WRR128- TWRR128- WRR256-
    			Ctrl:	Enable+ ID=0 ArbSelect=Fixed TC/VC=01
    			Status:	NegoPending- InProgress-
    	Capabilities: [160 v1] Device Serial Number b8-ac-6f-ff-fe-44-bc-74
    	Capabilities: [16c v1] Power Budgeting <?>
    	Kernel driver in use: tg3
    	Kernel modules: tg3

# Hardware Lister(lshw)

    wp-pc
        description: Mini Tower Computer
        product: OptiPlex 380
        vendor: Dell Inc.
        serial: FPRKX2X
        width: 64 bits
        capabilities: smbios-2.5 dmi-2.5 smp vsyscall32
        configuration: administrator_password=enabled boot=normal chassis=mini-tower power-on_password=enabled uuid=44454C4C-5000-1052-804B-C6C04F583258
      *-core
           description: Motherboard
           product: 0HN7XN
           vendor: Dell Inc.
           physical id: 0
           version: A01
           serial: ..CN1374006S05VK.
         *-firmware
              description: BIOS
              vendor: Dell Inc.
              physical id: 0
              version: A01
              date: 03/11/2010
              size: 64KiB
              capacity: 1984KiB
              capabilities: pci pnp apm upgrade shadowing escd cdboot bootselect edd int13floppytoshiba int13floppy720 int5printscreen int9keyboard int14serial int17printer acpi usb biosbootspecification netboot
         *-cpu
              description: CPU
              product: Intel(R) Core(TM)2 Duo CPU     E7500  @ 2.93GHz
              vendor: Intel Corp.
              physical id: 400
              bus info: cpu@0
              slot: CPU
              size: 2933MHz
              capacity: 2933MHz
              width: 64 bits
              clock: 1066MHz
              capabilities: x86-64 fpu fpu_exception wp vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx constant_tsc arch_perfmon pebs bts rep_good nopl aperfmperf eagerfpu pni dtes64 monitor ds_cpl vmx est tm2 ssse3 cx16 xtpr pdcm sse4_1 xsave lahf_lm tpr_shadow vnmi flexpriority dtherm cpufreq
              configuration: cores=2 enabledcores=2 threads=2
            *-cache:0
                 description: L1 cache
                 physical id: 700
                 size: 128KiB
                 capacity: 128KiB
                 capabilities: internal write-back unified
                 configuration: level=1
            *-cache:1
                 description: L2 cache
                 physical id: 701
                 size: 3MiB
                 capacity: 3MiB
                 capabilities: internal varies unified
                 configuration: level=2
         *-memory
              description: System Memory
              physical id: 1000
              slot: System board or motherboard
              size: 4GiB
            *-bank:0
                 description: DIMM DDR3 Synchronous 1066 MHz (0.9 ns)
                 product: M378B5673EH1-CH9
                 vendor: Samsung
                 physical id: 0
                 serial: 83BF5EDF
                 slot: DIMM_1
                 size: 2GiB
                 width: 64 bits
                 clock: 1066MHz (0.9ns)
            *-bank:1
                 description: DIMM DDR3 Synchronous 1066 MHz (0.9 ns)
                 product: HMT125U6TFR8C-H9
                 vendor: Hynix Semiconductor (Hyundai Electronics)
                 physical id: 1
                 serial: 0482C058
                 slot: DIMM_2
                 size: 2GiB
                 width: 64 bits
                 clock: 1066MHz (0.9ns)
         *-pci
              description: Host bridge
              product: 4 Series Chipset DRAM Controller
              vendor: Intel Corporation
              physical id: 100
              bus info: pci@0000:00:00.0
              version: 03
              width: 32 bits
              clock: 33MHz
            *-pci:0
                 description: PCI bridge
                 product: 4 Series Chipset PCI Express Root Port
                 vendor: Intel Corporation
                 physical id: 1
                 bus info: pci@0000:00:01.0
                 version: 03
                 width: 32 bits
                 clock: 33MHz
                 capabilities: pci pm msi pciexpress normal_decode bus_master cap_list
                 configuration: driver=pcieport
                 resources: irq:24 memory:fe500000-fe5fffff
            *-display:0
                 description: VGA compatible controller
                 product: 4 Series Chipset Integrated Graphics Controller
                 vendor: Intel Corporation
                 physical id: 2
                 bus info: pci@0000:00:02.0
                 version: 03
                 width: 64 bits
                 clock: 33MHz
                 capabilities: msi pm vga_controller bus_master cap_list rom
                 configuration: driver=i915 latency=0
                 resources: irq:26 memory:fe800000-febfffff memory:d0000000-dfffffff ioport:ecd8(size=8) memory:c0000-dffff
            *-display:1 UNCLAIMED
                 description: Display controller
                 product: 4 Series Chipset Integrated Graphics Controller
                 vendor: Intel Corporation
                 physical id: 2.1
                 bus info: pci@0000:00:02.1
                 version: 03
                 width: 64 bits
                 clock: 33MHz
                 capabilities: pm bus_master cap_list
                 configuration: latency=0
                 resources: memory:fe700000-fe7fffff
            *-multimedia
                 description: Audio device
                 product: NM10/ICH7 Family High Definition Audio Controller
                 vendor: Intel Corporation
                 physical id: 1b
                 bus info: pci@0000:00:1b.0
                 version: 01
                 width: 64 bits
                 clock: 33MHz
                 capabilities: pm msi pciexpress bus_master cap_list
                 configuration: driver=snd_hda_intel latency=0
                 resources: irq:27 memory:fe6fc000-fe6fffff
            *-pci:1
                 description: PCI bridge
                 product: NM10/ICH7 Family PCI Express Port 1
                 vendor: Intel Corporation
                 physical id: 1c
                 bus info: pci@0000:00:1c.0
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: pci pciexpress msi pm normal_decode bus_master cap_list
                 configuration: driver=pcieport
                 resources: irq:25 ioport:1000(size=4096) memory:fe400000-fe4fffff ioport:f0000000(size=2097152)
               *-network
                    description: Ethernet interface
                    product: NetLink BCM57780 Gigabit Ethernet PCIe
                    vendor: Broadcom Corporation
                    physical id: 0
                    bus info: pci@0000:02:00.0
                    logical name: enp2s0
                    version: 01
                    serial: b8:ac:6f:44:bc:74
                    size: 1Gbit/s
                    capacity: 1Gbit/s
                    width: 64 bits
                    clock: 33MHz
                    capabilities: pm msi pciexpress bus_master cap_list ethernet physical tp mii 10bt 10bt-fd 100bt 100bt-fd 1000bt 1000bt-fd autonegotiation
                    configuration: autonegotiation=on broadcast=yes driver=tg3 driverversion=3.137 duplex=full firmware=sb ip=192.168.1.117 latency=0 link=yes multicast=yes port=MII speed=1Gbit/s
                    resources: irq:28 memory:fe4f0000-fe4fffff
            *-usb:0
                 description: USB controller
                 product: NM10/ICH7 Family USB UHCI Controller #1
                 vendor: Intel Corporation
                 physical id: 1d
                 bus info: pci@0000:00:1d.0
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: uhci bus_master
                 configuration: driver=uhci_hcd latency=0
                 resources: irq:21 ioport:ff80(size=32)
               *-usbhost
                    product: UHCI Host Controller
                    vendor: Linux 4.9.0-deepin2-amd64 uhci_hcd
                    physical id: 1
                    bus info: usb@1
                    logical name: usb1
                    version: 4.09
                    capabilities: usb-1.10
                    configuration: driver=hub slots=2 speed=12Mbit/s
                  *-usb:0
                       description: Keyboard
                       product: Dell USB Keyboard
                       vendor: Dell
                       physical id: 1
                       bus info: usb@1:1
                       version: 3.07
                       capabilities: usb-1.10
                       configuration: driver=usbhid maxpower=70mA speed=2Mbit/s
                  *-usb:1
                       description: Mouse
                       product: USB Optical Mouse
                       vendor: Primax Electronics, Ltd
                       physical id: 2
                       bus info: usb@1:2
                       version: 2.00
                       capabilities: usb-2.00
                       configuration: driver=usbhid maxpower=100mA speed=2Mbit/s
            *-usb:1
                 description: USB controller
                 product: NM10/ICH7 Family USB UHCI Controller #2
                 vendor: Intel Corporation
                 physical id: 1d.1
                 bus info: pci@0000:00:1d.1
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: uhci bus_master
                 configuration: driver=uhci_hcd latency=0
                 resources: irq:22 ioport:ff60(size=32)
               *-usbhost
                    product: UHCI Host Controller
                    vendor: Linux 4.9.0-deepin2-amd64 uhci_hcd
                    physical id: 1
                    bus info: usb@2
                    logical name: usb2
                    version: 4.09
                    capabilities: usb-1.10
                    configuration: driver=hub slots=2 speed=12Mbit/s
            *-usb:2
                 description: USB controller
                 product: NM10/ICH7 Family USB UHCI Controller #3
                 vendor: Intel Corporation
                 physical id: 1d.2
                 bus info: pci@0000:00:1d.2
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: uhci bus_master
                 configuration: driver=uhci_hcd latency=0
                 resources: irq:18 ioport:ff40(size=32)
               *-usbhost
                    product: UHCI Host Controller
                    vendor: Linux 4.9.0-deepin2-amd64 uhci_hcd
                    physical id: 1
                    bus info: usb@3
                    logical name: usb3
                    version: 4.09
                    capabilities: usb-1.10
                    configuration: driver=hub slots=2 speed=12Mbit/s
            *-usb:3
                 description: USB controller
                 product: NM10/ICH7 Family USB UHCI Controller #4
                 vendor: Intel Corporation
                 physical id: 1d.3
                 bus info: pci@0000:00:1d.3
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: uhci bus_master
                 configuration: driver=uhci_hcd latency=0
                 resources: irq:23 ioport:ff20(size=32)
               *-usbhost
                    product: UHCI Host Controller
                    vendor: Linux 4.9.0-deepin2-amd64 uhci_hcd
                    physical id: 1
                    bus info: usb@4
                    logical name: usb4
                    version: 4.09
                    capabilities: usb-1.10
                    configuration: driver=hub slots=2 speed=12Mbit/s
            *-usb:4
                 description: USB controller
                 product: NM10/ICH7 Family USB2 EHCI Controller
                 vendor: Intel Corporation
                 physical id: 1d.7
                 bus info: pci@0000:00:1d.7
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: pm debug ehci bus_master cap_list
                 configuration: driver=ehci-pci latency=0
                 resources: irq:21 memory:ff980000-ff9803ff
               *-usbhost
                    product: EHCI Host Controller
                    vendor: Linux 4.9.0-deepin2-amd64 ehci_hcd
                    physical id: 1
                    bus info: usb@5
                    logical name: usb5
                    version: 4.09
                    capabilities: usb-2.00
                    configuration: driver=hub slots=8 speed=480Mbit/s
            *-pci:2
                 description: PCI bridge
                 product: 82801 PCI Bridge
                 vendor: Intel Corporation
                 physical id: 1e
                 bus info: pci@0000:00:1e.0
                 version: e1
                 width: 32 bits
                 clock: 33MHz
                 capabilities: pci subtractive_decode bus_master cap_list
            *-isa
                 description: ISA bridge
                 product: 82801GB/GR (ICH7 Family) LPC Interface Bridge
                 vendor: Intel Corporation
                 physical id: 1f
                 bus info: pci@0000:00:1f.0
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: isa bus_master cap_list
                 configuration: driver=lpc_ich latency=0
                 resources: irq:0
            *-ide:0
                 description: IDE interface
                 product: 82801G (ICH7 Family) IDE Controller
                 vendor: Intel Corporation
                 physical id: 1f.1
                 bus info: pci@0000:00:1f.1
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 capabilities: ide bus_master
                 configuration: driver=ata_piix latency=0
                 resources: irq:16 ioport:1f0(size=8) ioport:3f6 ioport:170(size=8) ioport:376 ioport:ffa0(size=16)
            *-ide:1
                 description: IDE interface
                 product: NM10/ICH7 Family SATA Controller [IDE mode]
                 vendor: Intel Corporation
                 physical id: 1f.2
                 bus info: pci@0000:00:1f.2
                 version: 01
                 width: 32 bits
                 clock: 66MHz
                 capabilities: ide pm bus_master cap_list
                 configuration: driver=ata_piix latency=0
                 resources: irq:20 ioport:fe00(size=8) ioport:fe10(size=4) ioport:fe20(size=8) ioport:fe30(size=4) ioport:fec0(size=16)
            *-serial
                 description: SMBus
                 product: NM10/ICH7 Family SMBus Controller
                 vendor: Intel Corporation
                 physical id: 1f.3
                 bus info: pci@0000:00:1f.3
                 version: 01
                 width: 32 bits
                 clock: 33MHz
                 configuration: driver=i801_smbus latency=0
                 resources: irq:17 ioport:ece0(size=32)
         *-scsi:0
              physical id: 1
              logical name: scsi2
              capabilities: emulated
            *-disk
                 description: ATA Disk
                 product: ST3500418AS
                 vendor: Seagate
                 physical id: 0.0.0
                 bus info: scsi@2:0.0.0
                 logical name: /dev/sda
                 version: CC38
                 serial: 5VMGE2YV
                 size: 465GiB (500GB)
                 capabilities: partitioned partitioned:dos
                 configuration: ansiversion=5 logicalsectorsize=512 sectorsize=512 signature=3ed730ea
               *-volume:0
                    description: EXT4 volume
                    vendor: Linux
                    physical id: 1
                    bus info: scsi@2:0.0.0,1
                    logical name: /dev/sda1
                    logical name: /home
                    version: 1.0
                    serial: 06848116-3c05-4b21-b074-85507f6f136b
                    size: 49GiB
                    capacity: 49GiB
                    capabilities: primary journaled extended_attributes large_files huge_files dir_nlink recover extents ext4 ext2 initialized
                    configuration: created=2015-11-13 21:12:20 filesystem=ext4 lastmountpoint=/home modified=2017-02-15 12:19:23 mount.fstype=ext4 mount.options=rw,relatime,data=ordered mounted=2017-02-15 12:19:23 state=mounted
               *-volume:1
                    description: EXT4 volume
                    vendor: Linux
                    physical id: 2
                    bus info: scsi@2:0.0.0,2
                    logical name: /dev/sda2
                    logical name: /
                    version: 1.0
                    serial: 35ebd624-9703-4247-82f2-c3a23f2f8c64
                    size: 49GiB
                    capacity: 49GiB
                    capabilities: primary journaled extended_attributes large_files huge_files dir_nlink recover extents ext4 ext2 initialized
                    configuration: created=2015-11-28 19:32:18 filesystem=ext4 lastmountpoint=/ modified=2017-02-15 12:19:14 mount.fstype=ext4 mount.options=rw,relatime,data=ordered mounted=2017-02-15 12:19:18 state=mounted
               *-volume:2
                    description: Windows NTFS volume
                    physical id: 3
                    bus info: scsi@2:0.0.0,3
                    logical name: /dev/sda3
                    version: 3.1
                    serial: 6749-837e
                    size: 49GiB
                    capacity: 49GiB
                    capabilities: primary ntfs initialized
                    configuration: clustersize=4096 created=2016-10-29 14:36:08 filesystem=ntfs state=clean
         *-scsi:1
              physical id: 2
              logical name: scsi3
              capabilities: emulated
            *-cdrom
                 description: DVD-RAM writer
                 product: DVD+-RW GH50N
                 vendor: HL-DT-ST
                 physical id: 0.0.0
                 bus info: scsi@3:0.0.0
                 logical name: /dev/cdrom
                 logical name: /dev/cdrw
                 logical name: /dev/dvd
                 logical name: /dev/dvdrw
                 logical name: /dev/sr0
                 version: B103
                 capabilities: removable audio cd-r cd-rw dvd dvd-r dvd-ram
                 configuration: ansiversion=5 status=nodisc
      *-network
           description: Ethernet interface
           physical id: 1
           logical name: docker0
           serial: 02:42:d7:fe:db:12
           capabilities: ethernet physical
           configuration: broadcast=yes driver=bridge driverversion=2.3 firmware=N/A ip=172.17.0.1 link=no multicast=yes

# SMBIOS/DMI (dmidecode)

    # dmidecode 3.0
    Getting SMBIOS data from sysfs.
    SMBIOS 2.5 present.
    75 structures occupying 2555 bytes.
    Table at 0x000F0450.
    
    Handle 0xDA00, DMI type 218, 89 bytes
    OEM-specific Type
    	Header and Data:
    		DA 59 00 DA B2 00 17 4B 0E 38 00 00 80 00 80 01
    		00 02 80 02 80 01 00 00 A0 00 A0 01 00 58 00 58
    		00 01 00 59 00 59 00 01 00 75 01 75 01 01 00 76
    		01 76 01 01 00 05 80 05 80 01 00 D1 01 19 00 01
    		00 19 00 19 00 00 00 4A 02 4A 02 01 00 0C 80 0C
    		80 01 00 FF FF 00 00 00 00
    
    Handle 0xDA01, DMI type 218, 35 bytes
    OEM-specific Type
    	Header and Data:
    		DA 23 01 DA B2 00 17 4B 0E 38 00 10 F5 10 F5 00
    		00 11 F5 11 F5 00 00 12 F5 12 F5 00 00 FF FF 00
    		00 00 00
    
    Handle 0xDA04, DMI type 218, 251 bytes
    OEM-specific Type
    	Header and Data:
    		DA FB 04 DA B2 00 17 4B 0E 38 00 42 00 42 00 01
    		00 43 00 43 00 01 00 0F 00 0F 00 01 00 10 00 10
    		00 01 00 11 00 11 00 01 00 12 00 12 00 01 00 00
    		00 13 00 01 00 00 00 14 00 01 00 00 00 15 00 01
    		00 00 00 16 00 01 00 07 00 07 00 01 00 08 00 08
    		00 01 00 09 00 09 00 01 00 0A 00 0A 00 01 00 0B
    		00 0B 00 01 00 0C 00 0C 00 01 00 0E 00 0E 00 01
    		00 01 F0 01 F0 01 00 0D 00 0D 00 01 00 A6 00 A6
    		00 01 00 A7 00 A7 00 01 00 05 01 05 01 01 00 06
    		01 06 01 01 00 8C 00 8C 00 01 00 8D 00 8D 00 01
    		00 09 01 09 01 01 00 A1 00 A1 00 01 00 A2 00 A2
    		00 01 00 A3 00 A3 00 01 00 9F 00 9F 00 01 00 A0
    		00 A0 00 01 00 9D 00 9D 00 01 00 9E 00 9E 00 01
    		00 54 01 54 01 01 00 55 01 55 01 01 00 04 80 04
    		80 01 00 01 A0 01 A0 01 00 93 00 93 00 01 00 94
    		00 94 00 01 00 FF FF 00 00 00 00
    
    Handle 0xDA05, DMI type 218, 137 bytes
    OEM-specific Type
    	Header and Data:
    		DA 89 05 DA B2 00 17 4B 0E 38 00 8A 00 8A 00 01
    		00 8B 00 8B 00 01 00 03 C0 03 C0 01 00 97 00 97
    		00 01 00 98 00 98 00 01 00 90 00 90 00 01 00 91
    		00 91 00 01 00 92 00 92 00 01 00 E2 00 E2 00 01
    		00 E3 00 E3 00 01 00 E4 00 E4 00 01 00 E5 00 E5
    		00 01 00 D1 00 D1 00 01 00 D2 00 D2 00 01 00 00
    		00 45 01 01 00 00 00 44 01 01 00 2B 01 2B 01 01
    		00 2C 01 2C 01 01 00 4E 01 4E 01 01 00 4F 01 4F
    		01 01 00 FF FF 00 00 00 00
    
    Handle 0xDA06, DMI type 218, 251 bytes
    OEM-specific Type
    	Header and Data:
    		DA FB 06 DA B2 00 17 4B 0E 38 00 17 01 17 01 01
    		00 18 01 18 01 01 00 19 01 19 01 01 00 1A 01 1A
    		01 01 00 1B 01 1B 01 01 00 1C 01 1C 01 01 00 1D
    		01 1D 01 01 00 1E 01 1E 01 01 00 87 00 87 00 01
    		00 88 00 88 00 01 00 04 02 04 02 01 00 05 02 05
    		02 01 00 00 00 62 02 01 00 00 00 63 02 01 00 2D
    		00 2D 00 01 00 2E 00 2E 00 01 00 6E 00 6E 00 01
    		00 E0 01 E0 01 01 00 28 00 28 00 01 00 29 00 29
    		00 01 00 2A 00 2A 00 01 00 2B 00 2B 00 01 00 2C
    		00 2C 00 01 00 55 00 55 00 01 00 6D 00 6D 00 01
    		00 8E 00 8E 00 01 00 8F 00 8F 00 01 00 00 00 1C
    		00 01 00 00 00 1D 00 01 00 23 00 23 00 01 00 22
    		00 22 00 01 00 F5 00 F5 00 01 00 F6 00 F6 00 01
    		00 EB 00 EB 00 01 00 EA 00 EA 00 01 00 40 01 40
    		01 01 00 41 01 41 01 01 00 ED 00 ED 00 01 00 F0
    		00 F0 00 01 00 FF FF 00 00 00 00
    
    Handle 0xDA07, DMI type 218, 101 bytes
    OEM-specific Type
    	Header and Data:
    		DA 65 07 DA B2 00 17 4B 0E 38 00 4A 01 4A 01 01
    		00 4B 01 4B 01 01 00 4C 01 4C 01 01 00 4D 01 4D
    		01 01 00 68 01 68 01 01 00 69 01 69 01 01 00 65
    		02 65 02 01 00 64 02 64 02 01 00 67 02 67 02 01
    		00 66 02 66 02 01 00 69 02 69 02 01 00 68 02 68
    		02 01 00 6D 02 6D 02 01 00 6C 02 6C 02 01 00 FF
    		FF 00 00 00 00
    
    Handle 0x0000, DMI type 0, 24 bytes
    BIOS Information
    	Vendor: Dell Inc.
    	Version: A01
    	Release Date: 03/11/2010
    	Address: 0xF0000
    	Runtime Size: 64 kB
    	ROM Size: 2048 kB
    	Characteristics:
    		PCI is supported
    		PNP is supported
    		APM is supported
    		BIOS is upgradeable
    		BIOS shadowing is allowed
    		ESCD support is available
    		Boot from CD is supported
    		Selectable boot is supported
    		EDD is supported
    		Japanese floppy for Toshiba 1.2 MB is supported (int 13h)
    		3.5"/720 kB floppy services are supported (int 13h)
    		Print screen service is supported (int 5h)
    		8042 keyboard services are supported (int 9h)
    		Serial services are supported (int 14h)
    		Printer services are supported (int 17h)
    		ACPI is supported
    		USB legacy is supported
    		BIOS boot specification is supported
    		Function key-initiated network boot is supported
    		Targeted content distribution is supported
    	BIOS Revision: 2.0
    
    Handle 0x0100, DMI type 1, 27 bytes
    System Information
    	Manufacturer: Dell Inc.
    	Product Name: OptiPlex 380                 
    	Version: Not Specified
    	Serial Number: FPRKX2X
    	UUID: 44454C4C-5000-1052-804B-C6C04F583258
    	Wake-up Type: Power Switch
    	SKU Number: Not Specified
    	Family: Not Specified
    
    Handle 0x0200, DMI type 2, 8 bytes
    Base Board Information
    	Manufacturer: Dell Inc.
    	Product Name: 0HN7XN
    	Version: A01
    	Serial Number: ..CN1374006S05VK.
    
    Handle 0x0300, DMI type 3, 13 bytes
    Chassis Information
    	Manufacturer: Dell Inc.
    	Type: Mini Tower
    	Lock: Not Present
    	Version: Not Specified
    	Serial Number: FPRKX2X
    	Asset Tag:           
    	Boot-up State: Safe
    	Power Supply State: Safe
    	Thermal State: Safe
    	Security Status: None
    
    Handle 0x0400, DMI type 4, 40 bytes
    Processor Information
    	Socket Designation: CPU
    	Type: Central Processor
    	Family: Core 2 Duo
    	Manufacturer: Intel
    	ID: 7A 06 01 00 FF FB EB BF
    	Signature: Type 0, Family 6, Model 23, Stepping 10
    	Flags:
    		FPU (Floating-point unit on-chip)
    		VME (Virtual mode extension)
    		DE (Debugging extension)
    		PSE (Page size extension)
    		TSC (Time stamp counter)
    		MSR (Model specific registers)
    		PAE (Physical address extension)
    		MCE (Machine check exception)
    		CX8 (CMPXCHG8 instruction supported)
    		APIC (On-chip APIC hardware supported)
    		SEP (Fast system call)
    		MTRR (Memory type range registers)
    		PGE (Page global enable)
    		MCA (Machine check architecture)
    		CMOV (Conditional move instruction supported)
    		PAT (Page attribute table)
    		PSE-36 (36-bit page size extension)
    		CLFSH (CLFLUSH instruction supported)
    		DS (Debug store)
    		ACPI (ACPI supported)
    		MMX (MMX technology supported)
    		FXSR (FXSAVE and FXSTOR instructions supported)
    		SSE (Streaming SIMD extensions)
    		SSE2 (Streaming SIMD extensions 2)
    		SS (Self-snoop)
    		HTT (Multi-threading)
    		TM (Thermal monitor supported)
    		PBE (Pending break enabled)
    	Version: Not Specified
    	Voltage: 1.2 V
    	External Clock: 1066 MHz
    	Max Speed: 5200 MHz
    	Current Speed: 2933 MHz
    	Status: Populated, Enabled
    	Upgrade: Socket LGA775
    	L1 Cache Handle: 0x0700
    	L2 Cache Handle: 0x0701
    	L3 Cache Handle: Not Provided
    	Serial Number: Not Specified
    	Asset Tag: Not Specified
    	Part Number: Not Specified
    	Core Count: 2
    	Core Enabled: 2
    	Thread Count: 2
    	Characteristics:
    		64-bit capable
    
    Handle 0x0700, DMI type 7, 19 bytes
    Cache Information
    	Socket Designation: Not Specified
    	Configuration: Enabled, Not Socketed, Level 1
    	Operational Mode: Write Back
    	Location: Internal
    	Installed Size: 128 kB
    	Maximum Size: 128 kB
    	Supported SRAM Types:
    		Other
    	Installed SRAM Type: Other
    	Speed: Unknown
    	Error Correction Type: None
    	System Type: Unified
    	Associativity: 8-way Set-associative
    
    Handle 0x0701, DMI type 7, 19 bytes
    Cache Information
    	Socket Designation: Not Specified
    	Configuration: Enabled, Not Socketed, Level 2
    	Operational Mode: Varies With Memory Address
    	Location: Internal
    	Installed Size: 3072 kB
    	Maximum Size: 3072 kB
    	Supported SRAM Types:
    		Other
    	Installed SRAM Type: Other
    	Speed: Unknown
    	Error Correction Type: Single-bit ECC
    	System Type: Unified
    	Associativity: 48-way Set-associative
    
    Handle 0x0800, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: PARALLEL
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: DB-25 female
    	Port Type: Parallel Port PS/2
    
    Handle 0x0801, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: SERIAL1
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: DB-9 male
    	Port Type: Serial Port 16550A Compatible
    
    Handle 0x0802, DMI type 126, 9 bytes
    Inactive
    
    Handle 0x0803, DMI type 126, 9 bytes
    Inactive
    
    Handle 0x0804, DMI type 126, 9 bytes
    Inactive
    
    Handle 0x0805, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB1
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x0806, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB2
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x0807, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB3
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x0808, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB4
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x0809, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB5
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x080A, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB6
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x080B, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB7
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x080C, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: USB8
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Access Bus (USB)
    	Port Type: USB
    
    Handle 0x080D, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: ENET
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: RJ-45
    	Port Type: Network Port
    
    Handle 0x080E, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: MIC
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Mini Jack (headphones)
    	Port Type: Audio Port
    
    Handle 0x080F, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: LINE-OUT
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Mini Jack (headphones)
    	Port Type: Audio Port
    
    Handle 0x0810, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: LINE-IN
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Mini Jack (headphones)
    	Port Type: Audio Port
    
    Handle 0x0811, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: HP-OUT
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: Mini Jack (headphones)
    	Port Type: Audio Port
    
    Handle 0x0812, DMI type 8, 9 bytes
    Port Connector Information
    	Internal Reference Designator: MONITOR
    	Internal Connector Type: None
    	External Reference Designator: Not Specified
    	External Connector Type: DB-15 female
    	Port Type: Video Port
    
    Handle 0x090A, DMI type 9, 13 bytes
    System Slot Information
    	Designation: SLOT1
    	Type: x1 Proprietary
    	Current Usage: Available
    	Length: Long
    	Characteristics:
    		PME signal is supported
    
    Handle 0x0901, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0902, DMI type 9, 13 bytes
    System Slot Information
    	Designation: SLOT2  
    	Type: 32-bit PCI
    	Current Usage: Available
    	Length: Long
    	ID: 2
    	Characteristics:
    		5.0 V is provided
    		3.3 V is provided
    		PME signal is supported
    
    Handle 0x0903, DMI type 9, 13 bytes
    System Slot Information
    	Designation: SLOT3  
    	Type: 32-bit PCI
    	Current Usage: Available
    	Length: Long
    	ID: 3
    	Characteristics:
    		5.0 V is provided
    		3.3 V is provided
    		PME signal is supported
    
    Handle 0x0904, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0905, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0906, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0907, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0908, DMI type 126, 13 bytes
    Inactive
    
    Handle 0x0A00, DMI type 10, 6 bytes
    On Board Device Information
    	Type: Video
    	Status: Enabled
    	Description: Intel Graphics Media Accelerator 950
    
    Handle 0x0A02, DMI type 10, 6 bytes
    On Board Device Information
    	Type: Ethernet
    	Status: Enabled
    	Description: Broadcom 57780 NetXtreme Gigabit Controller
    
    Handle 0x0A03, DMI type 10, 6 bytes
    On Board Device Information
    	Type: Sound
    	Status: Enabled
    	Description: Intel(R) High Definition Audio Controller
    
    Handle 0x0B00, DMI type 11, 5 bytes
    OEM Strings
    	String 1: www.dell.com
    
    Handle 0x0D00, DMI type 13, 22 bytes
    BIOS Language Information
    	Language Description Format: Long
    	Installable Languages: 1
    		en|US|iso8859-1
    	Currently Installed Language: en|US|iso8859-1
    
    Handle 0x0F00, DMI type 15, 29 bytes
    System Event Log
    	Area Length: 2049 bytes
    	Header Start Offset: 0x0000
    	Header Length: 16 bytes
    	Data Start Offset: 0x0010
    	Access Method: Memory-mapped physical 32-bit address
    	Access Address: 0xFFE01000
    	Status: Valid, Not Full
    	Change Token: 0x0000001C
    	Header Format: Type 1
    	Supported Log Type Descriptors: 3
    	Descriptor 1: POST error
    	Data Format 1: POST results bitmap
    	Descriptor 2: System limit exceeded
    	Data Format 2: System management
    	Descriptor 3: Log area reset/cleared
    	Data Format 3: None
    
    Handle 0x1000, DMI type 16, 15 bytes
    Physical Memory Array
    	Location: System Board Or Motherboard
    	Use: System Memory
    	Error Correction Type: None
    	Maximum Capacity: 4 GB
    	Error Information Handle: Not Provided
    	Number Of Devices: 2
    
    Handle 0x1100, DMI type 17, 27 bytes
    Memory Device
    	Array Handle: 0x1000
    	Error Information Handle: Not Provided
    	Total Width: 64 bits
    	Data Width: 64 bits
    	Size: 2048 MB
    	Form Factor: DIMM
    	Set: None
    	Locator: DIMM_1
    	Bank Locator: Not Specified
    	Type: DDR3
    	Type Detail: Synchronous
    	Speed: 1066 MHz
    	Manufacturer: 80CE000080CE    
    	Serial Number: 83BF5EDF
    	Asset Tag: 02092100
    	Part Number: M378B5673EH1-CH9  
    
    Handle 0x1101, DMI type 17, 27 bytes
    Memory Device
    	Array Handle: 0x1000
    	Error Information Handle: Not Provided
    	Total Width: 64 bits
    	Data Width: 64 bits
    	Size: 2048 MB
    	Form Factor: DIMM
    	Set: None
    	Locator: DIMM_2
    	Bank Locator: Not Specified
    	Type: DDR3
    	Type Detail: Synchronous
    	Speed: 1066 MHz
    	Manufacturer: 80AD000080AD    
    	Serial Number: 0482C058
    	Asset Tag: 01102300
    	Part Number: HMT125U6TFR8C-H9  
    
    Handle 0x1300, DMI type 19, 15 bytes
    Memory Array Mapped Address
    	Starting Address: 0x00000000000
    	Ending Address: 0x000FFFFFFFF
    	Range Size: 4 GB
    	Physical Array Handle: 0x1000
    	Partition Width: 1
    
    Handle 0x1400, DMI type 20, 19 bytes
    Memory Device Mapped Address
    	Starting Address: 0x00000000000
    	Ending Address: 0x000FFFFFFFF
    	Range Size: 4 GB
    	Physical Device Handle: 0x1100
    	Memory Array Mapped Address Handle: 0x1300
    	Partition Row Position: 1
    	Interleave Position: 1
    	Interleaved Data Depth: 1
    
    Handle 0x1401, DMI type 20, 19 bytes
    Memory Device Mapped Address
    	Starting Address: 0x00000000000
    	Ending Address: 0x000FFFFFFFF
    	Range Size: 4 GB
    	Physical Device Handle: 0x1101
    	Memory Array Mapped Address Handle: 0x1300
    	Partition Row Position: 1
    	Interleave Position: 2
    	Interleaved Data Depth: 1
    
    Handle 0x1410, DMI type 126, 19 bytes
    Inactive
    
    Handle 0x1800, DMI type 24, 5 bytes
    Hardware Security
    	Power-On Password Status: Enabled
    	Keyboard Password Status: Not Implemented
    	Administrator Password Status: Enabled
    	Front Panel Reset Status: Not Implemented
    
    Handle 0x1900, DMI type 25, 9 bytes
    	System Power Controls
    	Next Scheduled Power-on: *-* 00:00:00
    
    Handle 0x1B10, DMI type 27, 12 bytes
    Cooling Device
    	Type: Fan
    	Status: OK
    	OEM-specific Information: 0x0000DD00
    
    Handle 0x1B11, DMI type 126, 12 bytes
    Inactive
    
    Handle 0x1B12, DMI type 126, 12 bytes
    Inactive
    
    Handle 0x1B13, DMI type 126, 12 bytes
    Inactive
    
    Handle 0x1B14, DMI type 126, 12 bytes
    Inactive
    
    Handle 0x2000, DMI type 32, 11 bytes
    System Boot Information
    	Status: No errors detected
    
    Handle 0xB100, DMI type 177, 12 bytes
    OEM-specific Type
    	Header and Data:
    		B1 0C 00 B1 02 00 00 00 00 00 00 00
    
    Handle 0x8800, DMI type 136, 6 bytes
    OEM-specific Type
    	Header and Data:
    		88 06 00 88 5A 5A
    
    Handle 0xD000, DMI type 208, 12 bytes
    OEM-specific Type
    	Header and Data:
    		D0 0C 00 D0 01 03 FE 00 00 04 01 02
    	Strings:
    		20100717
    		20100726
    
    Handle 0xD100, DMI type 209, 12 bytes
    OEM-specific Type
    	Header and Data:
    		D1 0C 00 D1 78 03 07 03 04 0F 80 05
    
    Handle 0xD200, DMI type 210, 12 bytes
    OEM-specific Type
    	Header and Data:
    		D2 0C 00 D2 F8 03 04 03 06 80 04 05
    
    Handle 0xD201, DMI type 126, 12 bytes
    Inactive
    
    Handle 0xD400, DMI type 212, 47 bytes
    OEM-specific Type
    	Header and Data:
    		D4 2F 00 D4 70 00 71 00 00 10 2D 2E 5C 00 78 BF
    		40 5D 00 78 BF 00 2D 01 21 FE 01 2E 01 21 FE 00
    		2B 00 5A 00 00 2C 00 5B 00 00 FF FF 00 00 00
    
    Handle 0xD800, DMI type 216, 9 bytes
    OEM-specific Type
    	Header and Data:
    		D8 09 00 D8 01 02 01 F0 03
    	Strings:
    		Intel Corp.
    		ate 
    
    Handle 0xDD00, DMI type 221, 19 bytes
    OEM-specific Type
    	Header and Data:
    		DD 13 00 DD 00 01 00 00 00 10 F5 00 00 00 00 00
    		00 00 00
    
    Handle 0xDD01, DMI type 221, 19 bytes
    OEM-specific Type
    	Header and Data:
    		DD 13 01 DD 00 01 00 00 00 11 F5 00 00 00 00 00
    		00 00 00
    
    Handle 0xDD02, DMI type 221, 19 bytes
    OEM-specific Type
    	Header and Data:
    		DD 13 02 DD 00 01 00 00 00 12 F5 00 00 00 00 00
    		00 00 00
    
    Handle 0xDE00, DMI type 222, 13 bytes
    OEM-specific Type
    	Header and Data:
    		DE 0D 00 DE C1 01 FF FF 00 00 00 00 00
    
    Handle 0x7F00, DMI type 127, 4 bytes
    End Of Table
