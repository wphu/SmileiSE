
# Loaded Drivers

    Module                  Size  Used by
    bluetooth             557056  0
    rfkill                 24576  2 bluetooth
    fuse                   98304  1
    ipt_MASQUERADE         16384  1
    pci_stub               16384  1
    vboxpci                24576  0
    nf_nat_masquerade_ipv4    16384  1 ipt_MASQUERADE
    vboxnetadp             28672  0
    vboxnetflt             28672  0
    vboxdrv               454656  3 vboxnetadp,vboxnetflt,vboxpci
    iptable_nat            16384  1
    nf_conntrack_ipv4      16384  2
    nf_defrag_ipv4         16384  1 nf_conntrack_ipv4
    nf_nat_ipv4            16384  1 iptable_nat
    xt_addrtype            16384  2
    iptable_filter         16384  1
    ip_tables              24576  2 iptable_filter,iptable_nat
    xt_conntrack           16384  1
    x_tables               36864  5 ip_tables,iptable_filter,ipt_MASQUERADE,xt_addrtype,xt_conntrack
    nf_nat                 28672  2 nf_nat_masquerade_ipv4,nf_nat_ipv4
    nf_conntrack          114688  5 nf_conntrack_ipv4,nf_nat_masquerade_ipv4,xt_conntrack,nf_nat_ipv4,nf_nat
    br_netfilter           24576  0
    bridge                135168  1 br_netfilter
    stp                    16384  1 bridge
    llc                    16384  2 bridge,stp
    xfrm_user              36864  2
    overlay                49152  0
    xfrm4_tunnel           16384  0
    tunnel4                16384  1 xfrm4_tunnel
    ipcomp                 16384  0
    xfrm_ipcomp            16384  1 ipcomp
    esp4                   20480  0
    ah4                    20480  0
    af_key                 36864  0
    xfrm_algo              16384  5 xfrm_user,esp4,ah4,af_key,xfrm_ipcomp
    dell_wmi               16384  0
    sparse_keymap          16384  1 dell_wmi
    dell_smbios            16384  1 dell_wmi
    coretemp               16384  0
    iTCO_wdt               16384  0
    iTCO_vendor_support    16384  1 iTCO_wdt
    kvm_intel             192512  0
    kvm                   589824  1 kvm_intel
    irqbypass              16384  1 kvm
    dcdbas                 16384  1 dell_smbios
    snd_hda_codec_realtek    86016  1
    snd_hda_codec_generic    69632  1 snd_hda_codec_realtek
    snd_hda_intel          36864  3
    i2c_i801               24576  0
    snd_hda_codec         135168  3 snd_hda_intel,snd_hda_codec_generic,snd_hda_codec_realtek
    snd_hda_core           81920  4 snd_hda_intel,snd_hda_codec,snd_hda_codec_generic,snd_hda_codec_realtek
    i2c_smbus              16384  1 i2c_i801
    snd_hwdep              16384  1 snd_hda_codec
    pcspkr                 16384  0
    snd_pcm               110592  3 snd_hda_intel,snd_hda_codec,snd_hda_core
    serio_raw              16384  0
    snd_timer              32768  1 snd_pcm
    lpc_ich                24576  0
    mfd_core               16384  1 lpc_ich
    sg                     32768  0
    snd                    86016  13 snd_hda_intel,snd_hwdep,snd_hda_codec,snd_timer,snd_hda_codec_generic,snd_hda_codec_realtek,snd_pcm
    soundcore              16384  1 snd
    evdev                  24576  13
    rng_core               16384  0
    shpchp                 36864  0
    acpi_cpufreq           20480  0
    tpm_tis                16384  0
    tpm_tis_core           20480  1 tpm_tis
    tpm                    45056  2 tpm_tis,tpm_tis_core
    binfmt_misc            20480  1
    parport_pc             28672  1
    ppdev                  20480  0
    lp                     20480  0
    parport                49152  3 lp,parport_pc,ppdev
    autofs4                40960  2
    ext4                  585728  2
    crc16                  16384  2 bluetooth,ext4
    jbd2                  106496  1 ext4
    fscrypto               28672  1 ext4
    ecb                    16384  0
    glue_helper            16384  0
    lrw                    16384  0
    gf128mul               16384  1 lrw
    ablk_helper            16384  0
    cryptd                 24576  1 ablk_helper
    aes_x86_64             20480  0
    mbcache                16384  3 ext4
    raid10                 49152  0
    raid456               106496  0
    async_raid6_recov      20480  1 raid456
    async_memcpy           16384  2 raid456,async_raid6_recov
    async_pq               16384  2 raid456,async_raid6_recov
    async_xor              16384  3 async_pq,raid456,async_raid6_recov
    async_tx               16384  5 async_xor,async_pq,raid456,async_memcpy,async_raid6_recov
    xor                    24576  1 async_xor
    raid6_pq              110592  3 async_pq,raid456,async_raid6_recov
    libcrc32c              16384  1 raid456
    crc32c_generic         16384  1
    raid1                  36864  0
    raid0                  20480  0
    multipath              16384  0
    linear                 16384  0
    md_mod                131072  6 raid1,raid10,multipath,linear,raid0,raid456
    hid_generic            16384  0
    usbhid                 53248  0
    hid                   122880  2 hid_generic,usbhid
    sr_mod                 24576  0
    sd_mod                 45056  3
    cdrom                  61440  1 sr_mod
    ata_generic            16384  0
    psmouse               135168  0
    ata_piix               36864  2
    broadcom               20480  0
    bcm_phy_lib            16384  1 broadcom
    libata                249856  2 ata_piix,ata_generic
    scsi_mod              225280  4 sd_mod,libata,sr_mod,sg
    ehci_pci               16384  0
    tg3                   159744  0
    ptp                    20480  1 tg3
    pps_core               16384  1 ptp
    libphy                 49152  3 bcm_phy_lib,tg3,broadcom
    wmi                    16384  1 dell_wmi
    i915                 1232896  18
    uhci_hcd               45056  0
    ehci_hcd               81920  1 ehci_pci
    video                  40960  2 dell_wmi,i915
    usbcore               249856  4 usbhid,ehci_hcd,uhci_hcd,ehci_pci
    usb_common             16384  1 usbcore
    button                 16384  1 i915
    i2c_algo_bit           16384  1 i915
    drm_kms_helper        155648  1 i915
    drm                   360448  14 i915,drm_kms_helper

# Driver Modules File

    # /etc/modules: kernel modules to load at boot time.
    #
    # This file contains the names of kernel modules that should be loaded
    # at boot time, one per line. Lines beginning with "#" are ignored.
    
    bbswitch

# Driver Blacklist File

    /etc/modprobe.d/dkms.conf
    /etc/modprobe.d/intel-microcode-blacklist.conf
    /etc/modprobe.d/mdadm.conf
    
    
    
    ## /etc/modprobe.d/dkms.conf
    # modprobe information used for DKMS modules
    #
    # This is a stub file, should be edited when needed,
    # used by default by DKMS.
    
    ## /etc/modprobe.d/intel-microcode-blacklist.conf
    # The microcode module attempts to apply a microcode update when
    # it autoloads.  This is not always safe, so we block it by default.
    blacklist microcode
    
    ## /etc/modprobe.d/mdadm.conf
    # mdadm module configuration file
    # set start_ro=1 to make newly assembled arrays read-only initially,
    # to prevent metadata writes.  This is needed in order to allow
    # resume-from-disk to work - new boot should not perform writes
    # because it will be done behind the back of the system being
    # resumed.  See http://bugs.debian.org/415441 for details.
    
    options md_mod start_ro=1

# Installed Driver Packages

    ii  cups                                      2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD/driver support, web interface
    ii  cups-core-drivers                         2.2.1-2                           amd64        Common UNIX Printing System(tm) - PPD-less printing
    ii  cups-filters-core-drivers                 1.11.6-1+b1                       amd64        OpenPrinting CUPS Filters - PPD-less printing
    ii  firmware-linux-free                       3.4                               all          Binary firmware for various drivers in the Linux kernel
    ii  firmware-zd1211                           1:1.5-4                           all          binary firmware for the zd1211rw wireless driver
    ii  i965-va-driver:i386                       1.7.2-1                           i386         VAAPI driver for Intel G45 & HD Graphics family
    ii  libasound2-data                           1.1.2-1                           all          Configuration files and profiles for ALSA drivers
    ii  libdrm-amdgpu1:amd64                      2.4.71-1                          amd64        Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-amdgpu1:i386                       2.4.71-1                          i386         Userspace interface to amdgpu-specific kernel DRM services -- runtime
    ii  libdrm-dev:amd64                          2.4.71-1                          amd64        Userspace interface to kernel DRM services -- development files
    ii  libdrm-intel1:amd64                       2.4.71-1                          amd64        Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-intel1:i386                        2.4.71-1                          i386         Userspace interface to intel-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:amd64                     2.4.71-1                          amd64        Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-nouveau2:i386                      2.4.71-1                          i386         Userspace interface to nouveau-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:amd64                      2.4.71-1                          amd64        Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm-radeon1:i386                       2.4.71-1                          i386         Userspace interface to radeon-specific kernel DRM services -- runtime
    ii  libdrm2:amd64                             2.4.71-1                          amd64        Userspace interface to kernel DRM services -- runtime
    ii  libdrm2:i386                              2.4.71-1                          i386         Userspace interface to kernel DRM services -- runtime
    ii  libegl1-mesa:amd64                        12.0.3-3                          amd64        free implementation of the EGL API -- runtime
    ii  libegl1-mesa-dev:amd64                    12.0.3-3                          amd64        free implementation of the EGL API -- development files
    ii  libgl1-mesa-dev:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX development files
    ii  libgl1-mesa-dri:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-dri:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- DRI modules
    ii  libgl1-mesa-glx:amd64                     12.0.3-3                          amd64        free implementation of the OpenGL API -- GLX runtime
    ii  libgl1-mesa-glx:i386                      12.0.3-3                          i386         free implementation of the OpenGL API -- GLX runtime
    ii  libglapi-mesa:amd64                       12.0.3-3                          amd64        free implementation of the GL API -- shared library
    ii  libglapi-mesa:i386                        12.0.3-3                          i386         free implementation of the GL API -- shared library
    ii  libgles1-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 1.x API -- runtime
    ii  libgles2-mesa:amd64                       12.0.3-3                          amd64        free implementation of the OpenGL|ES 2.x API -- runtime
    ii  libglu1-mesa:amd64                        9.0.0-2.1                         amd64        Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa:i386                         9.0.0-2.1                         i386         Mesa OpenGL utility library (GLU)
    ii  libglu1-mesa-dev:amd64                    9.0.0-2.1                         amd64        Mesa OpenGL utility library -- development files
    ii  liblwp-protocol-https-perl                6.06-2                            all          HTTPS driver for LWP::UserAgent
    ii  libntfs-3g871                             1:2016.2.22AR.1-3                 amd64        read/write NTFS driver for FUSE (runtime library)
    ii  libosmesa6:i386                           12.0.3-3                          i386         Mesa Off-screen rendering extension
    ii  libqt5sql5-sqlite:amd64                   5.6.1+dfsg-3+b1                   amd64        Qt 5 SQLite 3 database driver
    ii  libreoffice-base-drivers                  1:5.1.5~rc2-1                     amd64        Database connectivity drivers for LibreOffice
    ii  libreoffice-sdbc-firebird                 1:5.1.5~rc2-1                     amd64        Firebird SDBC driver for LibreOffice
    ii  libreoffice-sdbc-hsqldb                   1:5.1.5~rc2-1                     amd64        HSQLDB SDBC driver for LibreOffice
    ii  libva-drm1:amd64                          1.7.3-2                           amd64        Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libva-drm1:i386                           1.7.3-2                           i386         Video Acceleration (VA) API for Linux -- DRM runtime
    ii  libvdpau-va-gl1:amd64                     0.4.2-1                           amd64        VDPAU driver with OpenGL/VAAPI backend
    ii  libvdpau-va-gl1:i386                      0.4.2-1                           i386         VDPAU driver with OpenGL/VAAPI backend
    ii  libwayland-egl1-mesa:amd64                12.0.3-3                          amd64        implementation of the Wayland EGL platform -- runtime
    ii  mesa-common-dev:amd64                     12.0.3-3                          amd64        Developer documentation for Mesa
    ii  mesa-utils                                8.3.0-2+b1                        amd64        Miscellaneous Mesa GL utilities
    ii  mesa-vdpau-drivers:amd64                  12.0.3-3                          amd64        Mesa VDPAU video acceleration drivers
    ii  mesa-vdpau-drivers:i386                   12.0.3-3                          i386         Mesa VDPAU video acceleration drivers
    ii  mintdrivers                               1.3.0-1                           all          Driver Manager
    ii  ntfs-3g                                   1:2016.2.22AR.1-3                 amd64        read/write NTFS driver for FUSE
    ii  ubuntu-drivers-common                     3:0.4.22+deepin                   amd64        Detect and install additional Ubuntu driver packages
    ii  va-driver-all:i386                        1.7.3-2                           i386         Video Acceleration (VA) API -- driver metapackage
    ii  vdpau-driver-all:amd64                    1.1.1-5                           amd64        Video Decode and Presentation API for Unix (driver metapackage)
    ii  vdpau-driver-all:i386                     1.1.1-5                           i386         Video Decode and Presentation API for Unix (driver metapackage)
    ii  vdpau-va-driver:i386                      0.7.4-6                           i386         VDPAU-based backend for VA API
    ii  xserver-xorg-input-all                    1:7.7+18                          amd64        X.Org X server -- input driver metapackage
    ii  xserver-xorg-input-evdev                  1:2.10.4-1+b1                     amd64        X.Org X server -- evdev input driver
    ii  xserver-xorg-input-libinput               0.23.0-2                          amd64        X.Org X server -- libinput input driver
    ii  xserver-xorg-input-mouse                  1:1.9.2-1+b1                      amd64        X.Org X server -- mouse input driver
    ii  xserver-xorg-input-synaptics              1.9.0-1+b1                        amd64        Synaptics TouchPad driver for X.Org server
    ii  xserver-xorg-input-wacom                  0.33.0-1+b1                       amd64        X.Org X server -- Wacom input driver
    ii  xserver-xorg-video-all                    1:7.7+18                          amd64        X.Org X server -- output driver metapackage
    ii  xserver-xorg-video-amdgpu                 1.2.0-1+b1                        amd64        X.Org X server -- AMDGPU display driver
    ii  xserver-xorg-video-ati                    1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI display driver wrapper
    ii  xserver-xorg-video-fbdev                  1:0.4.4-1+b5                      amd64        X.Org X server -- fbdev display driver
    ii  xserver-xorg-video-intel                  2:2.99.917+git20161206-1          amd64        X.Org X server -- Intel i8xx, i9xx display driver
    ii  xserver-xorg-video-nouveau                1:1.0.13-1+b1                     amd64        X.Org X server -- Nouveau display driver
    ii  xserver-xorg-video-radeon                 1:7.8.0-1+b1                      amd64        X.Org X server -- AMD/ATI Radeon display driver
    ii  xserver-xorg-video-vesa                   1:2.3.4-1+b2                      amd64        X.Org X server -- VESA display driver
    ii  xserver-xorg-video-vmware                 1:13.2.1-1+b1                     amd64        X.Org X server -- VMware display driver
