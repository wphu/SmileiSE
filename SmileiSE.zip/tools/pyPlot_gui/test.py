import normalization_units as nu

print nu.c
print nu.norm_n
