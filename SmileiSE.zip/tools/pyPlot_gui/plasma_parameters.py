import sys
sys.path.append('.')
import normalization_units as nu

mass_e = 9.109382616e-31
mass_D = 2.0 * 1.67262158e-27

print mass_D / mass_e

print "test import  ",nu.norm_l
