#include "Diagnostic2D.h"

Diagnostic2D::Diagnostic2D(PicParams& params, SmileiMPI* smpi, ElectroMagn* EMfields) :
Diagnostic(params)
{

}
