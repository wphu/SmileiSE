mpiexec -n 4 ../../src/smilei tst1d_periodic.py
