mpiexec -n 5 ../../src/smilei tst1d_periodic.py
