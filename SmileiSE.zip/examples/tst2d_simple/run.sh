mpiexec -n 4 ../../src/smilei tst2d_simple.py
