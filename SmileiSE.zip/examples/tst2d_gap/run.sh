mpiexec -n 24 ../../src/smilei tst2d_gap.py
