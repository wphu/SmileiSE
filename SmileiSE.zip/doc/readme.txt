Open the manual files using WPS software 
